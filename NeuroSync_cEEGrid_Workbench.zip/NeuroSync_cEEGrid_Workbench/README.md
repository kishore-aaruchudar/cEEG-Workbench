# NeuroSync - cEEGrid Workbench · 2.2

A local Python application for inspecting continuous EEG, reviewing ICA sources,
annotating irregular intervals, and retaining review decisions for later analysis.
It opens in your browser; processing and saved sessions stay on your computer.

## Start

1. Extract the entire ZIP into a writable folder.
2. On Windows, double-click `start_windows.bat`. Python 3.10 or later must be installed.
3. Leave the console open while using the app at `http://127.0.0.1:8765`.
4. Click **Open a recording**, or open **Workspace** to select a saved session or a local path.

On macOS/Linux, run `bash start_mac_linux.sh`, or install and launch manually:

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py
```

To choose a different port or workspace:

```sh
python run.py --port 8766 --workspace /path/to/sessions --no-browser
```

The first launch installs Python dependencies and needs internet access.
No demo recordings or synthetic-data generator are included in the application.
The tests generate disposable numerical fixtures and do not install sample sessions.

## Upgrade from an earlier version

Stop the old server. Replace its program files with this version while keeping
its `sessions` folder in the same location. Alternatively, copy your existing
`sessions` folder into the newly extracted `NeuroSync_cEEGrid_Workbench` folder.
Restart and press **Ctrl+F5** to refresh browser assets. Previous sessions,
annotations, component decisions and stage histories remain readable. Existing
browser view preferences are kept for continuity.

## Open recordings

Supported continuous formats: EEGLAB SET, EDF, BDF, MNE FIF and NPZ.
For external EEGLAB samples, select **the SET and its FDT together** using Ctrl
or Shift, preserving their original filenames. Alternatively, keep both files
in one folder and enter the SET path under **Workspace → Recording → Open by
local file path**. Use the local-path route for large or split recordings.
Epoched SET data are not silently flattened into a continuous recording.

SET import settings expose montage units and text encoding. MNE converts
EEGLAB sample amplitudes to volts; the app does not convert those samples twice.
NPZ files need `data` (channels × samples), `sfreq`, and `ch_names`; specify
whether their samples are volts or microvolts in the import controls.

From your notebook, save a compatible recording and open the resulting FIF:

```python
Band_Pass_Filter_Data.save('participant_filtered_raw.fif', overwrite=False)
# Or save ica_cleaned to inspect an already corrected recording.
```

The application fits its own ICA solution; it does not import an existing
notebook ICA object.

## Viewing and magnifying plots

EEG and ICA component plots open with comfortably spaced rows. Scroll the row
list as needed, or click **Fit rows** to put all displayed rows in one view.
**Whole screen** opens a screen-filling view and fits every EEG channel (up to
64) or every ICA component without vertical plot scrolling. When you exit, the
previous channel selection and row spacing return. Use Escape to exit.

Move the mouse over a waveform or the all-component ICA plot and scroll to
change its shared display sensitivity. Scroll up for taller traces; down for
shorter traces. Shift + wheel changes the time window; Alt + wheel scrolls a
spaced row list. These controls change only the display.

To magnify a particular region:

1. Select **Magnify** in Waveforms, Spectrum, All ICA components, or ICA detail.
2. Drag across a time range on the desired EEG channel or ICA component. On a
   spectrum, drag across the frequency range. A small plot opens on the same
   screen, including in Whole screen mode.
3. Move the detail window by dragging its title bar; close it with ×. You may
   select another interval without changing the main view. Select another mode
   when finished.

The EEG and ICA detail views retrieve the selected interval again from the full
stored samples or fitted source, using the same peak-preserving envelope if
there are more points than the display limit. The y-axis shows original values
in µV or ICA arbitrary units rather than display-centered values. Very short
selections expand to the minimum window required by the reader.

In the **Spectrum** tab, select the primary stage and optionally enable
**Compare** to choose a second stage, then calculate PSD. Both lines use the
same interval, channels and review exclusions; the band-power table lists the
primary stage. **Whole screen** expands the spectrum workspace and keeps the
comparison and magnifier controls available. Press Escape to exit.

Spectrum detail displays existing PSD bins, including both labeled stages if a
comparison was calculated. It does not recompute the spectrum or invent finer
frequency resolution. The frequency-bin spacing is shown under the detail plot.

- **Timeline:** a taller overview makes the median channel RMS, annotations and current window visible. Click anywhere to navigate.
- **Waveforms:** navigate, adjust sensitivity, compare stages, magnify, zoom the
  main time window or annotate a range.
- **Display options:** choose channels, mark persistent bad channels, set
  centering and clipping, and inspect signal diagnostics.
- **Workspace:** import, filtering, reference, ICA fitting, screening and export.
- **Color key:** opens the meaning of each line, interval and marker.
- **Stages:** shows processing lineage, reference and ICA fitting input.

Secondary dialogs, saved-annotation tables, screening results, long logs and
spaced row lists can scroll within their panels. Very small screens or unusually
many rows may make labels small in Whole screen mode; choose fewer channels in
Display options for closer reading.

## ICA detail layout

The **ICA detail** tab separates the source time course, source spectrum, and
cEEGrid electrode weights into independent plot frames. Axis labels and scales
stay within their respective plots. Sensor names are arranged in label columns,
with lines connecting them to the unshifted electrode positions. Both ears share
the same signed weight color scale.

Choose **Both**, **Source**, or **Electrode weights** above the plots. Smaller
screens initially show the source panel; choose **Electrode weights** to inspect
the maps at full width. Narrow electrode panels stack the two ears vertically.
When needed, the plot area can scroll internally instead of clipping figures.
**Whole screen** gives ICA detail more room.

The timeline is hidden by default in ICA detail to make room for the figures.
Click **Show timeline** to bring it back, or **Hide timeline** to reclaim space.
It remains visible in the waveform workspace.

## ICA replay and annotations

Fit a model under **Workspace → ICA separation**, then open **All ICA components**.
Sources appear in one stacked chart. Click a row to inspect it, select the
shared gain, or click **Fit components**. Play/pause replays recorded time at
0.25×–4× recorded-time speed. The replay time appears as text; the plots have no moving cursor line. This is not a live EEG-device connection.
**Whole screen** (or **F**) toggles a dedicated ICA replay view. If the browser
cannot enter native fullscreen, the app uses a viewport-filling focus mode.

The controls beside **Window** have different purposes:

- **Window** is the amount of recording shown in each view.
- **Window speed** is a manually entered number of recording seconds the window
  moves per real second. Enter `0` to freeze it. You can enter values from 0 to
  100; press Enter or leave the field to apply the value.
- **Replay speed** separately controls how quickly the replay time advances.

For example, a window speed of `0.5 s/s` and a replay speed of `2×` make the
window advance half a recording second while replay time advances two seconds
per real second. The readout shows both times. They may diverge; when replay
is outside the visible window, the ICA live readout says so instead of showing
an unrelated sample. The display refreshes automatically; slow processing can
make redraws less frequent or skip intermediate views, but does not change the
two clock rates. Replay stops at the end of the recording.

The window settings are shared between waveform and ICA views and saved with the
view preferences. The current window remains highlighted on the timeline; no
moving replay cursor line is shown.

Two ways to create a time annotation from replay:

1. Click **Annotate**, then drag a time interval on the source plot. Replay pauses
   while you select the range. Enter the label and note, then save.
2. Click **Mark start** at the replay time, continue replay or navigate forward,
   then click **Mark end & annotate**. This also works across time windows.
   These controls mark replay time, which may be outside the displayed window
   when the two speeds differ; check the annotation bounds before saving.

The annotation editor is available in fullscreen. It uses the same persistent
annotations as the EEG viewer and exports them with the review session.
Annotations created in ICA replay retain the originating model and component
in their JSON metadata. Bounds remain recording-relative seconds.

**Time annotations are global intervals, not component-specific exclusions.**
A `BAD_…` label excludes that time interval from subsequent ICA fitting and
accepted-window PSD. `NOTE` is informational. Neither erases stored samples.
To remove a component contribution, mark it for exclusion and use
**ICA detail → Apply reviewed exclusions**. New quality decisions can make a
previous fit stale; the app asks for a refit before applying a stale model.

Use the header **Annotations** button to review, edit or delete saved intervals.
The EEG viewer also supports **Annotate → drag** and **Exact annotation…**.

## Processing and exports

Each processing operation creates a separate disk-backed stage and retains its
source. Original imported samples remain available. Apply filters and finalize
the reference/channel selection before fitting ICA.

- Filter: fourth-order Butterworth, zero-phase forward/backward, optional 50/60 Hz notch.
- Reference: good-channel average or the explicitly confirmed linked-mastoid option.
  An unchanged average reference is reused.
- ICA: scikit-learn FastICA, seed 97, unit-variance whitening. Fit data exclude
  BAD intervals and persistent bad channels. A private 1 Hz fitting copy is used
  only when an adequate app-recorded high-pass is absent. The source stays unchanged.
- Full-recording screening: two-second amplitude/flatness/RMS checks produce
  review candidates; they do not automatically reject data.
- PSD: accepted four-second Hamming windows, 50% overlap; bad channels and BAD
  spans excluded. Comparison retains the same interval and review rules.
- Export: full selected-stage samples, annotations, bad channels, ICA matrices
  and decisions, stage history, and a Python loader; MNE FIF export is optional.
  TSV and JSON review exports are also available.

Nominal cEEGrid electrode positions are optional and not participant anatomy.
ICA spatial weights use exact channel values with no spatial interpolation.
Use timing, spectrum, and electrode weights together when judging a component.

## Keyboard controls

← / →: previous/next window · Space: replay · A: annotation mode in the current
EEG/all-ICA viewer · Z: EEG range zoom · I: EEG cursor · + / −: EEG sensitivity ·
F: whole-screen EEG/all-ICA viewer · Escape: close dialogs or focus mode.
Shortcuts are disabled while typing or while a modal panel is open.
Replay pauses when the browser tab becomes inactive.

## Verification

See `VALIDATION.md` for the checks run and remaining limits. No participant
recording was supplied for this update. Research review software; not a
clinical diagnostic device.
