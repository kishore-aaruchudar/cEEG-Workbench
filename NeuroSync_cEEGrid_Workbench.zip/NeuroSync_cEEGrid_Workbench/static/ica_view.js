/* All-source inspection and replay share recording time with the EEG viewer. */
function syncReplayControls(){
  const playing=!!S.playing;
  $('play').textContent=playing?'Ⅱ':'▶';
  for(const id of ['ica-play','ica-all-play'])$(id).textContent=playing?'Ⅱ Pause':'▶ Replay';
  for(const id of ['replay-speed','ica-speed','ica-all-speed'])$(id).value=String(S.replaySpeed);
  for(const id of ['window-speed','ica-window-speed','ica-all-window-speed'])if(document.activeElement!==$(id))$(id).value=String(S.windowSpeed);
  if(document.activeElement!==$('ica-all-start'))$('ica-all-start').value=S.start.toFixed(3);
  for(const id of ['window','ica-all-window','ica-window']){
    const select=$(id);
    if(![...select.options].some(o=>Number(o.value)===S.duration)){
      const option=document.createElement('option');option.value=String(S.duration);option.textContent=S.duration.toFixed(2)+' s';select.append(option);
    }
    select.value=String(S.duration);
  }
  const position=S.replayCursor??S.start,status=S.playing?.loading?'Loading':playing?'Replaying':'Paused';
  const outside=S.replayCursor!==null&&(position<S.start||position>Math.min(S.meta?.duration??Infinity,S.start+S.duration));
  const readout=`${status} · replay ${timeLabel(position,true)} · window ${timeLabel(S.start,true)} · ${S.replaySpeed}×${outside?' · replay outside window':''}`;
  $('ica-replay-time').textContent=readout;
  $('ica-all-time').textContent=readout;
  $('wave-replay-time').textContent=readout;
}

// The two rates use the same monotonic wall clock, including time spent fetching.
function advanceReplayClock(state,now){
  if(!S.meta)return;
  const elapsed=Math.max(0,(now-state.last)/1000);
  const available=S.replaySpeed>0?Math.max(0,(S.meta.duration-S.replayCursor)/S.replaySpeed):elapsed;
  const active=Math.min(elapsed,available);
  S.replayCursor=EEGReplay.advance(S.replayCursor,active,S.replaySpeed,S.meta.duration,Infinity).position;
  state.windowPosition=EEGReplay.moveWindow(state.windowPosition,active,S.windowSpeed,S.meta.duration,S.duration);
  state.last=now;
}

function pauseReplay(){
  S.playing=null;
  cancelAnimationFrame(S.playTimer);S.playTimer=null;
  syncReplayControls();
}

async function finishReplay(state){
  if(S.playing!==state)return;
  advanceReplayClock(state,performance.now());
  const target=state.windowPosition;
  pauseReplay();
  // A new request supersedes any in-flight replay fetch, so an older response
  // cannot overwrite the final position after pause or end-of-recording.
  if(Math.abs(target-S.start)>=.5/S.meta.sfreq||state.loading){
    S.start=target;
    await syncWindowAndSources();
  }
  updateLiveFeedback(S.replayCursor);drawOverview();
}

function toggleReplay(){
  if(S.playing)return finishReplay(S.playing).catch(e=>toast(e.message,true));
  if(!S.meta){toast('Open a recording first.');return;}
  if(!['waveforms','ica','ica-all'].includes(S.tab)){toast('Open waveforms or ICA to replay.');return;}
  if(S.tab.startsWith('ica')&&!S.model){toast('Fit or select an ICA model first.');return;}
  if(S.replayCursor===null||S.replayCursor>=S.meta.duration)S.replayCursor=S.start;
  const now=performance.now();S.playing={last:now,loading:false,lastFeedback:0,lastRefresh:0,lastViewed:0,windowPosition:S.start};
  syncReplayControls();
  S.playTimer=requestAnimationFrame(replayTick);
}

function replayTick(){
  const state=S.playing;if(!state)return;
  const now=performance.now();advanceReplayClock(state,now);
  if(S.replayCursor>=S.meta.duration){finishReplay(state).catch(e=>toast(e.message,true));return;}
  // Only one fetch at a time. If rendering is slow, the next request catches
  // up to the current clock position rather than slowing either clock.
  if(!state.loading&&now-state.lastRefresh>=100&&Math.abs(state.windowPosition-S.start)>=.5/S.meta.sfreq){
    S.start=state.windowPosition;state.loading=true;state.lastRefresh=now;
    const markViewed=S.tab==='waveforms'&&now-state.lastViewed>=1000;
    if(markViewed)state.lastViewed=now;
    (async()=>{
      await refreshWindow(markViewed);
      if(S.playing!==state)return;
      if(S.tab==='ica-all')await loadAllComponents();
      else if(S.tab==='ica')await loadComponent();
    })().catch(error=>{if(S.playing===state){pauseReplay();toast(error.message,true);}}).finally(()=>{state.loading=false;});
  }
  if(now-state.lastFeedback>=100){syncReplayControls();updateLiveFeedback(S.replayCursor);state.lastFeedback=now;}
  S.playTimer=requestAnimationFrame(replayTick);
}

async function loadAllComponents(){
  if(S.tab!=='ica-all')return;
  if(!S.model){S.allComponents=null;drawAllComponents();return;}
  const request=++S.allRequest,model=S.model;
  const data=await api('/api/components',null,{project:S.meta.id,model,start:S.start,duration:S.duration});
  if(request!==S.allRequest||S.model!==model)return;
  S.allComponents=data;
  if(S.allFitPending){fitAllComponents(false);S.allFitPending=false;}
  const source=S.meta.stages.find(s=>s.id===data.source)?.label||data.source;
  $('ica-all-summary').textContent=`${data.components.length} source waveforms · Source: ${source} · ${data.start.toFixed(3)}–${data.end.toFixed(3)} s · ${data.display_bucket_samples>1?'Peak-preserving display envelopes':'Full-rate samples'} · source scale: a.u.`;
  drawAllComponents();syncReplayControls();updateLiveFeedback(S.replayCursor??S.start);
}

function fitAllComponents(redraw=true){
  const data=S.allComponents;if(!data){if(redraw)toast('Load an ICA model first.');return;}
  let peak=0;
  for(const stats of data.stats)peak=Math.max(peak,Math.abs(stats.q01-stats.median),Math.abs(stats.q99-stats.median));
  const scales=[.1,.25,.5,1,2,5,10,25,50,100,250,500,1000,5000];
  S.componentGain=scales.find(v=>v>=peak*22/25)||Math.ceil(peak);
  if(![...$('ica-all-gain').options].some(o=>Number(o.value)===S.componentGain)){
    const option=document.createElement('option');option.value=String(S.componentGain);option.textContent=S.componentGain+' a.u./div';$('ica-all-gain').append(option);
  }
  $('ica-all-gain').value=String(S.componentGain);
  if(redraw)drawAllComponents();
}

function drawAllComponents(){
  if(S.tab!=='ica-all')return;
  const data=S.allComponents,n=data?.components.length||4,top=28,bottom=38,left=83;
  const fit=EEGDisplay.layout($('ica-all-scroll').clientHeight || $('ica-all-canvas').parentElement.clientHeight,n,top,bottom,S.icaFitAll),gap=fit.gap,rowPad=Math.min(4,gap*.12);
  const {ctx,width,height}=setupCanvas($('ica-all-canvas'),fit.height);
  ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
  if(!data){ctx.fillStyle='#71808b';ctx.font='12px Segoe UI';ctx.fillText('Fit or select an ICA model to see all source waveforms.',25,60);return;}
  const right=width-20,start=data.start,end=Math.min(S.meta.duration,S.start+S.duration),x=t=>left+(t-start)/(end-start)*(right-left);
  $('ica-all-canvas')._geometry={left,right,top,bottom,height,width,start,end,gap};
  for(let i=0;i<n;i++){ctx.fillStyle=i===S.component?'#eaf4f2':i%2?'#fff':'#fbfdfd';ctx.fillRect(left,top+i*gap,right-left,gap);}
  const tick=niceTimeStep(end-start);
  ctx.font='10px Segoe UI';
  for(let t=Math.ceil(start/tick)*tick;t<=end+tick*1e-6;t+=tick){ctx.strokeStyle='#e8eef0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x(t),top);ctx.lineTo(x(t),height-bottom);ctx.stroke();ctx.fillStyle='#71808b';ctx.textAlign='center';ctx.fillText(t.toFixed(tick<1?2:1),x(t),height-bottom+18);}
  for(const ann of S.meta.annotations){const a=Math.max(start,ann.start),b=Math.min(end,ann.end);if(b<=a)continue;ctx.fillStyle=ann.label.toLowerCase().startsWith('bad')?'#d85d5a18':'#268d8312';ctx.fillRect(x(a),top,x(b)-x(a),height-top-bottom);}
  const draftA=Number($('ann-start').value),draftB=Number($('ann-end').value);
  if($('ann-start').value!==''&&draftB>draftA){const a=Math.max(start,draftA),b=Math.min(end,draftB);if(b>a){ctx.fillStyle='#1c879d20';ctx.fillRect(x(a),top,x(b)-x(a),height-top-bottom);ctx.save();ctx.strokeStyle='#1c879d';ctx.setLineDash([4,3]);ctx.strokeRect(x(a),top,x(b)-x(a),height-top-bottom);ctx.restore();}}
  for(let i=0;i<n;i++){
    const baseline=top+(i+.5)*gap,trace=data.traces[i],median=data.stats[i].median;
    const excluded=S.excluded.has(i),color=excluded?'#c67d78':'#147d78';
    ctx.fillStyle=i===S.component?'#172d3c':'#536873';ctx.textAlign='right';ctx.font=(i===S.component?'bold ':'')+'10px Segoe UI';ctx.fillText(data.components[i]+(excluded?' ×':''),left-10,baseline+3);
    ctx.strokeStyle='#dce6e8';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(left,baseline);ctx.lineTo(right,baseline);ctx.stroke();
    ctx.save();ctx.beginPath();ctx.rect(left,baseline-gap/2+rowPad,right-left,gap-2*rowPad);ctx.clip();ctx.strokeStyle=color;ctx.lineWidth=1;ctx.beginPath();
    for(let j=0;j<trace.x.length;j++){const px=x(trace.x[j]),py=baseline-(trace.y[j]-median)*fit.division/S.componentGain;if(j===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.stroke();ctx.restore();
    let lastMarker=-100;
    for(let j=0;j<trace.x.length;j++){
      const px=x(trace.x[j]),relative=(trace.y[j]-median)*fit.division/S.componentGain;
      if(Math.abs(relative)<=gap/2-rowPad||px-lastMarker<15)continue;
      lastMarker=px;const edge=baseline+(relative>0?-1:1)*(gap/2-rowPad),direction=relative>0?1:-1;
      ctx.fillStyle='#bf8742';ctx.beginPath();ctx.moveTo(px,edge);ctx.lineTo(px-3,edge+Math.min(4,gap*.2)*direction);ctx.lineTo(px+3,edge+Math.min(4,gap*.2)*direction);ctx.closePath();ctx.fill();
    }
  }
  ctx.textAlign='center';ctx.fillStyle='#536873';ctx.font='11px Segoe UI';ctx.fillText('Elapsed recording time (s)',(left+right)/2,height-8);
  ctx.save();ctx.translate(16,(top+height-bottom)/2);ctx.rotate(-Math.PI/2);ctx.fillText('ICA component · amplitude (a.u.)',0,0);ctx.restore();
  ctx.textAlign='right';ctx.font='10px Segoe UI';ctx.fillText(`${S.componentGain} a.u./div · shared gain`,right,17);
  ctx.strokeStyle='#354c58';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(right-5,5);ctx.lineTo(right-5,5+fit.division);ctx.stroke();ctx.textAlign='left';
  $('ica-all-exclude').checked=S.excluded.has(S.component);
}

function updateLiveFeedback(position){
  let trace,stats;
  if(S.allComponents?.info.id===S.model&&Math.abs(S.allComponents.start-S.start)<=1/S.meta.sfreq){trace=S.allComponents.traces[S.component];stats=S.allComponents.stats[S.component];}
  else if(S.componentData?.info.id===S.model&&S.componentData.index===S.component&&Math.abs(S.componentData.trace.x[0]-S.start)<=1/S.meta.sfreq){trace=S.componentData.trace;stats=S.componentData.source_stats;}
  if(!trace||!trace.x.length)return;
  const tolerance=1/S.meta.sfreq;
  if(position<trace.x[0]-tolerance||position>trace.x.at(-1)+tolerance){
    $('ica-live-feedback').textContent=`IC${String(S.component).padStart(3,'0')} · replay ${position.toFixed(3)} s is outside the displayed window · adjust the independent window speed or navigate to the time`;
    return;
  }
  const index=EEGReplay.closestIndex(trace.x,position),value=trace.y[index];
  const text=`IC${String(S.component).padStart(3,'0')} · ${position.toFixed(3)} s · Source ${Number(value).toFixed(3)} a.u.${stats?' · Window RMS '+stats.rms.toFixed(3)+' a.u. · Peak-to-peak '+stats.peak_to_peak.toFixed(3)+' a.u.':''} · ${S.excluded.has(S.component)?'Marked for exclusion':'Retained'}${S.allComponents?.display_bucket_samples>1?' · display-envelope value':''}`;
  $('ica-live-feedback').textContent=text;
}

async function saveComponentExclusion(component,enabled){
  if(!S.model)throw new Error('Fit an ICA model first.');
  const selected=new Set(S.excluded);enabled?selected.add(component):selected.delete(component);
  S.meta=await api('/api/ica-selection',{project:S.meta.id,model:S.model,excluded:[...selected]});
  renderModels();renderLog();drawAllComponents();updateLiveFeedback(S.replayCursor??S.start);
  toast('ICA selection saved. Apply exclusions in ICA detail to create corrected samples.');
}

async function selectIcaModel(id){
  stopPlay();S.model=id;S.component=0;S.allComponents=null;S.componentData=null;S.allFitPending=true;S.icaMarkStart=undefined;S.icaMarkContext=null;
  renderModels();if(S.tab==='ica-all')await loadAllComponents();else await loadComponent();
}

async function syncWindowAndSources(){
  await refreshWindow(S.tab==='waveforms');
  if(S.tab==='ica-all')await loadAllComponents();
  else if(S.tab==='ica')await loadComponent();
}

function niceTimeStep(span){return [0.01,0.02,0.05,.1,.2,.5,1,2,5,10,20,30,60].find(step=>span/step<=9)||120;}
