/* Processing provenance for UI labels. Numerical processing remains in Python. */
const EEGPipeline=(()=>{
  function lineage(meta,id){
    const lookup=new Map(meta.stages.map(s=>[s.id,s])),result=[],seen=new Set();
    while(id!==null&&id!==undefined){
      if(seen.has(id)||!lookup.has(id))throw new Error('Invalid processing lineage.');
      seen.add(id);const stage=lookup.get(id);result.push(stage);id=stage.parent;
    }
    return result.reverse();
  }
  function plan(meta,id){
    const path=lineage(meta,id),filters=path.filter(s=>s.kind==='filtered'),refs=path.filter(s=>s.kind==='reference');
    const highpass=filters.length?Math.max(...filters.map(s=>Number(s.params.highpass_hz))):null;
    const lowpass=filters.length?Math.min(...filters.map(s=>Number(s.params.lowpass_hz))):null;
    const signature=ref=>JSON.stringify([ref.params.mode,ref.params.reference_channels]);
    let duplicates=0;const seen=new Set();
    for(const ref of refs){const sig=signature(ref);if(seen.has(sig))duplicates++;seen.add(sig);}
    return {path,highpass,lowpass,reference:refs.at(-1)?.params||null,additionalHighpass:highpass===null||highpass<1,
      duplicateReferences:duplicates,corrected:path.some(s=>s.kind==='cleaned')};
  }
  function sameAverage(meta,id,mode){
    if(mode!=='average')return false;
    const previous=plan(meta,id).reference;
    const good=meta.channels.filter((n,i)=>meta.channel_types[i]==='eeg'&&!meta.bad_channels.includes(n));
    return !!previous&&previous.mode==='average'&&JSON.stringify(previous.reference_channels)===JSON.stringify(good);
  }
  return {lineage,plan,sameAverage};
})();
if(typeof module==='object'&&module.exports)module.exports=EEGPipeline;
