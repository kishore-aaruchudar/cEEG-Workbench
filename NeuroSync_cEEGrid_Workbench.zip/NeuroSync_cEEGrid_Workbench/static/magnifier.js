/* A detail window shows existing samples or spectral bins in the selected range.
 * It never modifies the processing data or changes the main time window. */
let lensRequest=0, lensData=null, selection=null;
const lens=$('magnifier'), lensCanvas=$('magnifier-canvas');

function setRowLayout(){
  $('wave-scroll').classList.toggle('roomy',!S.waveFitAll);
  document.querySelector('.all-ica-scroll').classList.toggle('roomy',!S.icaFitAll);
  for(const [id,fit] of [['wave-fit-rows',S.waveFitAll],['ica-fit-rows',S.icaFitAll]]){
    const whole=S.wholeScreenBackup?.kind===(id==='wave-fit-rows'?'wave':'ica');
    $(id).disabled=whole;
    $(id).textContent=whole?'All rows visible':fit?'Spaced rows':'Fit rows';
    $(id).setAttribute('aria-pressed',String(fit));
  }
  renderWaves();drawAllComponents();
}
bind('wave-fit-rows','click',()=>{S.waveFitAll=!S.waveFitAll;setRowLayout();});
bind('ica-fit-rows','click',()=>{S.icaFitAll=!S.icaFitAll;setRowLayout();});

function setMagnifyMode(kind,enabled){
  S.magnifyMode=S.magnifyMode||{};S.magnifyMode[kind]=enabled;
  const ids={'ica-all':'ica-all-magnify','spectrum':'spectrum-magnify','ica-detail':'ica-detail-magnify'};
  const button=$(ids[kind]);if(button){button.classList.toggle('active',enabled);button.setAttribute('aria-pressed',String(enabled));}
  if(kind==='ica-all'&&enabled&&S.icaAnnotate)setIcaAnnotationMode(false);
  if(enabled)toast(kind==='spectrum'?'Drag across the frequency range.':'Drag across a trace and time range.');
}
for(const [kind,id] of [['ica-all','ica-all-magnify'],['spectrum','spectrum-magnify'],['ica-detail','ica-detail-magnify']]){
  bind(id,'click',()=>setMagnifyMode(kind,!S.magnifyMode?.[kind]));
}

function changeComponentGain(direction){
  const options=[...$('ica-all-gain').options].map(o=>Number(o.value)).filter(v=>v>0).sort((a,b)=>a-b);
  let index=options.findIndex(v=>v>=S.componentGain);if(index<0)index=options.length-1;
  S.componentGain=options[Math.max(0,Math.min(options.length-1,index+direction))];
  $('ica-all-gain').value=String(S.componentGain);drawAllComponents();
}
$('ica-all-canvas').addEventListener('wheel',event=>{
  if(!S.allComponents||event.ctrlKey||event.metaKey)return;
  event.preventDefault();
  if(event.altKey){$('ica-all-scroll').scrollTop+=event.deltaY;return;}
  if(event.shiftKey){navigate(event.deltaY>0?1:-1);return;}
  changeComponentGain(event.deltaY>0?1:-1);
},{passive:false});

function zoomGeometry(canvas){return canvas._geometry||canvas._lineGeometry;}
function zoomX(canvas,event){
  const g=zoomGeometry(canvas),rect=canvas.getBoundingClientRect();
  const px=Math.max(g.left,Math.min(g.right,event.clientX-rect.left));
  return g.start+(px-g.left)/(g.right-g.left)*(g.end-g.start);
}
function selectionOutline(canvas,event,first){
  const g=zoomGeometry(canvas),r=canvas.getBoundingClientRect(),top=g.plotTop??g.top,bottom=g.plotBottom??(g.height-g.bottom);
  const x=Math.max(g.left,Math.min(g.right,event.clientX-r.left));
  const box=$('magnify-selection');box.style.left=(r.left+Math.min(first,x))+'px';box.style.top=(r.top+top)+'px';
  box.style.width=Math.abs(first-x)+'px';box.style.height=Math.max(0,bottom-top)+'px';box.hidden=false;
}
function lensRange(a,b,minSpan,total){
  a=Math.max(0,Math.min(total,a));b=Math.max(0,Math.min(total,b));
  if(b<a)[a,b]=[b,a];
  if(b-a<minSpan){const middle=(a+b)/2;a=Math.max(0,middle-minSpan/2);b=Math.min(total,a+minSpan);a=Math.max(0,b-minSpan);}
  return [a,b];
}
function dataForCanvas(canvas){
  if(canvas.id==='wave-main')return {kind:'wave',data:S.main,stage:S.stage};
  if(canvas.id==='wave-compare')return {kind:'wave',data:S.comparison,stage:S.compareStage};
  if(canvas.id==='ica-all-canvas')return {kind:'ica',data:S.allComponents};
  if(canvas.id==='psd-canvas')return {kind:'spectrum',data:S.psd};
  if(canvas.id==='component-trace')return {kind:'ica-detail',data:S.componentData};
  return {kind:'ica-spectrum',data:S.componentData};
}
function magnifyEnabled(canvas){
  if(canvas.id==='wave-main'||canvas.id==='wave-compare')return S.mode==='magnify';
  if(canvas.id==='ica-all-canvas')return !!S.magnifyMode?.['ica-all'];
  if(canvas.id==='psd-canvas')return !!S.magnifyMode?.spectrum;
  return !!S.magnifyMode?.['ica-detail'];
}
const outline=document.createElement('div');outline.id='magnify-selection';outline.hidden=true;document.body.append(outline);
for(const id of ['wave-main','wave-compare','ica-all-canvas','psd-canvas','component-trace','component-spectrum']){
  const canvas=$(id);
  canvas.addEventListener('pointerdown',event=>{
    if(!magnifyEnabled(canvas))return;
    const info=dataForCanvas(canvas),g=zoomGeometry(canvas),rect=canvas.getBoundingClientRect();
    if(!info.data||!g){toast('Load or calculate this plot first.');return;}
    const px=event.clientX-rect.left,py=event.clientY-rect.top,top=g.plotTop??g.top,bottom=g.plotBottom??(g.height-g.bottom);
    if(px<g.left||px>g.right||py<top||py>bottom)return;
    let row=0;
    if(info.kind==='wave'||info.kind==='ica'){
      row=Math.floor((py-g.top)/g.gap);
      const length=info.kind==='wave'?info.data.channels.length:info.data.components.length;
      if(row<0||row>=length)return;
    }
    event.preventDefault();event.stopImmediatePropagation();stopPlay();
    // Selection overlay must be inside the full-screen element to remain visible.
    const host=canvas.closest('.card');host.append(outline);
    if(info.kind==='ica')S.suppressIcaClick=true;
    selection={canvas,info,row,x:zoomX(canvas,event),px,id:event.pointerId,project:S.meta.id,model:S.model,component:S.component};
    canvas.setPointerCapture(event.pointerId);selectionOutline(canvas,event,px);
  },true);
  canvas.addEventListener('pointermove',event=>{
    if(selection?.canvas!==canvas)return;
    event.preventDefault();event.stopImmediatePropagation();selectionOutline(canvas,event,selection.px);
  },true);
  canvas.addEventListener('pointerup',event=>{
    if(selection?.canvas!==canvas)return;
    event.preventDefault();event.stopImmediatePropagation();
    const chosen=selection;selection=null;outline.hidden=true;
    if(chosen.info.kind==='ica')setTimeout(()=>{S.suppressIcaClick=false;},0);
    if(canvas.hasPointerCapture(event.pointerId))canvas.releasePointerCapture(event.pointerId);
    const other=zoomX(canvas,event);
    if(Math.abs(event.clientX-canvas.getBoundingClientRect().left-chosen.px)<4){toast('Drag across a range to open the magnifier.');return;}
    showMagnified(chosen,Math.min(chosen.x,other),Math.max(chosen.x,other)).catch(e=>toast(e.message,true));
  },true);
  canvas.addEventListener('pointercancel',()=>{if(selection?.canvas===canvas){selection=null;outline.hidden=true;S.suppressIcaClick=false;}},true);
}

async function showMagnified(chosen,a,b){
  const seq=++lensRequest,host=chosen.canvas.closest('.card'),kind=chosen.info.kind;
  let series=[],title='',unit='',xLabel='',note='',range=[a,b];
  if(kind==='wave'||kind==='ica'||kind==='ica-detail'){
    const isWave=kind==='wave',minimum=Math.max(isWave ? 0.05 : 0.1,(isWave?2:4)/S.meta.sfreq+.001);
    range=lensRange(a,b,minimum,S.meta.duration);[a,b]=range;
    const duration=Math.min(120,b-a+1/S.meta.sfreq);
    if(isWave){
      const name=chosen.info.data.channels[chosen.row],stage=chosen.info.stage;
      const response=await api('/api/window',null,{project:chosen.project,stage,start:a,duration,channels:[name]});
      const label=S.meta.stages.find(s=>s.id===stage)?.label||stage;
      title=`${name} – ${label}`;series=[{...response.traces[0],color:chosen.canvas.id==='wave-compare'?'#527296':'#147d78',label:name}];unit='Amplitude (µV)';
      note=response.display_bucket_samples>1?'Peak-preserving sample envelope':'Full-rate samples';
    }else{
      const component=kind==='ica'?chosen.row:chosen.component;
      const response=await api('/api/component',null,{project:chosen.project,model:chosen.model,component,start:a,duration});
      title=`IC${String(component).padStart(3,'0')} – source`;series=[{...response.trace,color:'#147d78',label:'ICA source'}];unit='Amplitude (a.u.)';
      note='Source values from fitted ICA model';
    }
    xLabel='Recording time (s)';
  }else{
    if(kind==='spectrum'){
      series=[S.psd,S.psdCompare].filter(Boolean).map((p,i)=>({x:p.frequencies,y:p.mean_db,color:i?'#527296':'#147d78',label:p.label}));
      title='Power spectrum';unit='PSD (dB re 1 µV²/Hz)';
    }else{
      series=[{x:S.componentData.frequencies,y:S.componentData.psd_db,color:'#527296',label:'ICA source PSD'}];
      title=`IC${String(chosen.component).padStart(3,'0')} – spectrum`;unit='PSD (dB re 1 a.u.²/Hz)';
    }
    xLabel='Frequency (Hz)';
    const spacing=series[0]?.x.length>1?series[0].x[1]-series[0].x[0]:null;
    note=spacing?`Existing spectrum bins · ${spacing.toPrecision(3)} Hz spacing`:'Existing spectrum bins';
  }
  if(seq!==lensRequest||S.meta.id!==chosen.project)return;
  series=series.map(s=>{
    const x=[],y=[];for(let i=0;i<s.x.length;i++)if(s.x[i]>=a&&s.x[i]<=b&&Number.isFinite(s.y[i])){x.push(s.x[i]);y.push(s.y[i]);}
    return {...s,x,y};
  });
  if(!series.some(s=>s.x.length)){toast('No samples or spectrum bins in this range. Select a wider range.');return;}
  lensData={series,range:[a,b],xLabel,unit};
  host.append(lens);lens.style.left='';lens.style.right='12px';lens.style.top='58px';lens.hidden=false;
  $('magnifier-title').textContent=title;
  $('magnifier-subtitle').textContent=`${a.toFixed(kind.includes('spectrum')?2:3)} – ${b.toFixed(kind.includes('spectrum')?2:3)} ${kind.includes('spectrum')?'Hz':'s'}`;
  $('magnifier-note').innerHTML=esc(note)+'<span class="magnifier-legend">'+series.map(s=>`<span><i style="background:${s.color}"></i>${esc(s.label)}</span>`).join('')+'</span>';
  requestAnimationFrame(drawMagnifier);
}
function axisNumber(n,span){
  if(Math.abs(n)>99999||(n!==0&&Math.abs(n)<.0001))return n.toExponential(2);
  const digits=Math.min(6,Math.max(0,Math.ceil(-Math.log10(Math.abs(span)||1))+1));
  return n.toFixed(digits);
}
function drawMagnifier(){
  if(lens.hidden||!lensData)return;
  const {series,range,xLabel,unit}=lensData,{ctx,width,height}=setupCanvas(lensCanvas,170);
  const left=70,right=width-18,top=12,bottom=height-38,values=series.flatMap(s=>s.y).filter(Number.isFinite);
  let lo=Math.min(...values),hi=Math.max(...values),pad=(hi-lo)*.1||Math.max(.1,Math.abs(lo)*.1);lo-=pad;hi+=pad;
  const x=v=>left+(v-range[0])/(range[1]-range[0]||1)*(right-left),y=v=>bottom-(v-lo)/(hi-lo)*(bottom-top);
  ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);ctx.font='10px system-ui';
  for(let i=0;i<=4;i++){
    const xx=left+(right-left)*i/4,yy=bottom-(bottom-top)*i/4;
    ctx.strokeStyle='#edf0f2';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(right,yy);ctx.stroke();
    ctx.fillStyle='#64727a';ctx.textAlign='center';ctx.fillText(axisNumber(range[0]+(range[1]-range[0])*i/4,range[1]-range[0]),xx,bottom+14);
    ctx.textAlign='right';ctx.fillText(axisNumber(lo+(hi-lo)*i/4,hi-lo),left-6,yy+3);
  }
  for(const s of series){
    ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineWidth=1.3;ctx.beginPath();
    for(let i=0;i<s.x.length;i++)i?ctx.lineTo(x(s.x[i]),y(s.y[i])):ctx.moveTo(x(s.x[i]),y(s.y[i]));ctx.stroke();
    if(s.x.length<20)for(let i=0;i<s.x.length;i++){ctx.beginPath();ctx.arc(x(s.x[i]),y(s.y[i]),2.4,0,2*Math.PI);ctx.fill();}
  }
  ctx.fillStyle='#52626b';ctx.textAlign='center';ctx.fillText(xLabel,(left+right)/2,height-4);
  ctx.save();ctx.translate(12,(top+bottom)/2);ctx.rotate(-Math.PI/2);ctx.fillText(unit,0,0);ctx.restore();
}
bind('magnifier-close','click',()=>{lensRequest++;lens.hidden=true;lensData=null;});
// Drag the small detail window by its title bar; clamp it inside its host.
$('magnifier-handle').addEventListener('pointerdown',event=>{
  if(event.target.closest('button'))return;
  const host=lens.parentElement,r=host.getBoundingClientRect(),lr=lens.getBoundingClientRect();
  const dx=event.clientX-lr.left,dy=event.clientY-lr.top;event.preventDefault();
  $('magnifier-handle').setPointerCapture(event.pointerId);
  const move=e=>{
    lens.style.right='auto';lens.style.left=Math.max(0,Math.min(r.width-lr.width,e.clientX-r.left-dx))+'px';
    lens.style.top=Math.max(0,Math.min(r.height-lr.height,e.clientY-r.top-dy))+'px';
  };
  const done=()=>{$('magnifier-handle').removeEventListener('pointermove',move);$('magnifier-handle').removeEventListener('pointerup',done);$('magnifier-handle').removeEventListener('pointercancel',done);};
  $('magnifier-handle').addEventListener('pointermove',move);$('magnifier-handle').addEventListener('pointerup',done);$('magnifier-handle').addEventListener('pointercancel',done);
});
new ResizeObserver(()=>{if(!lens.hidden)requestAnimationFrame(drawMagnifier);}).observe(lens);
setRowLayout();
