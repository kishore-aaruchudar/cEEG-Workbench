/* Screen-sized workspaces and a shared, persistent time-annotation editor. */
function redrawWorkspace(){
  const active=document.fullscreenElement||document.querySelector('.focus-fallback');
  for(const [id,selector] of [['fullscreen','.signal-card'],['spectrum-fullscreen','.spectrum-card'],['ica-all-fullscreen','.all-ica-card'],['ica-detail-fullscreen','#tab-ica>.card']]){
    const on=active===document.querySelector(selector);$(id).setAttribute('aria-pressed',String(on));
    $(id).textContent=on?'Exit whole screen':'Whole screen';
  }
  renderWaves();drawOverview();drawPSD();drawAllComponents();
  if(S.tab==='ica'&&S.componentData){
    renderComponentDetails(S.componentData);
  }
  syncReplayControls();
}

function openPanel(id){
  const panel=$(id),host=document.fullscreenElement||document.querySelector('.focus-fallback');
  stopPlay();
  if(host)host.append(panel);
  if(!panel.open)panel.showModal();
}

function openAnnotationDialog(view='waveforms',context=null){
  if(!S.meta){toast('Open a recording first.');return;}
  S.annotationContext=context||(view==='ica-all'?{view,model:S.model,component:S.component}:{view:'waveforms'});
  $('annotation-context').textContent=view==='ica-all'?`ICA${String(S.component).padStart(3,'0')} · recording time annotation`:'Recording time annotations';
  openPanel('annotation-dialog');
  // A time annotation applies to the recording, while a component exclusion is a separate decision.
  $('annotation-dialog').querySelector('.annotation-editor>.hint').textContent='Saved time spans appear on EEG and ICA plots. BAD labels exclude this interval from later fitting and PSD; they do not exclude a component.';
  requestAnimationFrame(()=>$('ann-label').focus());
}

async function toggleViewerFullscreen(viewer){
  if(!viewer)return;
  if(document.fullscreenElement){await document.exitFullscreen();restoreWholeScreen();}
  else if(viewer.classList.contains('focus-fallback')){viewer.classList.remove('focus-fallback');restoreWholeScreen();}
  else{
    if(viewer.classList.contains('signal-card')){
      S.wholeScreenBackup={kind:'wave',selected:[...S.selected],hideBads:$('hide-bads').checked,fit:S.waveFitAll};
      const eeg=S.meta.channels.filter((name,i)=>S.meta.channel_types[i]==='eeg');
      S.selected=eeg.slice(0,64);$('hide-bads').checked=false;S.waveFitAll=true;renderChannels();setRowLayout();
      await refreshWindow(false);
      if(eeg.length>64)toast('Whole screen shows the first 64 EEG channels. Choose other channels in Display options.');
    }else if(viewer.classList.contains('all-ica-card')){
      S.wholeScreenBackup={kind:'ica',fit:S.icaFitAll};S.icaFitAll=true;setRowLayout();
    }
    try{
      if(!viewer.requestFullscreen)throw new Error('Fullscreen unavailable');
      await viewer.requestFullscreen();
    }catch(_){viewer.classList.add('focus-fallback');}
  }
  requestAnimationFrame(redrawWorkspace);
}

function restoreWholeScreen(){
  const backup=S.wholeScreenBackup;if(!backup)return;
  S.wholeScreenBackup=null;
  if(backup.kind==='wave'){
    S.waveFitAll=backup.fit;S.selected=backup.selected;$('hide-bads').checked=backup.hideBads;
    renderChannels();refreshWindow(false).catch(e=>toast(e.message,true));
  }else S.icaFitAll=backup.fit;
  setRowLayout();
}

function setIcaAnnotationMode(enabled){
  S.icaAnnotate=enabled;
  if(enabled&&typeof setMagnifyMode==='function')setMagnifyMode('ica-all',false);
  if(enabled)stopPlay();
  $('ica-all-annotate').setAttribute('aria-pressed',String(enabled));
  $('ica-all-annotate').textContent=enabled?'Annotate: drag a range':'Annotate';
  $('ica-all-canvas').style.cursor=enabled?'crosshair':'default';
}

bind('workspace-button','click',()=>openPanel('workspace-dialog'));
bind('annotations-button','click',()=>openAnnotationDialog(S.tab==='ica-all'?'ica-all':'waveforms'));
bind('wave-annotate','click',()=>openAnnotationDialog());
bind('display-settings-button','click',()=>openPanel('display-dialog'));
bind('spectrum-fullscreen','click',()=>toggleViewerFullscreen(document.querySelector('.spectrum-card')));
bind('ica-all-fullscreen','click',()=>toggleViewerFullscreen(document.querySelector('.all-ica-card')));
bind('ica-detail-fullscreen','click',()=>toggleViewerFullscreen(document.querySelector('#tab-ica>.card')));
function setIcaDetailView(view,chosen=false){
  S.icaDetailView=view;if(chosen)S.icaDetailUserChoice=true;
  $('ica-source-panel').hidden=view==='weights';$('ica-map-panel').hidden=view==='source';
  document.querySelector('.ica-grid').dataset.view=view;
  for(const name of ['both','source','weights'])$('detail-view-'+name).setAttribute('aria-pressed',String(name===view));
  requestAnimationFrame(()=>{if(S.tab==='ica'&&S.componentData){renderComponentDetails(S.componentData);syncReplayControls();}});
}
for(const name of ['both','source','weights'])bind('detail-view-'+name,'click',()=>setIcaDetailView(name,true));
bind('ica-timeline-toggle','click',()=>{
  S.showTimelineInDetail=!S.showTimelineInDetail;
  document.body.classList.toggle('ica-detail-focus',!S.showTimelineInDetail);
  $('ica-timeline-toggle').textContent=S.showTimelineInDetail?'Hide timeline':'Show timeline';
  requestAnimationFrame(redrawWorkspace);
});
function setAutomaticIcaDetailView(){
  if(!S.icaDetailUserChoice)setIcaDetailView(window.innerWidth<=850?'source':'both');
}
setAutomaticIcaDetailView();
window.addEventListener('resize',setAutomaticIcaDetailView);
bind('ica-all-annotate','click',()=>setIcaAnnotationMode(!S.icaAnnotate));
bind('ica-all-annotations','click',()=>openAnnotationDialog('ica-all'));
bind('fit-ica','click',()=>{if($('workspace-dialog').open)$('workspace-dialog').close();});
bind('ica-mark-start','click',()=>{
  if(!S.model){toast('Fit or select an ICA model first.');return;}
  S.icaMarkStart=S.replayCursor??S.start;
  S.icaMarkContext={view:'ica-all',model:S.model,component:S.component};
  const outside=S.icaMarkStart<S.start||S.icaMarkStart>Math.min(S.meta.duration,S.start+S.duration);
  $('ica-mark-status').textContent=`Replay start marked at ${S.icaMarkStart.toFixed(3)} s${outside?' (outside the displayed window)':''}. Replay, then mark the end.`;
});
bind('ica-mark-end','click',()=>{
  if(S.icaMarkStart===undefined){toast('Mark a start at the replay time first.');return;}
  const end=S.replayCursor??S.start;
  if(end<=S.icaMarkStart){toast('Advance replay past the marked start.');return;}
  stopPlay();clearAnnotation();
  $('ann-start').value=S.icaMarkStart.toFixed(3);$('ann-end').value=end.toFixed(3);
  openAnnotationDialog('ica-all',S.icaMarkContext);drawAllComponents();
  delete S.icaMarkStart;delete S.icaMarkContext;
  $('ica-mark-status').textContent='Time annotations apply across all stages.';
});

const icaCanvas=$('ica-all-canvas');
icaCanvas.addEventListener('pointerdown',event=>{
  if(!S.icaAnnotate||!S.allComponents||!icaCanvas._geometry)return;
  const g=icaCanvas._geometry,r=icaCanvas.getBoundingClientRect();
  if(event.clientX-r.left<g.left||event.clientY-r.top<g.top||event.clientY-r.top>g.height-g.bottom)return;
  stopPlay();S.annId=null;S.suppressIcaClick=true;
  S.icaDrag={start:pointerTime(icaCanvas,event),id:event.pointerId};
  S.component=Math.min(S.allComponents.components.length-1,Math.max(0,Math.floor((event.clientY-r.top-g.top)/g.gap)));
  icaCanvas.setPointerCapture(event.pointerId);
});
icaCanvas.addEventListener('pointermove',event=>{
  if(!S.icaDrag)return;
  const t=pointerTime(icaCanvas,event);
  $('ann-start').value=Math.min(S.icaDrag.start,t).toFixed(3);
  $('ann-end').value=Math.max(S.icaDrag.start,t).toFixed(3);
  drawAllComponents();
});
icaCanvas.addEventListener('pointerup',event=>{
  if(!S.icaDrag)return;
  const t=pointerTime(icaCanvas,event),a=Math.min(S.icaDrag.start,t),b=Math.max(S.icaDrag.start,t);
  S.icaDrag=null;
  if(icaCanvas.hasPointerCapture(event.pointerId))icaCanvas.releasePointerCapture(event.pointerId);
  setTimeout(()=>{S.suppressIcaClick=false;},0);
  if(b-a<1/S.meta.sfreq)return;
  $('ann-start').value=a.toFixed(3);$('ann-end').value=b.toFixed(3);
  renderModels();drawAllComponents();openAnnotationDialog('ica-all');
});
icaCanvas.addEventListener('pointercancel',()=>{S.icaDrag=null;S.suppressIcaClick=false;});

document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
for(const panel of document.querySelectorAll('dialog')){
  panel.addEventListener('close',()=>{
    document.body.append(panel);
    if(panel.id==='annotation-dialog')clearAnnotation();
    requestAnimationFrame(redrawWorkspace);
  });
  panel.addEventListener('click',event=>{
    const r=panel.getBoundingClientRect();
    if(event.target===panel&&(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom))panel.close();
  });
}
// Only one primary processing group is expanded at a time.
for(const details of document.querySelectorAll('.sidebar>details'))details.addEventListener('toggle',()=>{
  if(details.open)for(const peer of document.querySelectorAll('.sidebar>details'))if(peer!==details)peer.open=false;
});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'){
    document.querySelectorAll('.focus-fallback').forEach(el=>el.classList.remove('focus-fallback'));
    restoreWholeScreen();
    if(!document.querySelector('dialog[open]')){setIcaAnnotationMode(false);clearAnnotation();}
    requestAnimationFrame(redrawWorkspace);
  }
});
for(const el of document.querySelectorAll('.wave-scroll,.all-ica-scroll,.ica-grid,.spectrum-card,.component-frame')){
  new ResizeObserver(()=>{cancelAnimationFrame(el._redraw);el._redraw=requestAnimationFrame(redrawWorkspace);}).observe(el);
}
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)restoreWholeScreen();});
