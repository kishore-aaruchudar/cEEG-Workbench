/* Replay advances recorded seconds by wall-clock elapsed seconds × speed. */
const EEGReplay=(()=>{
  function advance(cursor,elapsed,speed,duration,windowEnd){
    const position=Math.min(duration,Math.max(0,cursor+Math.max(0,elapsed)*speed));
    return {position,ended:position>=duration,needsWindow:position>=windowEnd&&position<duration};
  }
  function windowStart(position, recordingDuration, windowDuration){
    return Math.max(0,Math.min(position,Math.max(0,recordingDuration-windowDuration)));
  }
  function moveWindow(position,elapsed,speed,recordingDuration,windowDuration){
    return windowStart(position+Math.max(0,elapsed)*Math.max(0,speed),recordingDuration,windowDuration);
  }
  function closestIndex(times,time){
    if(!times.length)return -1;
    let a=0,b=times.length-1;
    while(a<b){const mid=(a+b)>>1;if(times[mid]<time)a=mid+1;else b=mid;}
    return a>0&&Math.abs(times[a-1]-time)<Math.abs(times[a]-time)?a-1:a;
  }
  return {advance,windowStart,moveWindow,closestIndex};
})();
if(typeof module==='object'&&module.exports)module.exports=EEGReplay;
