/* Display-only geometry. Never changes stored samples or per-channel gains. */
const EEGDisplay = (() => {
  const scales = [.1,.2,.5,1,2,5,10,20,30,50,100,200,500,1000,2000,5000,10000,20000,50000,100000];
  function center(stats, trace, enabled) {
    if (!enabled) return 0;
    if (Number.isFinite(stats?.median_uv)) return stats.median_uv;
    const values=(trace?.y||[]).filter(Number.isFinite).sort((a,b)=>a-b);
    if (!values.length) return 0;
    const mid=Math.floor(values.length/2);
    return values.length%2 ? values[mid] : (values[mid-1]+values[mid])/2;
  }
  function pixel(value, baseline, sensitivity, offset=0, division=22) {
    return baseline-(value-offset)*division/sensitivity;
  }
  function layout(available,count,top=28,bottom=40,fitAll=true) {
    const usable=Number(available)||360;
    const height=Math.max(top+bottom+24,usable,fitAll?0:top+bottom+Math.max(1,count)*40);
    const gap=(height-top-bottom)/Math.max(1,count);
    return {height,gap,division:Math.min(22,gap*.32),top,bottom};
  }
  function fit(panes, centered=true) {
    let peak=0;
    for(const pane of panes.filter(Boolean)){
      for(let i=0;i<pane.traces.length;i++){
        const stats=pane.stats?.[i], offset=center(stats,pane.traces[i],centered);
        if(Number.isFinite(stats?.q01_uv)&&Number.isFinite(stats?.q99_uv)){
          peak=Math.max(peak,Math.abs(stats.q01_uv-offset),Math.abs(stats.q99_uv-offset));
        } else {
          const values=pane.traces[i].y.filter(Number.isFinite).map(v=>Math.abs(v-offset)).sort((a,b)=>a-b);
          if(values.length)peak=Math.max(peak,values[Math.floor((values.length-1)*.99)]);
        }
      }
    }
    if(peak<1e-10)return 5;
    const target=peak*22/27;
    return scales.find(value=>value>=target) || Math.ceil(target/10000)*10000;
  }
  function status(pane, centered, sensitivity, gap=68, division=22) {
    const stats=pane?.stats||[];
    return {
      invalid:stats.filter(s=>!s.finite_samples).map(s=>s.channel),
      nearFlat:stats.filter(s=>s.finite_samples&&s.max_uv-s.min_uv<.01).map(s=>s.channel),
      clipped:stats.filter((s,i)=>s.finite_samples && Math.max(
        Math.abs(s.min_uv-center(s,pane.traces[i],centered)),
        Math.abs(s.max_uv-center(s,pane.traces[i],centered))) *division/sensitivity>gap/2-Math.min(4,gap*.12)).map(s=>s.channel),
    };
  }
  return {scales,center,pixel,fit,status,layout};
})();
if(typeof module==='object'&&module.exports)module.exports=EEGDisplay;
