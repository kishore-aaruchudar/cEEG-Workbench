'use strict';

const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const S = {token:'', meta:null, stage:'raw', compareStage:'raw', selected:[], start:0, duration:10,
  sensitivity:30, mode:'inspect', main:null, comparison:null, overview:null, tab:'waveforms',
  annId:null, added:[], request:0, model:null, component:0, componentData:null, excluded:new Set(),
  psd:null, psdCompare:null, spectrumStage:null, spectrumCompareStage:null, busy:false, playing:null, playTimer:null, drag:null, autoFitPending:false,
  allComponents:null, allRequest:0, componentRequest:0, componentGain:1, allFitPending:true,
  replayCursor:null, replaySpeed:1, windowSpeed:1, waveFitAll:false, icaFitAll:false};
let toastTimer;

function toast(message, error=false) {
  $('toast').textContent = message;
  $('toast').classList.toggle('error', error);
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').hidden = true, error ? 12000 : 4500);
}

async function api(route, body=null, query={}) {
  const parameters = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null) parameters.set(key, typeof value === 'object' ? JSON.stringify(value) : value);
  }
  const response = await fetch(route + (parameters.size ? '?' + parameters : ''), {
    method:body === null ? 'GET' : 'POST',
    headers:body === null ? {} : {'Content-Type':'application/json', 'X-Echo-Token':S.token},
    body:body === null ? undefined : JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'The request failed.');
  return result;
}

function bind(id, event, fn) {
  $(id).addEventListener(event, e => Promise.resolve().then(() => fn(e)).catch(error => toast(error.message, true)));
}

function timeLabel(seconds, detailed=false) {
  const h = Math.floor(seconds/3600), m = Math.floor(seconds/60)%60, s = Math.floor(seconds)%60;
  return (h ? String(h).padStart(2,'0')+':' : '') + String(m).padStart(2,'0')+':' + String(s).padStart(2,'0') + (detailed ? '.'+String(Math.round((seconds%1)*1000)).padStart(3,'0') : '');
}

function setBusy(busy, label='Processing') {
  S.busy = busy;
  $('job-banner').hidden = !busy;
  $('job-label').textContent = label;
  for (const id of ['import-path','filter','reference','fit-ica','screen','apply-ica','export-review','export-fif','compute-psd','psd-stage','psd-compare','psd-compare-stage','psd-range']) {
    $(id).disabled = busy || (!S.meta && id!=='import-path');
  }
  $('upload').disabled = busy;
  const model=S.meta?.ica_models.find(m=>m.id===S.model);
  $('apply-ica').disabled=busy||!model||!model.converged||!S.excluded.size||model.quality_revision!==S.meta.quality_revision;
  const sameReference=S.meta&&EEGPipeline.sameAverage(S.meta,S.stage,$('reference-mode').value);
  $('reference').disabled=busy||!S.meta||sameReference;
  $('reference').textContent=sameReference?'Average reference already applied':'Create reference stage';
}

async function finishJob(job) {
  setBusy(true, job.label);
  try {
    while (job.status === 'queued' || job.status === 'running') {
      await new Promise(resolve => setTimeout(resolve, 700));
      job = await api('/api/job', null, {id:job.id});
    }
    if (job.status === 'error') throw new Error(job.error);
    return job.result;
  } finally { setBusy(false); }
}

async function runJob(route, payload={}, after=null) {
  if (S.busy) throw new Error('Wait for the current processing job to finish.');
  setBusy(true, 'Starting…');
  try {
    const job = await api(route, payload);
    const result = await finishJob(job);
    if (result.project) await openSession(result.project);
    else if (S.meta) {
      await refreshMeta();
      if (result.stage) { S.stage=result.stage; syncStages(); await refreshWindow(); await loadOverview(); }
      if (result.model) { S.model=result.model; S.allComponents=null; S.allFitPending=true; renderModels(); selectTab('ica-all'); await loadAllComponents(); }
    }
    if (after) await after(result);
    if(result.reused)toast('This stage already has the same average reference. No additional reference was applied.');
    return result;
  } catch (error) { setBusy(false); throw error; }
}

async function listSessions() {
  const sessions = await api('/api/sessions');
  $('session-picker').innerHTML = '<option value="">Open a session…</option>' + sessions.map(m => `<option value="${m.id}">${esc(m.name)} · ${timeLabel(m.duration)}</option>`).join('');
  if (S.meta) $('session-picker').value = S.meta.id;
}

async function openSession(id) {
  stopPlay();
  if($('workspace-dialog').open)$('workspace-dialog').close();
  S.icaMarkStart=undefined;S.icaMarkContext=null;
  S.meta = await api('/api/session', null, {project:id});
  const saved = JSON.parse(localStorage.getItem('echo-view-'+id) || '{}');
  S.stage = S.meta.stages.some(s => s.id===saved.stage) ? saved.stage : S.meta.stages.at(-1).id;
  S.compareStage = S.meta.stages[0].id;
  S.spectrumStage=S.stage;S.spectrumCompareStage=S.compareStage;
  $('psd-compare').checked=false;$('psd-compare-label').hidden=true;
  S.start = Math.max(0, Math.min(saved.start || 0, S.meta.duration-.05));
  S.duration = saved.duration || 10;
  S.sensitivity = saved.sensitivity || 30;
  S.windowSpeed = Number.isFinite(saved.windowSpeed) && saved.windowSpeed >= 0 && saved.windowSpeed <= 100 ? saved.windowSpeed : 1;
  $('center-traces').checked = saved.centered !== false;
  $('clip-rows').checked = saved.clipRows !== false;
  S.autoFitPending = saved.display_version !== 2;
  setSensitivity(S.sensitivity);
  S.selected = S.meta.channels.filter((n,i) => S.meta.channel_types[i]==='eeg').slice(0,64);
  if (!S.selected.length) S.selected = S.meta.channels.slice(0,64);
  S.main=null; S.comparison=null; S.overview=null; S.psd=null; S.psdCompare=null;
  $('bandpower-table').innerHTML='';$('psd-summary').textContent='Choose a stage and calculate PSD. Comparison uses the same interval and review exclusions.';
  S.model=S.meta.ica_models.at(-1)?.id || null; S.component=0; S.componentData=null; S.added=[];
  S.allComponents=null;S.allFitPending=true;S.replayCursor=null;
  clearAnnotation();
  $('welcome').hidden=true; $('workbench').hidden=false;
  $('start').value=S.start.toFixed(3); $('window').value=String(S.duration); $('sensitivity').value=String(S.sensitivity);
  $('compare').checked=false; $('compare-panel').hidden=true; $('compare-label').hidden=true;
  $('secondary-legend').hidden=true;
  localStorage.setItem('echo-project',id);
  await listSessions();
  renderMeta(); selectTab('waveforms');
  await Promise.all([refreshWindow(), loadOverview()]);
  toast('Session opened. Review decisions autosave.');
}

async function refreshMeta() {
  if (!S.meta) return;
  S.meta=await api('/api/session', null, {project:S.meta.id});
  renderMeta();
}

function renderMeta() {
  const m=S.meta;
  if (!m) return;
  $('session-name').textContent=m.name;
  $('recording-title').textContent=m.name;
  $('duration-stat').textContent=timeLabel(m.duration);
  $('channel-stat').textContent=m.channels.length;
  $('annotation-stat').textContent=m.annotations.length;
  $('header-annotation-count').textContent=m.annotations.length;
  $('annotation-count').textContent=m.annotations.length;
  $('overview-end').textContent=timeLabel(m.duration);
  const viewed=m.viewed.reduce((sum,[a,b])=>sum+b-a,0);
  $('viewed-stat').textContent=`Time windows viewed: ${(100*viewed/m.duration).toFixed(1)}%`;
  $('recording-info').innerHTML=`<div><span>Sampling rate</span><b>${m.sfreq} Hz</b></div><div><span>Samples / channel</span><b>${m.n_samples.toLocaleString()}</b></div><div><span>Duration</span><b>${m.duration.toFixed(3)} s</b></div><div><span>Bad channels</span><b>${m.bad_channels.length}</b></div><p>${esc(m.position_provenance)}</p>`;
  syncStages(); renderChannels(); renderAnnotations(); renderQueue(); renderModels(); renderLog();
  document.querySelectorAll('[data-recording]').forEach(b=>b.disabled=false);
  setBusy(S.busy, $('job-label').textContent);
  drawOverview();
}

function syncStages() {
  if (!S.meta) return;
  const duplicateLabels=new Map();for(const s of S.meta.stages)duplicateLabels.set(s.label,(duplicateLabels.get(s.label)||0)+1);
  const stageName=s=>s.label+(duplicateLabels.get(s.label)>1?' ['+s.id.slice(-4)+']':'');
  const opts=S.meta.stages.map(s=>`<option value="${s.id}">${esc(stageName(s))}</option>`).join('');
  $('stage').innerHTML=opts; $('compare-stage').innerHTML=opts;
  $('psd-stage').innerHTML=opts; $('psd-compare-stage').innerHTML=opts;
  if(!S.meta.stages.some(s=>s.id===S.spectrumStage))S.spectrumStage=S.stage;
  if(!S.meta.stages.some(s=>s.id===S.spectrumCompareStage))S.spectrumCompareStage=S.compareStage;
  $('psd-stage').value=S.spectrumStage; $('psd-compare-stage').value=S.spectrumCompareStage;
  $('stage').value=S.stage; $('compare-stage').value=S.compareStage;
  const plan=EEGPipeline.plan(S.meta,S.stage),path=plan.path;
  $('history').innerHTML=path.map((s,i)=>`${i?'<span class="arrow">→</span>':''}<button data-stage="${s.id}" class="${s.id===S.stage?'active':''}" title="Source: ${esc(s.parent || 'original')}">${esc(stageName(s))}</button>`).join('');
  $('history').querySelectorAll('button').forEach(b=>b.onclick=()=>changeStage(b.dataset.stage).catch(e=>toast(e.message,true)));
  const other=S.meta.stages.length-path.length;
  $('other-stages-note').textContent=other?`${other} other saved stage${other===1?'':'s'} available in the Stage selector`:'';
  const passband=plan.highpass===null?'No app-recorded filter in this lineage':`Known app passband: ${plan.highpass}–${plan.lowpass} Hz`;
  const reference=plan.reference?`${plan.reference.mode} reference`:'Imported reference · verify acquisition history';
  const fitNote=plan.additionalHighpass?'ICA will use a private 1 Hz high-pass fitting copy; source stays unchanged.':'ICA will use this already high-pass-filtered stage; no additional 1 Hz filter.';
  $('ica-fit-plan').textContent=`Input: ${stageName(path.at(-1))}. ${passband}. ${reference}. ${fitNote}`;
  const model=S.meta.ica_models.filter(m=>m.source===S.stage).at(-1);
  let status=plan.corrected?'ICA correction exists in this lineage.':model?`ICA fitted for this stage (${model.n_components} components); ${model.converged?'review exclusions before applying':'fit did not converge'}.`:'ICA is not fitted for this selected stage. Use Fit ICA to continue.';
  if(model&&model.quality_revision!==S.meta.quality_revision)status+=' Review decisions changed: refit before applying.';
  if(plan.duplicateReferences)status+=` ${plan.duplicateReferences} repeated reference record(s) remain from earlier processing; saved history is preserved.`;
  $('processing-state').textContent=`${passband} · ${reference}. ${status}`;
  if(model&&!plan.corrected){const button=document.createElement('button');button.className='ica-fit-badge';button.textContent=`ICA fitted · ${model.n_components} components · Review →`;button.onclick=()=>{S.model=model.id;renderModels();selectTab('ica');};$('history').append(button);}
  const label=S.meta.stages.find(s=>s.id===S.stage)?.label || '';
  $('primary-legend').innerHTML='<i></i>'+esc(label);
  $('secondary-legend').innerHTML='<i></i>'+esc(S.meta.stages.find(s=>s.id===S.compareStage)?.label || '');
  setBusy(S.busy,$('job-label').textContent);
}

async function changeStage(id) {
  stopPlay();S.replayCursor=null;
  S.stage=id; syncStages(); saveView();
  await Promise.all([refreshWindow(), loadOverview()]);
}

function activeChannels() {
  return S.selected.filter(n=>!$('hide-bads').checked || !S.meta.bad_channels.includes(n));
}

function renderChannels() {
  $('channel-selection-label').textContent=`${activeChannels().length} channels displayed`;
  $('channels').innerHTML=S.meta.channels.map(n=>`<div class="channel-chip ${S.meta.bad_channels.includes(n)?'bad':''}"><label><input type="checkbox" data-channel="${esc(n)}" ${S.selected.includes(n)?'checked':''}>${esc(n)}</label><button data-bad="${esc(n)}" title="Toggle persistent bad-channel mark" aria-label="Toggle ${esc(n)} bad channel">⚑</button></div>`).join('');
  $('channels').querySelectorAll('[data-channel]').forEach(el=>el.onchange=()=>{
    const name=el.dataset.channel;
    S.selected=el.checked ? [...S.selected,name] : S.selected.filter(n=>n!==name);
    if (S.selected.length>64) {S.selected=S.selected.filter(n=>n!==name);el.checked=false;toast('Display up to 64 channels at a time.',true);return;}
    $('channel-selection-label').textContent=`${activeChannels().length} channels displayed`;
    refreshWindow().catch(e=>toast(e.message,true));
  });
  $('channels').querySelectorAll('[data-bad]').forEach(el=>el.onclick=async()=>{
    try {
      const name=el.dataset.bad, bad=new Set(S.meta.bad_channels);
      bad.has(name)?bad.delete(name):bad.add(name);
      S.meta=await api('/api/bad-channels',{project:S.meta.id,channels:[...bad]});
      renderMeta(); await refreshWindow();
      toast('Bad-channel decision saved. Refit ICA if its training channels changed.');
    } catch(e){toast(e.message,true);}
  });
}

function saveView() {
  if (S.meta) localStorage.setItem('echo-view-'+S.meta.id, JSON.stringify({stage:S.stage,start:S.start,duration:S.duration,sensitivity:S.sensitivity,windowSpeed:S.windowSpeed,centered:$('center-traces').checked,clipRows:$('clip-rows').checked,display_version:2}));
}

async function refreshWindow(markViewed=true) {
  if (!S.meta) return;
  const request=++S.request;
  const names=activeChannels();
  if (!names.length) { S.main=null; S.comparison=null; renderWaves(); toast('Select at least one visible channel.'); return; }
  S.start=Math.max(0,Math.min(S.start,Math.max(0,S.meta.duration-Math.min(S.duration,S.meta.duration))));
  $('start').value=S.start.toFixed(3);
  const q={project:S.meta.id,start:S.start,duration:S.duration,channels:names};
  const results=await Promise.all([
    api('/api/window',null,{...q,stage:S.stage}),
    $('compare').checked ? api('/api/window',null,{...q,stage:S.compareStage}) : Promise.resolve(null),
  ]);
  if(request!==S.request) return;
  [S.main,S.comparison]=results;
  if(S.autoFitPending){setSensitivity(EEGDisplay.fit([S.main,S.comparison],$('center-traces').checked));S.autoFitPending=false;}
  $('window-readout').textContent=`${timeLabel(S.main.start,true)} – ${timeLabel(S.main.end,true)}`;
  $('display-note').textContent=S.main.display_bucket_samples>1 ? 'Peak-preserving display envelope · processing uses full samples' : 'Full samples displayed · signals in µV';
  renderWaves(); drawOverview(); saveView();
  syncReplayControls();
  if(markViewed) {
    const m=await api('/api/viewed',{project:S.meta.id,start:S.main.start,end:Math.min(S.meta.duration,S.main.end+1/S.meta.sfreq)});
    if(request===S.request){S.meta.viewed=m.viewed;const n=m.viewed.reduce((sum,[a,b])=>sum+b-a,0);$('viewed-stat').textContent=`Time windows viewed: ${(100*n/m.duration).toFixed(1)}%`;}
  }
}

async function loadOverview() {
  const project=S.meta.id, stage=S.stage;
  const data=await api('/api/overview',null,{project,stage});
  if(S.meta.id===project && S.stage===stage){S.overview=data;drawOverview();}
}

function setupCanvas(canvas,height) {
  const width=Math.max(160,canvas.getBoundingClientRect?.().width||canvas.parentElement.clientWidth);
  const dpr=Math.min(window.devicePixelRatio||1,2);
  canvas.style.height=height+'px';
  canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);
  const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);
  return {ctx,width,height};
}

function renderWaves() {
  if(S.tab!=='waveforms')return;
  drawWave($('wave-main'),S.main,'#147d78');
  if($('compare').checked)drawWave($('wave-compare'),S.comparison,'#527296');
  renderSignalHealth();
}

function setSensitivity(value){
  S.sensitivity=value;
  const values=[...new Set([...EEGDisplay.scales,value])].sort((a,b)=>a-b);
  $('sensitivity').innerHTML=values.map(v=>`<option value="${v}">${v.toLocaleString()} µV/div</option>`).join('');
  $('sensitivity').value=String(value);
}

function fitTraces(){
  if(!S.main){toast('Load a waveform window first.');return;}
  setSensitivity(EEGDisplay.fit([S.main,S.comparison],$('center-traces').checked));
  renderWaves();saveView();
  toast(`Shared display sensitivity set to ${S.sensitivity.toLocaleString()} µV/div. Samples are unchanged.`);
}

function renderSignalHealth(){
  const data=S.main;
  if(!data){$('signal-health').textContent='No traces displayed. Select at least one channel.';$('signal-diagnostics').innerHTML='';return;}
  const centered=$('center-traces').checked;
  const gap=$('wave-main')._geometry?.gap||68;
  const status=EEGDisplay.status(data,centered,S.sensitivity,gap,Math.min(22,gap*.32));
  let message=`${data.channels.length} individual traces loaded · ${centered?'Window median centered for display':'Original offsets displayed'} · ${S.sensitivity.toLocaleString()} µV/div`;
  if(status.invalid.length)message+=` · No finite samples: ${status.invalid.join(', ')}`;
  if(status.nearFlat.length)message+=` · Near-flat window: ${status.nearFlat.join(', ')} (check source and units)`;
  if(status.clipped.length)message+=` · ${status.clipped.length} traces exceed row height; use Fit traces or increase µV/div`;
  if(!centered&&(data.stats||[]).some(s=>Math.abs(s.median_uv||0)>1000))message+=' · Large offsets detected: enable display centering to inspect fluctuations';
  $('signal-health').textContent=message;
  $('signal-health').classList.toggle('warning',!!(status.invalid.length||status.nearFlat.length||status.clipped.length));
  const format=value=>Number.isFinite(value)?value.toLocaleString(undefined,{maximumFractionDigits:3}):'–';
  $('signal-diagnostics').innerHTML=`<table><thead><tr><th>Channel</th><th>Median offset / µV</th><th>Peak-to-peak / µV</th><th>RMS about median / µV</th><th>Finite samples</th></tr></thead><tbody>${(data.stats||[]).map(s=>`<tr><td>${esc(s.channel)}</td><td>${format(s.median_uv)}</td><td>${s.finite_samples?format(s.max_uv-s.min_uv):'–'}</td><td>${format(s.rms_ac_uv)}</td><td>${s.finite_samples.toLocaleString()}</td></tr>`).join('')}</tbody></table>`;
}

function drawWave(canvas,data,color) {
  const count=data?.channels.length || 4, top=28, left=74, bottom=40;
  const fit=EEGDisplay.layout($('wave-scroll').clientHeight || canvas.parentElement.clientHeight,count,top,bottom,S.waveFitAll),gap=fit.gap;
  const {ctx,width,height}=setupCanvas(canvas,fit.height);
  ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
  if(!data){ctx.fillStyle='#71808b';ctx.font='12px Segoe UI';ctx.fillText('Select channels to inspect.',25,50);return;}
  const right=width-16, end=S.start+S.duration, x=t=>left+(t-S.start)/S.duration*(right-left);
  canvas._geometry={left,right,top,bottom,gap,width,height,start:S.start,end};
  data.channels.forEach((name,i)=>{ctx.fillStyle=i%2===0?'#fbfdfd':'#fff';ctx.fillRect(left,top+i*gap,right-left,gap);});
  ctx.font='10px Segoe UI';
  const tickStep=niceTimeStep(S.duration);
  for(let t=Math.ceil(S.start/tickStep)*tickStep;t<=end;t+=tickStep){
    const px=x(t);ctx.strokeStyle='#eaf0f1';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(px,top-10);ctx.lineTo(px,height-bottom);ctx.stroke();
    ctx.fillStyle='#8b989f';ctx.fillText(t.toFixed(tickStep<1?2:1),px-6,height-27);
  }
  for(const ann of S.meta.annotations){
    const a=Math.max(S.start,ann.start),b=Math.min(end,ann.end);if(b<=a)continue;
    const bad=ann.label.toLowerCase().startsWith('bad');ctx.fillStyle=bad?'#d85d5a16':'#268d8312';ctx.fillRect(x(a),top-10,x(b)-x(a),height-top-bottom+10);
    ctx.fillStyle=bad?'#b85450':'#147d78';ctx.font='9px Segoe UI';ctx.fillText(ann.label,x(a)+4,top-14);
  }
  const selectedA=Number($('ann-start').value), selectedB=Number($('ann-end').value);
  if($('ann-start').value!=='' && selectedB>selectedA){const a=Math.max(S.start,selectedA),b=Math.min(end,selectedB);if(b>a){ctx.fillStyle='#1c879d20';ctx.fillRect(x(a),top-10,x(b)-x(a),height-top-bottom+10);ctx.save();ctx.strokeStyle='#1c879d';ctx.setLineDash([4,3]);ctx.strokeRect(x(a),top-10,x(b)-x(a),height-top-bottom+10);ctx.restore();}}
  const ppu=fit.division/S.sensitivity,rowPad=Math.min(4,gap*.12);
  data.channels.forEach((name,i)=>{
    const baseline=top+(i+.5)*gap;
    ctx.strokeStyle='#f0f3f4';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,baseline);ctx.lineTo(right,baseline);ctx.stroke();
    const bad=S.meta.bad_channels.includes(name);
    ctx.fillStyle=bad?'#c85a57':'#536873';ctx.font='10px Segoe UI';ctx.textAlign='right';ctx.fillText((bad?'⚑ ':'')+name,left-10,baseline+3);ctx.textAlign='left';
    const trace=data.traces[i],center=EEGDisplay.center(data.stats?.[i],trace,$('center-traces').checked);
    const rowClip=$('clip-rows').checked;
    ctx.save();ctx.beginPath();ctx.rect(left,rowClip?baseline-gap/2+rowPad:top-10,right-left,rowClip?gap-2*rowPad:height-top-bottom+10);ctx.clip();
    ctx.strokeStyle=bad?'#c67d78':color;ctx.lineWidth=1.05;ctx.beginPath();
    let drawing=false;
    for(let j=0;j<trace.x.length;j++){if(trace.y[j]===null){drawing=false;continue;}const px=x(trace.x[j]),py=EEGDisplay.pixel(trace.y[j],baseline,S.sensitivity,center,fit.division);if(!drawing){ctx.moveTo(px,py);drawing=true;}else ctx.lineTo(px,py);}
    ctx.stroke();ctx.restore();
    if(rowClip){let last=-100;for(let j=0;j<trace.x.length;j++){const v=trace.y[j];if(v===null)continue;const px=x(trace.x[j]),py=EEGDisplay.pixel(v,baseline,S.sensitivity,center,fit.division);if(Math.abs(py-baseline)<=gap/2-rowPad||px-last<15)continue;last=px;const edge=baseline+(py<baseline?-1:1)*(gap/2-rowPad),direction=py<baseline?1:-1;ctx.fillStyle='#bf8742';ctx.beginPath();ctx.moveTo(px,edge);ctx.lineTo(px-2,edge+Math.min(4,gap*.2)*direction);ctx.lineTo(px+2,edge+Math.min(4,gap*.2)*direction);ctx.closePath();ctx.fill();}}
  });
  // Division size follows fitted rows; the labelled scale bar retains the units.
  ctx.strokeStyle='#354c58';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(right-7,8);ctx.lineTo(right-7,8+fit.division);ctx.stroke();
  ctx.fillStyle='#536873';ctx.font='9px Segoe UI';ctx.textAlign='right';ctx.fillText(`${S.sensitivity} µV/div`,right-13,17);ctx.textAlign='left';
  ctx.fillStyle='#536873';ctx.font='10px Segoe UI';ctx.textAlign='center';ctx.fillText('Elapsed recording time (s)',(left+right)/2,height-7);
  ctx.save();ctx.translate(13,(top+height-bottom)/2);ctx.rotate(-Math.PI/2);ctx.fillText('EEG channel · amplitude (µV)',0,0);ctx.restore();ctx.textAlign='left';
}

function drawOverview(){
  if(!S.meta || $('workbench').hidden || (S.tab==='ica'&&!S.showTimelineInDetail))return;
  const {ctx,width,height}=setupCanvas($('overview'),$('overview').clientHeight||120);
  const left=65,right=width-14,top=24,bottom=height-34;
  const x=t=>left+t/S.meta.duration*(right-left);
  $('overview')._geometry={left,right,width,height,top,bottom};
  ctx.fillStyle='#f7f9fa';ctx.fillRect(left,top,right-left,bottom-top);
  const max=S.overview?Math.max(...S.overview.rms_uv,1):1;
  const y=v=>bottom-v/max*(bottom-top);
  ctx.font='10px Segoe UI';
  for(let i=0;i<=2;i++){
    const value=max*i/2,py=y(value);ctx.strokeStyle='#e1e7e9';ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(left,py);ctx.lineTo(right,py);ctx.stroke();
    ctx.fillStyle='#586b74';ctx.textAlign='right';ctx.fillText(value<10?value.toFixed(1):value.toFixed(0),left-8,py+3);
  }
  for(const c of S.meta.suggestions.filter(s=>s.status==='pending')){ctx.fillStyle='#cb963644';ctx.fillRect(x(c.start),top,Math.max(2,x(c.end)-x(c.start)),bottom-top);}
  if(S.overview){
    ctx.strokeStyle='#54727c';ctx.lineWidth=1.5;ctx.beginPath();
    S.overview.times.forEach((t,i)=>{const py=y(S.overview.rms_uv[i]);i?ctx.lineTo(x(t),py):ctx.moveTo(x(t),py);});ctx.stroke();
  }
  for(const ann of S.meta.annotations){ctx.fillStyle=ann.label.toLowerCase().startsWith('bad')?'#c85a5777':'#147d7855';ctx.fillRect(x(ann.start),top,Math.max(2,x(ann.end)-x(ann.start)),bottom-top);}
  for(const [a,b] of S.meta.viewed){ctx.fillStyle='#147d7890';ctx.fillRect(x(a),bottom+3,Math.max(1,x(b)-x(a)),4);}
  const windowLeft=x(S.start),windowRight=x(Math.min(S.meta.duration,S.start+S.duration));
  // Expand only the visual marker so short windows remain visible in a long recording.
  const markWidth=Math.min(right-left,Math.max(6,windowRight-windowLeft));
  const markLeft=Math.max(left,Math.min(right-markWidth,windowLeft));
  ctx.fillStyle='#147d7828';ctx.strokeStyle='#126b67';ctx.lineWidth=1.5;
  ctx.fillRect(markLeft,top,markWidth,bottom-top);ctx.strokeRect(markLeft,top,markWidth,bottom-top);
  ctx.fillStyle='#536873';ctx.font='10px Segoe UI';const ticks=width<520?3:5;
  for(let i=0;i<=ticks;i++){const t=S.meta.duration*i/ticks;ctx.textAlign=i===0?'left':i===ticks?'right':'center';ctx.fillText(timeLabel(t),x(t),bottom+18);}
  ctx.textAlign='center';ctx.fillText('Elapsed recording time (mm:ss / hh:mm:ss)',(left+right)/2,height-2);
  ctx.textAlign='left';ctx.fillText('Median RMS (µV)',8,11);
}

function pointerTime(canvas,event){
  const g=canvas._geometry,rect=canvas.getBoundingClientRect(),px=event.clientX-rect.left;
  return Math.max(0,Math.min(S.meta.duration,g.start+Math.max(0,Math.min(1,(px-g.left)/(g.right-g.left)))*(g.end-g.start)));
}

for(const id of ['wave-main','wave-compare']){
  const canvas=$(id);
  canvas.addEventListener('pointerdown',e=>{
    if(!S.meta || !canvas._geometry)return;
    if(S.mode==='inspect'||S.mode==='magnify')return;
    stopPlay();
    S.drag={canvas,start:pointerTime(canvas,e)};canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove',e=>{
    const data=id==='wave-main'?S.main:S.comparison;if(!data || !canvas._geometry)return;
    const t=pointerTime(canvas,e),g=canvas._geometry,rect=canvas.getBoundingClientRect();
    const i=Math.floor((e.clientY-rect.top-g.top)/g.gap);
    if(i>=0 && i<data.channels.length){const trace=data.traces[i];let l=0,r=trace.x.length-1;while(l<r){const mid=(l+r)>>1;if(trace.x[mid]<t)l=mid+1;else r=mid;}const value=trace.y[l],offset=EEGDisplay.center(data.stats?.[i],trace,$('center-traces').checked);$('cursor-readout').textContent=`${data.channels[i]} · ${t.toFixed(3)} s · ${value===null?'invalid':`Original ${value.toFixed(2)} µV · Display relative ${ (value-offset).toFixed(2)} µV`}${data.display_bucket_samples>1?' (display envelope)':''}`;}
    if(S.drag?.canvas===canvas){const a=Math.min(t,S.drag.start),b=Math.max(t,S.drag.start);$('ann-start').value=a.toFixed(3);$('ann-end').value=b.toFixed(3);renderWaves();}
  });
  canvas.addEventListener('pointerup',e=>{
    if(S.drag?.canvas!==canvas)return;
    const t=pointerTime(canvas,e),a=Math.min(t,S.drag.start),b=Math.max(t,S.drag.start);S.drag=null;
    if(b-a<.01)return;
    if(S.mode==='zoom'){S.start=a;S.duration=Math.max(.05,b-a);clearAnnotation();refreshWindow().catch(e=>toast(e.message,true));}
    else{$('ann-start').value=a.toFixed(3);$('ann-end').value=b.toFixed(3);openAnnotationDialog('waveforms');renderWaves();}
  });
  canvas.addEventListener('pointercancel',()=>{S.drag=null;});
  canvas.addEventListener('dblclick',()=>{S.duration=10;$('window').value='10';refreshWindow().catch(e=>toast(e.message,true));});
  canvas.addEventListener('wheel',e=>{
    if(!S.meta)return;
    if(e.altKey){e.preventDefault();$('wave-scroll').scrollTop+=e.deltaY;}
    else if(e.shiftKey){e.preventDefault();navigate(e.deltaY>0?1:-1);}
    else if(!e.ctrlKey&&!e.metaKey){e.preventDefault();changeSensitivity(e.deltaY>0?1:-1);}
  },{passive:false});
}

function setMode(mode){S.mode=mode;document.querySelectorAll('[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===mode);b.setAttribute('aria-pressed',String(b.dataset.mode===mode));});for(const id of ['wave-main','wave-compare'])$(id).style.cursor=mode==='zoom'||mode==='magnify'?'zoom-in':'crosshair';}
async function navigate(direction){if(!S.meta)return;stopPlay();S.replayCursor=null;S.start+=direction*S.duration;try{await refreshWindow(S.tab==='waveforms');if(S.tab==='ica')await loadComponent();else if(S.tab==='ica-all')await loadAllComponents();}catch(e){toast(e.message,true);}}
function stopPlay(){pauseReplay();}
function changeSensitivity(direction){const options=[...$('sensitivity').options].map(o=>Number(o.value)).sort((a,b)=>a-b);let index=options.findIndex(v=>v>=S.sensitivity);index=Math.max(0,Math.min(options.length-1,index+direction));setSensitivity(options[index]);renderWaves();saveView();}

function clearAnnotation(){S.annId=null;for(const id of ['ann-start','ann-end','ann-note'])$(id).value='';$('ann-label').value='BAD_artifact';$('annotation-heading').textContent='Mark an irregularity';$('save-annotation').textContent='Save annotation';S.annotationContext=null;renderWaves();drawAllComponents();}
function editAnnotation(id){const ann=S.meta.annotations.find(a=>a.id===id);if(!ann)return;S.annId=id;$('ann-start').value=ann.start;$('ann-end').value=ann.end;$('ann-label').value=ann.label;$('ann-note').value=ann.note;$('annotation-heading').textContent='Edit saved annotation';$('save-annotation').textContent='Save changes';S.start=Math.max(0,ann.start-1);selectTab('waveforms');openAnnotationDialog('waveforms',ann.context);refreshWindow().catch(e=>toast(e.message,true));}
function renderAnnotations(){
  const annotations=S.meta.annotations;
  $('annotation-table').innerHTML=annotations.length?`<table><thead><tr><th>Interval / s</th><th>Duration</th><th>Label</th><th>Note</th><th>Actions</th></tr></thead><tbody>${annotations.map(a=>`<tr><td>${a.start.toFixed(3)} – ${a.end.toFixed(3)}</td><td>${(a.end-a.start).toFixed(3)} s</td><td><span class="label-badge ${a.label.toLowerCase().startsWith('bad')?'bad':''}">${esc(a.label)}</span></td><td>${esc(a.note)}</td><td><button data-edit="${a.id}">Inspect / edit</button><button data-delete="${a.id}">Delete</button></td></tr>`).join('')}</tbody></table>`:'<div class="empty">No annotations yet. Mark a time range to record your first decision.</div>';
  $('annotation-table').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editAnnotation(b.dataset.edit));
  $('annotation-table').querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{try{S.meta=await api('/api/annotation',{project:S.meta.id,id:b.dataset.delete,delete:true});if(S.annId===b.dataset.delete)clearAnnotation();renderMeta();renderWaves();toast('Annotation deleted.');}catch(e){toast(e.message,true);}});
}

function renderQueue(){
  const pending=S.meta.suggestions.filter(c=>c.status==='pending');
  $('queue-count').textContent=pending.length;
  $('screen-summary').textContent=S.meta.screening?`${pending.length} pending · ${S.meta.screening.windows} two-second windows screened`:'Run full-recording screening from the sidebar.';
  $('queue-table').innerHTML=pending.length?`<table><thead><tr><th>Interval / s</th><th>Reason</th><th>Channels</th><th>Review</th></tr></thead><tbody>${pending.map(c=>`<tr><td>${c.start.toFixed(1)} – ${c.end.toFixed(1)}</td><td>${esc(c.reasons.join(', '))}</td><td>${esc(c.channels.join(', '))}</td><td><button data-inspect="${c.id}">Inspect</button><button data-accept="${c.id}">Mark BAD</button><button data-dismiss="${c.id}">Dismiss</button></td></tr>`).join('')}</tbody></table>`:'<div class="empty">No pending candidates. A clear queue does not establish artifact-free EEG.</div>';
  $('queue-table').querySelectorAll('[data-inspect]').forEach(b=>b.onclick=()=>{const c=pending.find(v=>v.id===b.dataset.inspect);S.stage=S.meta.screening.stage;syncStages();S.start=Math.max(0,c.start-2);S.duration=Math.min(120,Math.max(10,c.end-c.start+4));selectTab('waveforms');$('ann-start').value=c.start;$('ann-end').value=c.end;Promise.all([refreshWindow(),loadOverview()]).catch(e=>toast(e.message,true));});
  for(const [attribute,accept] of [['accept',true],['dismiss',false]])$('queue-table').querySelectorAll(`[data-${attribute}]`).forEach(b=>b.onclick=async()=>{try{S.meta=await api('/api/suggestion',{project:S.meta.id,id:b.dataset[attribute],accept});renderMeta();renderWaves();toast(accept?'Candidate saved as a BAD annotation.':'Candidate dismissed.');}catch(e){toast(e.message,true);}});
}

function renderLog(){
  $('processing-log').innerHTML=S.meta.stages.map(s=>`<div class="log-item"><h3>${esc(s.label)}</h3><p class="hint">Stage ${esc(s.id)} · Source ${esc(s.parent||'original import')} · ${esc(s.created_at)}</p><pre>${esc(JSON.stringify(s.params,null,2))}</pre></div>`).join('')+S.meta.ica_models.map(m=>`<div class="log-item"><h3>ICA fit · ${esc(m.id)}</h3><p class="hint">Fitting creates a model, not corrected samples. Apply reviewed exclusions to create a corrected stage.</p><pre>${esc(JSON.stringify(m,null,2))}</pre></div>`).join('')+`<div class="log-item"><h3>Review audit</h3><pre>${esc(JSON.stringify(S.meta.audit.slice(-100),null,2))}</pre></div>`;
}

function selectTab(tab){
  if(S.tab!==tab){
    stopPlay();
    if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});
    document.querySelectorAll('.focus-fallback').forEach(el=>el.classList.remove('focus-fallback'));
    if(typeof restoreWholeScreen==='function')restoreWholeScreen();
  }
  S.tab=tab;document.querySelectorAll('[data-tab]').forEach(b=>{const selected=b.dataset.tab===tab;b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected));});
  document.body.classList.toggle('ica-detail-focus',tab==='ica'&&!S.showTimelineInDetail);
  document.querySelectorAll('.tab-content').forEach(el=>el.hidden=el.id!=='tab-'+tab);
  requestAnimationFrame(()=>{if(tab==='waveforms')renderWaves();if(tab==='spectrum')drawPSD();if(tab==='ica')loadComponent().catch(e=>toast(e.message,true));if(tab==='ica-all')loadAllComponents().catch(e=>toast(e.message,true));syncReplayControls();});
}

function lineChart(canvas,series,{xLabel='Frequency (Hz)',yLabel='Power (dB)',height=300}={}){
  const {ctx,width}=setupCanvas(canvas,height);ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
  if(!series.length){ctx.fillStyle='#71808b';ctx.font='12px Segoe UI';ctx.fillText('No spectrum calculated yet.',35,45);return;}
  const left=66,right=width-28,top=18,bottom=height-42;
  const xs=series.flatMap(s=>s.x).filter(Number.isFinite),ys=series.flatMap(s=>s.y).filter(Number.isFinite);
  if(!xs.length||!ys.length||right<=left||bottom<=top)return;
  const xmin=Math.min(...xs),xmax=Math.max(...xs),rawMin=Math.min(...ys),rawMax=Math.max(...ys),pad=(rawMax-rawMin)*.08||Math.max(Math.abs(rawMax)*.1,.1),ymin=rawMin-pad,ymax=rawMax+pad;
  canvas._lineGeometry={left,right,plotTop:top,plotBottom:bottom,start:xmin,end:xmax};
  const x=v=>left+(v-xmin)/(xmax-xmin||1)*(right-left),y=v=>bottom-(v-ymin)/(ymax-ymin||1)*(bottom-top);
  const xSpan=xmax-xmin,decimals=xSpan<1?Math.min(5,Math.max(2,Math.ceil(-Math.log10(xSpan||1))+1)):1;
  const ticks=Math.max(2,Math.min(5,Math.floor((bottom-top)/22),Math.floor((right-left)/62)));
  ctx.font='10px Segoe UI';
  for(let i=0;i<=ticks;i++){
    const v=ymin+(ymax-ymin)*i/ticks,py=y(v);ctx.strokeStyle='#e9eef0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,py);ctx.lineTo(right,py);ctx.stroke();
    ctx.fillStyle='#536873';ctx.textAlign='right';const ytext=Math.abs(v)>=10000||(v!==0&&Math.abs(v)<.001)?v.toExponential(1):(ymax-ymin)<10?v.toPrecision(3):v.toFixed(0);ctx.fillText(ytext,left-8,py+3);
    const vx=xmin+(xmax-xmin)*i/ticks;ctx.textAlign=i===0?'left':i===ticks?'right':'center';ctx.fillText(vx.toFixed(decimals),x(vx),bottom+17);
  }
  ctx.save();ctx.beginPath();ctx.rect(left,top,right-left,bottom-top);ctx.clip();
  series.forEach(s=>{ctx.strokeStyle=s.color;ctx.lineWidth=1.4;ctx.beginPath();let started=false;s.x.forEach((v,i)=>{if(!Number.isFinite(v)||!Number.isFinite(s.y[i])){started=false;return;}if(!started){ctx.moveTo(x(v),y(s.y[i]));started=true;}else ctx.lineTo(x(v),y(s.y[i]));});ctx.stroke();});ctx.restore();
  ctx.fillStyle='#536873';ctx.textAlign='center';ctx.fillText(xLabel,(left+right)/2,height-5);ctx.save();ctx.translate(12,(top+bottom)/2);ctx.rotate(-Math.PI/2);ctx.fillText(yLabel,0,0);ctx.restore();ctx.textAlign='left';
}

function drawPSD(){
  if(S.tab!=='spectrum')return;
  const series=[];
  if(S.psd)series.push({x:S.psd.frequencies,y:S.psd.mean_db,color:'#147d78',label:S.psd.label});
  if(S.psdCompare)series.push({x:S.psdCompare.frequencies,y:S.psdCompare.mean_db,color:'#527296',label:S.psdCompare.label});
  $('psd-legend').innerHTML=series.length?series.map((s,i)=>`<span><i class="key-line ${i===0?'key-teal':'key-blue'}"></i>${esc(s.label)} · mean of accepted good EEG channels</span>`).join(''):'<span class="hint">Calculate PSD to identify the stage represented by each line.</span>';
  lineChart($('psd-canvas'),series,{height:Math.max(120,$('psd-canvas').clientHeight||300),yLabel:'PSD (dB re 1 µV²/Hz)'});
}

function renderModels(){
  const models=S.meta.ica_models;
  $('ica-model').innerHTML=models.map(m=>`<option value="${m.id}">${esc(m.id)} · ${m.n_components} ICs</option>`).join('');
  $('ica-all-model').innerHTML=$('ica-model').innerHTML;
  if(!models.some(m=>m.id===S.model))S.model=models.at(-1)?.id||null;
  if(S.model)$('ica-model').value=S.model;
  if(S.model)$('ica-all-model').value=S.model;
  const info=models.find(m=>m.id===S.model);
  if(!info){$('ica-status').textContent='Fit a model from the sidebar to inspect components.';$('component-buttons').innerHTML='';$('apply-ica').disabled=true;S.allComponents=null;drawAllComponents();return;}
  if(S.component>=info.n_components)S.component=0;
  S.excluded=new Set(info.selected_excluded || []);
  const stale=info.quality_revision!==S.meta.quality_revision;
  $('ica-status').textContent=`Source: ${S.meta.stages.find(s=>s.id===info.source)?.label} · Rank ${info.rank} · ${info.training_samples.toLocaleString()} training samples · ${info.converged?'Converged':'DID NOT CONVERGE'} · ${info.fit_filter_note||'Legacy model: additional 1 Hz fitting filter was used.'}${stale?' · REVIEW CHANGED: refit before applying':''}`;
  $('component-buttons').innerHTML=Array.from({length:info.n_components},(_,i)=>`<button data-component="${i}" class="${i===S.component?'active':''} ${S.excluded.has(i)?'excluded':''}">IC ${String(i).padStart(2,'0')}</button>`).join('');
  $('component-buttons').querySelectorAll('button').forEach(b=>b.onclick=()=>{S.component=Number(b.dataset.component);renderModels();loadComponent().catch(e=>toast(e.message,true));});
  $('excluded-readout').textContent=S.excluded.size?'Selected exclusions: '+[...S.excluded].sort((a,b)=>a-b).map(i=>'IC '+i).join(', '):'No components selected for exclusion.';
  $('exclude-component').checked=S.excluded.has(S.component);
  $('ica-all-exclude').checked=S.excluded.has(S.component);
  $('apply-ica').disabled=S.busy||stale||!info.converged||!S.excluded.size;
  drawAllComponents();
}

async function loadComponent(){
  if(S.tab!=='ica'||!S.model)return;
  const model=S.model,component=S.component;
  const request=++S.componentRequest;
  const data=await api('/api/component',null,{project:S.meta.id,model,component,start:S.start,duration:S.duration});
  if(S.model!==model||S.component!==component||request!==S.componentRequest)return;
  S.componentData=data;
  $('component-title').textContent=`IC ${String(component).padStart(2,'0')} · ${timeLabel(S.start)} window`;
  $('exclude-component').checked=S.excluded.has(component);
  renderComponentDetails(data);
  syncReplayControls();updateLiveFeedback(S.replayCursor??S.start);
}

function weightColor(value,bound){const amount=Math.min(1,Math.abs(value)/bound),base=value>=0?[192,63,64]:[48,97,162];return `rgb(${base.map(v=>Math.round(246+(v-246)*amount)).join(',')})`;}

function renderComponentDetails(data){
  if(!data||S.tab!=='ica')return;
  if(!$('ica-source-panel').hidden){
    const traceHeight=$('component-trace-frame').clientHeight||180;
    const spectrumHeight=$('component-spectrum-frame').clientHeight||180;
    lineChart($('component-trace'),[{x:data.trace.x,y:data.trace.y,color:'#147d78'}],{height:traceHeight,xLabel:'Time (s)',yLabel:'Source (a.u.)'});
    lineChart($('component-spectrum'),[{x:data.frequencies,y:data.psd_db,color:'#527296'}],{height:spectrumHeight,yLabel:'PSD (dB re 1 a.u.²/Hz)'});
  }
  if(!$('ica-map-panel').hidden)drawComponentMap(data);
}

function drawComponentMap(data){
  const frame=$('component-map-frame');
  const panelWidth=frame.clientWidth||frame.getBoundingClientRect?.().width||600;
  const stacked=panelWidth<440;
  const sides=['L','R'];
  const available=data.channels.filter(n=>Array.isArray(data.positions[n])&&data.positions[n].slice(0,3).every(Number.isFinite));
  const maxSide=Math.max(0,...sides.map(side=>available.filter(n=>n.startsWith(side)).length));
  // Reserve room for labels; small screens stack ears rather than shrinking text.
  const minHeight=stacked?Math.max(520,2*(100+maxSide*12)+82):Math.max(300,160+maxSide*12);
  frame.style.minHeight=minHeight+'px';
  const {ctx,width,height}=setupCanvas($('component-map'),Math.max(minHeight,frame.clientHeight||minHeight));
  ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
  if(!available.length){ctx.fillStyle='#71808b';ctx.font='12px Segoe UI';ctx.textAlign='left';ctx.fillText('Electrode positions unavailable.',20,50);ctx.fillText('Add measured or nominal positions',20,72);ctx.fillText('to view weights.',20,90);return;}
  const xy=available.map(n=>[-data.positions[n][1],data.positions[n][2]]),xs=xy.map(v=>v[0]),ys=xy.map(v=>v[1]);
  const xmin=Math.min(...xs)-.01,xmax=Math.max(...xs)+.01,ymin=Math.min(...ys)-.01,ymax=Math.max(...ys)+.01;
  const bound=Math.max(...data.weights.map(Math.abs),1e-15);
  const contentBottom=height-76,panels=[];
  for(const [column,side] of sides.entries()){
    const panelLeft=stacked?0:column*width/2,panelRight=stacked?width:(column+1)*width/2;
    const panelTop=stacked?column*contentBottom/2:0,panelBottom=stacked?(column+1)*contentBottom/2:contentBottom;
    const availableLeft=panelLeft+50,availableRight=panelRight-52,availableTop=panelTop+29,availableBottom=panelBottom-35;
    const scale=Math.max(0,Math.min((availableRight-availableLeft)/(xmax-xmin),(availableBottom-availableTop)/(ymax-ymin)));
    const center=(availableLeft+availableRight)/2,midY=(availableTop+availableBottom)/2;
    const x=v=>center+(v-(xmin+xmax)/2)*scale,y=v=>midY-(v-(ymin+ymax)/2)*scale;
    const x0=x(xmin),x1=x(xmax),y0=y(ymin),y1=y(ymax);
    ctx.fillStyle='#213b49';ctx.textAlign='center';ctx.font='11px Segoe UI';ctx.fillText(side==='L'?'Left ear':'Right ear',(panelLeft+panelRight)/2,panelTop+15);
    ctx.strokeStyle='#b5c4c9';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(x0,y1);ctx.lineTo(x0,y0);ctx.lineTo(x1,y0);ctx.stroke();
    ctx.font='9px Segoe UI';ctx.fillStyle='#536873';
    for(let i=0;i<=2;i++){
      const xv=xmin+(xmax-xmin)*i/2,yv=ymin+(ymax-ymin)*i/2;
      ctx.textAlign=i===0?'left':i===2?'right':'center';ctx.fillText((xv*1000).toFixed(0),x(xv),y0+12);
      ctx.textAlign='right';ctx.fillText((yv*1000).toFixed(0),x0-5,y(yv)+3);
    }
    ctx.textAlign='center';ctx.fillText('−y (mm) · anterior ←',center,y0+27);
    ctx.save();ctx.translate(panelLeft+9,(y0+y1)/2);ctx.rotate(-Math.PI/2);ctx.fillText('z (mm) · superior ↑',0,0);ctx.restore();
    const entries=[];
    data.channels.forEach((name,i)=>{
      if(!name.startsWith(side)||!available.includes(name))return;
      const p=data.positions[name],px=x(-p[1]),py=y(p[2]);
      ctx.fillStyle=weightColor(data.weights[i],bound);ctx.strokeStyle='#667882';ctx.lineWidth=.8;ctx.beginPath();ctx.arc(px,py,7,0,2*Math.PI);ctx.fill();ctx.stroke();
      entries.push({name,px,py});
    });
    // A sorted label column keeps names apart while dots retain exact coordinates.
    entries.sort((a,b)=>a.py-b.py);const spacing=11;
    entries.forEach((e,i)=>{e.labelY=Math.max(y1+5,e.py,i?entries[i-1].labelY+spacing:y1+5);});
    if(entries.length){const shift=Math.max(0,entries.at(-1).labelY-(y0-4));entries.forEach(e=>e.labelY-=shift);}
    const labelX=panelRight-36;
    panels.push({side,left:panelLeft,right:panelRight,top:panelTop,bottom:panelBottom,x0,x1,y0,y1,labelX,labels:entries.map(e=>({name:e.name,y:e.labelY}))});
    for(const e of entries){
      ctx.strokeStyle='#aebcc0';ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(e.px+7,e.py);ctx.lineTo(labelX-3,e.labelY);ctx.stroke();
      ctx.fillStyle='#425660';ctx.textAlign='left';ctx.font='9px Segoe UI';
      let label=e.name;while(label.length>1&&ctx.measureText(label).width>33)label=label.slice(0,-1);
      if(label!==e.name)label=label.slice(0,Math.max(1,label.length-1))+'…';ctx.fillText(label,labelX,e.labelY+3);
    }
  }
  const barWidth=Math.min(260,width-80),barX=(width-barWidth)/2,barY=height-56;
  const gradient=ctx.createLinearGradient(barX,0,barX+barWidth,0);
  gradient.addColorStop(0,weightColor(-bound,bound));gradient.addColorStop(.5,weightColor(0,bound));gradient.addColorStop(1,weightColor(bound,bound));
  ctx.fillStyle=gradient;ctx.fillRect(barX,barY,barWidth,10);ctx.strokeStyle='#cbd6da';ctx.lineWidth=.7;ctx.strokeRect(barX,barY,barWidth,10);
  ctx.fillStyle='#536873';ctx.font='9px Segoe UI';
  for(const [fraction,label] of [[0,(-bound).toPrecision(3)],[.5,'0'],[1,'+'+bound.toPrecision(3)]]){ctx.textAlign=fraction===0?'left':fraction===1?'right':'center';ctx.fillText(label,barX+fraction*barWidth,barY+24);}
  ctx.textAlign='center';ctx.fillText('Signed ICA loading (a.u.) · shared ear scale',width/2,height-7);ctx.textAlign='left';
  $('component-map')._mapGeometry={stacked,width,height,panels};
}

function downloadLink(filename){
  const url='/api/download?'+new URLSearchParams({project:S.meta.id,file:filename});
  const link=document.createElement('a');link.href=url;link.download=filename;link.textContent='Download '+filename;$('download-links').prepend(link);link.click();
}

// ----------------------- control wiring -----------------------
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>selectTab(b.dataset.tab));
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
bind('help-button','click',()=>$('help-dialog').showModal());
bind('close-help','click',()=>$('help-dialog').close());
bind('welcome-upload','click',()=>$('upload').click());
bind('session-picker','change',()=>{if($('session-picker').value)return openSession($('session-picker').value);});
bind('upload','change',async()=>{
  const files=[...$('upload').files];if(!files.length)return;
  if(S.busy)throw new Error('Wait for the current job to finish.');
  const primary=files.filter(f=>!f.name.toLowerCase().endsWith('.fdt'));
  if(primary.length!==1 || files.length>2 || (files.length===2&&!primary[0].name.toLowerCase().endsWith('.set'))){$('upload').value='';throw new Error('Select one recording, or a SET and its FDT companion together.');}
  if(new Set(files.map(f=>f.name.toLowerCase())).size!==files.length){$('upload').value='';throw new Error('Duplicate upload filenames.');}
  setBusy(true,'Uploading recording…');
  let batch=null,handedOff=false;
  try{
    batch=(await api('/api/upload-batch',{})).batch;
    for(let i=0;i<files.length;i++){
      const file=files[i];$('job-label').textContent=`Uploading ${i+1}/${files.length} · ${file.name}`;
      const response=await fetch('/api/upload',{method:'POST',headers:{'X-Echo-Token':S.token,'X-Filename':encodeURIComponent(file.name),'X-Upload-Batch':batch},body:file});
      const uploaded=await response.json();if(!response.ok)throw new Error(uploaded.error);
    }
    const job=await api('/api/import-upload',{batch,units:$('units').value,montage_units:$('eeglab-montage-units').value,uint16_codec:$('eeglab-codec').value||null});
    handedOff=true;
    const result=await finishJob(job);await openSession(result.project);
  }finally{if(batch&&!handedOff)await api('/api/cancel-upload',{batch}).catch(()=>{});setBusy(false);$('upload').value='';}
});
bind('import-path','click',()=>{if(!$('local-path').value.trim())throw new Error('Enter a complete recording file path.');return runJob('/api/import-path',{path:$('local-path').value.trim(),units:$('units').value,montage_units:$('eeglab-montage-units').value,uint16_codec:$('eeglab-codec').value||null});});
bind('filter','click',()=>runJob('/api/filter',{project:S.meta.id,source:S.stage,low:Number($('low').value),high:Number($('high').value),notch:$('notch').value}));
bind('reference','click',()=>runJob('/api/reference',{project:S.meta.id,source:S.stage,mode:$('reference-mode').value,confirm:$('confirm-reference').checked}));
bind('reference-mode','change',()=>setBusy(S.busy,$('job-label').textContent));
bind('fit-ica','click',()=>runJob('/api/fit-ica',{project:S.meta.id,source:S.stage,start:Number($('fit-start').value||0),end:$('fit-end').value||null,n_components:$('fit-components').value||null}));
bind('nominal-montage','click',async()=>{S.meta=await api('/api/montage',{project:S.meta.id});renderMeta();if(S.tab==='ica')await loadComponent();toast('Nominal geometry added. This is not participant-specific digitization.');});
bind('screen','click',()=>runJob('/api/screen',{project:S.meta.id,stage:S.stage,p2p_uv:Number($('screen-p2p').value),flat_uv:Number($('screen-flat').value),robust_z:Number($('screen-z').value)},()=>{selectTab('review');toast('Screening complete. Inspect candidates before marking them BAD.');}));
bind('stage','change',()=>changeStage($('stage').value));
bind('compare-stage','change',async()=>{S.compareStage=$('compare-stage').value;syncStages();await refreshWindow(false);});
bind('compare','change',async()=>{const enabled=$('compare').checked;$('compare-panel').hidden=!enabled;$('compare-label').hidden=!enabled;$('secondary-legend').hidden=!enabled;await refreshWindow(false);});
bind('prev','click',()=>navigate(-1));bind('next','click',()=>navigate(1));
bind('start','change',()=>{stopPlay();S.replayCursor=null;S.start=Number($('start').value);return syncWindowAndSources();});
bind('window','change',()=>{const duration=Number($('window').value);stopPlay();S.replayCursor=null;S.duration=duration;return syncWindowAndSources();});
bind('sensitivity','change',()=>{S.sensitivity=Number($('sensitivity').value);renderWaves();saveView();});
bind('fit-traces','click',fitTraces);
bind('center-traces','change',()=>{renderWaves();saveView();});
bind('clip-rows','change',()=>{renderWaves();saveView();});
bind('play','click',toggleReplay);
bind('reset-zoom','click',()=>{S.duration=10;$('window').value='10';return refreshWindow();});
bind('fullscreen','click',()=>toggleViewerFullscreen(document.querySelector('.signal-card')));
bind('select-all','click',()=>{S.selected=S.meta.channels.filter((n,i)=>S.meta.channel_types[i]==='eeg').slice(0,64);renderChannels();return refreshWindow();});
bind('left-only','click',()=>{S.selected=S.meta.channels.filter(n=>n.startsWith('L')).slice(0,64);renderChannels();return refreshWindow();});
bind('right-only','click',()=>{S.selected=S.meta.channels.filter(n=>n.startsWith('R')).slice(0,64);renderChannels();return refreshWindow();});
bind('hide-bads','change',()=>{renderChannels();return refreshWindow();});
bind('overview','click',async e=>{if(!S.meta)return;stopPlay();S.replayCursor=null;const rect=$('overview').getBoundingClientRect(),g=$('overview')._geometry;const fraction=Math.max(0,Math.min(1,(e.clientX-rect.left-g.left)/(g.right-g.left)));S.start=Math.max(0,fraction*S.meta.duration-S.duration/2);await syncWindowAndSources();});
bind('save-annotation','click',async()=>{
  if(!$('ann-start').value||!$('ann-end').value)throw new Error('Select a time range or enter both annotation bounds.');
  const before=new Set(S.meta.annotations.map(a=>a.id));
  S.meta=await api('/api/annotation',{project:S.meta.id,id:S.annId,start:Number($('ann-start').value),end:Number($('ann-end').value),label:$('ann-label').value,note:$('ann-note').value,context:S.annotationContext});
  const added=S.meta.annotations.find(a=>!before.has(a.id));if(added)S.added.push(added.id);
  $('annotation-dialog').close();clearAnnotation();renderMeta();renderWaves();drawOverview();drawAllComponents();toast('Annotation saved across EEG and ICA views.');
});
bind('cancel-annotation','click',clearAnnotation);
bind('undo-annotation','click',async()=>{let id;while(S.added.length&&!id){const candidate=S.added.pop();if(S.meta.annotations.some(a=>a.id===candidate))id=candidate;}if(!id){toast('No new annotation to undo in this browser session.');return;}S.meta=await api('/api/annotation',{project:S.meta.id,id,delete:true});renderMeta();renderWaves();toast('Last annotation addition undone.');});
for(const id of ['ann-start','ann-end'])bind(id,'input',()=>{renderWaves();drawAllComponents();});
function clearSpectrum(){
  S.psd=null;S.psdCompare=null;
  $('bandpower-table').innerHTML='';
  $('psd-summary').textContent='Settings changed – calculate PSD to update the spectrum.';
  drawPSD();
}
bind('psd-stage','change',()=>{S.spectrumStage=$('psd-stage').value;clearSpectrum();});
bind('psd-compare-stage','change',()=>{S.spectrumCompareStage=$('psd-compare-stage').value;clearSpectrum();});
bind('psd-compare','change',()=>{$('psd-compare-label').hidden=!$('psd-compare').checked;clearSpectrum();});
bind('psd-range','change',clearSpectrum);
bind('compute-psd','click',async()=>{
  const full=$('psd-range').value==='all',primary=S.spectrumStage,comparison=$('psd-compare').checked?S.spectrumCompareStage:null;
  const q={project:S.meta.id,stage:primary,start:full?0:S.start,end:full?null:Math.min(S.meta.duration,S.start+S.duration),channels:activeChannels()};
  clearSpectrum();$('psd-summary').textContent='Calculating spectrum…';
  const first=await runJob('/api/psd',q);
  const second=comparison?await runJob('/api/psd',{...q,stage:comparison}):null;
  const label=id=>S.meta.stages.find(s=>s.id===id)?.label||id;
  S.psd={...first.psd,label:label(primary)};
  S.psdCompare=second?{...second.psd,label:label(comparison)}:null;
  $('psd-summary').textContent=`${full?'Entire recording':`${q.start.toFixed(2)}–${q.end.toFixed(2)} s`} · ${S.psd.accepted_windows} / ${S.psd.total_windows} windows accepted · ${S.psd.settings}${second?' · comparison uses the same interval and channel selection':''}`;
  const bands=Object.keys(S.psd.bandpower_db);$('bandpower-table').innerHTML=`<table><caption>Band power – ${esc(S.psd.label)}</caption><thead><tr><th>Channel</th>${bands.map(b=>`<th>${esc(b)} · dB re 1 µV²</th>`).join('')}</tr></thead><tbody>${S.psd.channels.map((name,i)=>`<tr><td>${esc(name)}</td>${bands.map(b=>`<td>${S.psd.bandpower_db[b][i].toFixed(2)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;drawPSD();
});
bind('ica-model','change',()=>selectIcaModel($('ica-model').value));
bind('ica-all-model','change',()=>selectIcaModel($('ica-all-model').value));
for(const id of ['replay-speed','ica-speed','ica-all-speed'])bind(id,'change',()=>{if(S.playing)advanceReplayClock(S.playing,performance.now());S.replaySpeed=Number($(id).value);syncReplayControls();});
for(const id of ['window-speed','ica-window-speed','ica-all-window-speed'])bind(id,'change',()=>{
  const field=$(id),text=field.value.trim(),value=Number(text);
  if(!text||!Number.isFinite(value)||value<0||value>100){field.value=String(S.windowSpeed);throw new Error('Window speed must be a number between 0 and 100 recording seconds per second.');}
  if(S.playing)advanceReplayClock(S.playing,performance.now());
  S.windowSpeed=value;syncReplayControls();saveView();
});
for(const id of ['window-speed','ica-window-speed','ica-all-window-speed'])$(id).addEventListener('keydown',event=>{
  if(event.key==='Enter'){event.preventDefault();event.currentTarget.dispatchEvent(new Event('change',{bubbles:true}));event.currentTarget.blur();}
});
for(const id of ['ica-play','ica-all-play'])bind(id,'click',toggleReplay);
for(const id of ['ica-prev','ica-all-prev'])bind(id,'click',()=>navigate(-1));
for(const id of ['ica-next','ica-all-next'])bind(id,'click',()=>navigate(1));
bind('ica-all-start','change',()=>{const start=Number($('ica-all-start').value);stopPlay();S.replayCursor=null;S.start=start;return syncWindowAndSources();});
for(const id of ['ica-all-window','ica-window'])bind(id,'change',()=>{const duration=Number($(id).value);stopPlay();S.replayCursor=null;S.duration=duration;return syncWindowAndSources();});
bind('ica-all-gain','change',()=>{S.componentGain=Number($('ica-all-gain').value);drawAllComponents();});
bind('ica-all-fit','click',()=>fitAllComponents());
bind('ica-all-exclude','change',()=>saveComponentExclusion(S.component,$('ica-all-exclude').checked));
bind('ica-all-inspect','click',()=>selectTab('ica'));
bind('open-all-components','click',()=>selectTab('ica-all'));
bind('ica-all-canvas','click',event=>{
  if(S.icaAnnotate||S.suppressIcaClick)return;
  const canvas=$('ica-all-canvas'),g=canvas._geometry;if(!g||!S.allComponents)return;
  const rect=canvas.getBoundingClientRect(),row=Math.floor((event.clientY-rect.top-g.top)/g.gap);
  if(row>=0&&row<S.allComponents.components.length){S.component=row;renderModels();drawAllComponents();updateLiveFeedback(S.replayCursor??S.start);}
});
bind('ica-all-canvas','pointermove',event=>{
  const canvas=$('ica-all-canvas'),g=canvas._geometry;if(!g||!S.allComponents)return;
  const rect=canvas.getBoundingClientRect(),t=g.start+Math.max(0,Math.min(1,(event.clientX-rect.left-g.left)/(g.right-g.left)))*(g.end-g.start);
  if(!S.playing)updateLiveFeedback(t);
});
bind('exclude-component','change',()=>saveComponentExclusion(S.component,$('exclude-component').checked));

bind('apply-ica','click',()=>runJob('/api/apply-ica',{project:S.meta.id,model:S.model,excluded:[...S.excluded]},()=>{selectTab('waveforms');$('compare').checked=true;$('compare-panel').hidden=false;$('compare-label').hidden=false;$('secondary-legend').hidden=false;S.compareStage=S.meta.ica_models.find(m=>m.id===S.model).source;syncStages();return refreshWindow(false);}));
bind('export-review','click',()=>runJob('/api/export',{project:S.meta.id,stage:S.stage},result=>{downloadLink(result.download);toast('Export ready. Includes full samples and review decisions.');}));
bind('export-fif','click',()=>runJob('/api/export',{project:S.meta.id,stage:S.stage,fif:true},result=>downloadLink(result.download)));
bind('export-tsv','click',()=>{const a=document.createElement('a');a.href='/api/annotations.tsv?project='+S.meta.id;a.download='annotations.tsv';a.click();});
bind('export-json','click',()=>{const blob=new Blob([JSON.stringify(S.meta,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='review-decisions.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});

document.addEventListener('keydown',e=>{
  if(!S.meta||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)||document.querySelector('dialog[open]'))return;
  if(e.key==='ArrowRight'){e.preventDefault();navigate(1);}else if(e.key==='ArrowLeft'){e.preventDefault();navigate(-1);}
  else if(e.key.toLowerCase()==='a'){if(S.tab==='ica-all')setIcaAnnotationMode(!S.icaAnnotate);else{selectTab('waveforms');setMode('annotate');}}
  else if(e.key.toLowerCase()==='f'&&['ica-all','waveforms','spectrum'].includes(S.tab)){e.preventDefault();toggleViewerFullscreen(S.tab==='ica-all'?document.querySelector('.all-ica-card'):S.tab==='spectrum'?document.querySelector('.spectrum-card'):document.querySelector('.signal-card'));}
  else if(e.key.toLowerCase()==='z')setMode('zoom');else if(e.key.toLowerCase()==='i')setMode('inspect');
  else if(e.key===' '){e.preventDefault();$('play').click();}else if(e.key==='+'||e.key==='=')changeSensitivity(-1);else if(e.key==='-')changeSensitivity(1);
});
let resizeTimer;
new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{renderWaves();drawOverview();drawPSD();if(S.tab==='ica-all')drawAllComponents();if(S.tab==='ica'&&S.componentData){drawComponentMap(S.componentData);loadComponent().catch(e=>toast(e.message,true));}},100);}).observe(document.querySelector('main'));
document.addEventListener('fullscreenchange',()=>requestAnimationFrame(redrawWorkspace));
document.addEventListener('visibilitychange',()=>{if(document.hidden&&S.playing){stopPlay();toast('Replay paused while the browser tab is inactive.');}});
window.addEventListener('error',event=>{if(event.message)toast('Viewer error: '+event.message,true);});
window.addEventListener('unhandledrejection',event=>toast('Viewer request failed: '+(event.reason?.message||event.reason),true));

(async()=>{
  try{
    const init=await api('/api/init');S.token=init.token;await listSessions();setBusy(false);
    document.querySelectorAll('[data-recording]').forEach(b=>b.disabled=true);
    const last=localStorage.getItem('echo-project');if(last&&init.sessions.some(s=>s.id===last))await openSession(last);
  }catch(error){toast(error.message,true);}
})();
