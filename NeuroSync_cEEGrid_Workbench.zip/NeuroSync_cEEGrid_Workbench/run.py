"""Launch NeuroSync - cEEGrid Workbench on localhost. No cloud account or web framework required."""
import argparse
from pathlib import Path
from eeg_server import serve

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='NeuroSync - cEEGrid Workbench local review workbench')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--workspace', type=Path, default=Path(__file__).parent / 'sessions')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    serve(args.workspace, args.port, open_browser=not args.no_browser)
