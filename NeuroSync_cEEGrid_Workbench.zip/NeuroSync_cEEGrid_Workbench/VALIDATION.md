# NeuroSync - cEEGrid Workbench 2.2 · validation

Checked on 29 October 2026.

## Passed

- Python suite: 26 checks passed; one actual-MNE SET-reader check skipped. The
  processing and persistence tests cover filtering, reference, ICA reconstruction,
  annotations, screening, PSD, and SET/FDT upload pairing.
- JavaScript numerical checks cover plot axes, display scaling, row fitting,
  processing lineage, and replay timing.
- DOM + local Python API integration covers ICA layout controls, independently
  sized source and spectrum frames, automatic narrow-screen source view,
  timeline show/hide, a stacked narrow ear map, side-by-side ear maps, all
  electrode labels and label spacing, magnifiers, annotations, and replay.
- Rendered the application's actual canvas drawing functions with a disposable
  18-channel fixture. Visually inspected the 120 px timeline, a 620 px wide
  electrode map, a 330 px stacked electrode map, and a time-course chart. The
  rendered labels and axes fit their respective plots in these examples.
- Replay checks cover independent rates in waveform, all-component and detail
  views, zero-speed window freeze, speed changes during a deliberately delayed
  fetch, automatic redraw, pause and end behavior, and annotation timing.
  DOM and API checks confirm the final paused position, saved window speed,
  removal of the window update control, and changing each window selector
  while paused and during replay, with matching plot data and controls.
- Spectrum integration checks use two independently processed stages, compare them
  over the same interval and channel selection, inspect both curves in the
  magnifier, and exercise whole-screen fallback, F and Escape.
- JavaScript syntax and ZIP integrity checks passed.

## Limits

The plot render checks are actual canvas drawings, but they do not render the
full browser layout. The DOM checks simulate element sizes and browser fullscreen;
the remote browser could not connect to the local Python server. Browser-specific
layout, native fullscreen, touch gestures and the user's own recording have not
been verified here.

The real MNE SET/FDT reader and FIF import/export could not be exercised because
MNE is unavailable in this environment; the reader-protocol tests passed.

On a short screen, ICA detail can scroll within its plot area to keep axes and
labels intact. Selecting Source or Electrode weights, or using Whole screen,
provides more room. On a narrow map the ears are stacked; dots stay at their
projected coordinates and label leader lines do not change those positions.
No recordings or saved sessions are included in the package.
