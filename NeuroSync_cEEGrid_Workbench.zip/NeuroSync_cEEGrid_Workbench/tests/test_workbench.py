"""Run: python -m unittest discover -s tests -v"""
import json
import importlib.util
import tempfile
import threading
import time
import types
import unittest
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np

from eeg_core import Workspace, envelope
from eeg_server import make_server


class FakeEEGLABRaw:
    """Protocol fixture for exercising import and companion-file handling without MNE."""
    def __init__(self):
        self.ch_names=['L01','R01']
        self.n_times=256
        self.first_samp=0
        self.first_time=0.
        self.info={'sfreq':128.,'bads':[],'meas_date':None}
        self.annotations=[]
        self.samples=np.ones((2,256))*20e-6
        self.closed=False
    def get_montage(self):return None
    def get_channel_types(self):return ['eeg','eeg']
    def get_data(self,start=0,stop=None):return self.samples[:,start:stop]
    def close(self):self.closed=True


def fake_mne(reader):
    return types.SimpleNamespace(io=types.SimpleNamespace(
        read_raw_edf=reader,read_raw_bdf=reader,read_raw_fif=reader,read_raw_eeglab=reader))


class ProcessingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.w = Workspace(self.tmp.name)
        self.sf = 128.
        self.t = np.arange(128*40)/self.sf
        x = np.vstack([np.sin(2*np.pi*10*self.t), np.sin(2*np.pi*4*self.t), np.cos(2*np.pi*18*self.t)])*10e-6
        self.p = self.w.create('Test EEG', x, self.sf, ['L01','R01','L04b'])

    def tearDown(self):
        self.tmp.cleanup()

    def test_ica_replay_annotation_context_survives_restart_and_export(self):
        def model(meta):
            meta['ica_models'].append({'id':'test-model','n_components':3})
        self.w.update(self.p,model)
        context={'view':'ica-all','model':'test-model','component':1}
        self.w.annotation(self.p,{'start':2.5,'end':3.25,'label':'NOTE','note':'Observed in replay','context':context})
        saved=Workspace(self.tmp.name).meta(self.p)['annotations'][0]
        self.assertEqual(saved['context'],dict(context,scope='recording-time'))
        self.assertEqual(saved['note'],'Observed in replay')
        with self.assertRaisesRegex(ValueError,'model not found'):
            self.w.annotation(self.p,{'start':1,'end':2,'context':dict(context,model='missing')})
        with self.assertRaisesRegex(ValueError,'Invalid annotation component'):
            self.w.annotation(self.p,{'start':1,'end':2,'context':dict(context,component=10)})

    def test_samples_and_display_envelope_preserve_peaks(self):
        data = np.zeros((1, 10000)); data[0,1234]=100e-6; data[0,1235]=-50e-6
        traces, bucket = envelope(data,1000,4,max_points=200)
        self.assertGreater(bucket,1)
        self.assertIn(100.,traces[0]['y'])
        self.assertIn(-50.,traces[0]['y'])
        self.assertTrue(np.all(np.diff(traces[0]['x'])>=0))
        self.assertAlmostEqual(traces[0]['x'][traces[0]['y'].index(100.)],5.234)

    def test_waveform_diagnostics_preserve_large_dc_offsets(self):
        x=np.array([[.020-.00001,.020,.020+.00001,.020]*100,[-.01,-.01,-.01,-.01]*100])
        p=self.w.create('DC offsets',x,100,['L01','R01'])
        window=self.w.window(p,'raw',0,4)
        self.assertEqual(window['channels'],['L01','R01'])
        self.assertAlmostEqual(window['stats'][0]['median_uv'],20000)
        self.assertAlmostEqual(window['stats'][0]['max_uv']-window['stats'][0]['min_uv'],20)
        self.assertEqual(window['stats'][0]['finite_samples'],400)
        self.assertAlmostEqual(window['stats'][1]['median_uv'],-10000)
        self.assertEqual(window['stats'][1]['rms_ac_uv'],0)
        np.testing.assert_array_equal(self.w.stage(p,'raw')[2],x)

    def test_annotation_validation_and_restart_persistence(self):
        m=self.w.annotation(self.p,{'start':2,'end':4,'label':'BAD_movement','note':'test'})
        ann=m['annotations'][0]
        reopened=Workspace(self.tmp.name)
        self.assertEqual(reopened.meta(self.p)['annotations'][0]['id'],ann['id'])
        with self.assertRaises(ValueError): self.w.annotation(self.p,{'start':5,'end':4})
        self.w.annotation(self.p,{'id':ann['id'],'start':3,'end':5,'label':'NOTE','note':'edited'})
        self.assertEqual(self.w.meta(self.p)['annotations'][0]['start'],3)
        self.w.annotation(self.p,{'id':ann['id'],'delete':True})
        self.assertFalse(self.w.meta(self.p)['annotations'])

    def test_psd_bad_windows_and_nonbad_notes(self):
        before=self.w.psd(self.p,'raw')
        self.assertEqual(before['accepted_windows'],19)
        self.w.annotation(self.p,{'start':0,'end':4,'label':'NOTE'})
        self.assertEqual(self.w.psd(self.p,'raw')['accepted_windows'],19)
        self.w.annotation(self.p,{'start':0,'end':4,'label':'BAD_artifact'})
        after=self.w.psd(self.p,'raw')
        self.assertEqual(after['accepted_windows'],17)
        alpha=after['bandpower_db']['Alpha']
        self.assertGreater(alpha[0],alpha[1]+20)

    def test_reference_math_and_original_preservation(self):
        original=np.array(self.w.stage(self.p,'raw')[2])
        with self.assertRaises(ValueError): self.w.reference(self.p,'raw','linked',False)
        reference=self.w.reference(self.p,'raw','linked',True)
        output=self.w.stage(self.p,reference)[2]
        np.testing.assert_allclose(output,original-.5*original[2])
        np.testing.assert_array_equal(self.w.stage(self.p,'raw')[2],original)
        with self.assertRaises(ValueError): self.w.reference(self.p,reference,'linked',True)

    def test_repeated_average_reference_reuses_existing_stage(self):
        reference=self.w.reference(self.p,'raw','average')
        count=len(self.w.meta(self.p)['stages'])
        self.assertEqual(self.w.reference(self.p,reference,'average'),reference)
        self.assertEqual(len(self.w.meta(self.p)['stages']),count)
        self.w.bad_channels(self.p,['R01'])
        changed=self.w.reference(self.p,reference,'average')
        self.assertNotEqual(changed,reference)
        self.assertEqual(self.w.processing_context(self.w.meta(self.p),changed)['reference']['reference_channels'],['L01','L04b'])

    def test_lineage_does_not_misrepresent_unrelated_branches(self):
        branch_a=self.w.filter(self.p,'raw',1,40)
        branch_b=self.w.filter(self.p,'raw',2,30)
        referenced=self.w.reference(self.p,branch_a,'average')
        m=self.w.meta(self.p)
        self.assertEqual([s['id'] for s in self.w.lineage(m,referenced)],['raw',branch_a,referenced])
        self.assertNotIn(branch_b,self.w.processing_context(m,referenced)['lineage'])
        self.assertEqual(self.w.processing_context(m,referenced)['known_highpass_hz'],1)

    def test_ica_does_not_refilter_an_already_one_hz_source(self):
        filtered=self.w.filter(self.p,'raw',1,40)
        referenced=self.w.reference(self.p,filtered,'average')
        with patch('eeg_core.signal.sosfiltfilt',side_effect=AssertionError('Unexpected repeated filtering')):
            model=self.w.fit_ica(self.p,referenced)
        info=self.w.model(self.p,model)[1]
        self.assertIsNone(info['additional_highpass_hz'])
        self.assertEqual(info['source_context']['known_highpass_hz'],1)
        self.assertEqual(info['source_context']['known_lowpass_hz'],40)
        self.assertEqual(info['source_context']['source'],referenced)
        model_raw=self.w.fit_ica(self.p,'raw')
        self.assertEqual(self.w.model(self.p,model_raw)[1]['additional_highpass_hz'],1)

    def test_filter_attenuates_out_of_band_without_modifying_original(self):
        x=np.vstack([np.sin(2*np.pi*10*self.t)+np.sin(2*np.pi*45*self.t)])*1e-5
        p=self.w.create('Filter test',x,self.sf,['L01'])
        out=self.w.filter(p,'raw',1,30)
        y=self.w.stage(p,out)[2][0,128:-128]
        t=self.t[128:-128]
        def amplitude(f): return abs(np.mean(y*np.exp(-2j*np.pi*f*t)))*2
        self.assertGreater(amplitude(10),8e-6)
        self.assertLess(amplitude(45),1e-6)
        np.testing.assert_array_equal(self.w.stage(p,'raw')[2],x)

    def test_bad_channels_omitted_from_analysis(self):
        self.w.bad_channels(self.p,['R01'])
        self.assertNotIn('R01',self.w.psd(self.p,'raw')['channels'])
        with self.assertRaises(ValueError): self.w.bad_channels(self.p,['invented'])

    def test_viewed_intervals_merge(self):
        self.w.viewed(self.p,0,10);self.w.viewed(self.p,8,15);self.w.viewed(self.p,20,25)
        self.assertEqual(self.w.meta(self.p)['viewed'],[[0.,15.],[20.,25.]])

    def test_screening_never_automatically_marks_bad(self):
        original=np.array(self.w.stage(self.p,'raw')[2]);original[0,128*20:128*22]*=100
        p=self.w.create('Burst',original,self.sf,['L01','R01','L04b'])
        result=self.w.screen(p,'raw',p2p_uv=200)
        self.assertGreater(result['candidates'],0)
        self.assertFalse(self.w.meta(p)['annotations'])
        candidate=self.w.meta(p)['suggestions'][0]
        self.w.resolve_suggestion(p,candidate['id'],True)
        self.assertTrue(self.w.meta(p)['annotations'][0]['label'].startswith('BAD'))
        with self.assertRaises(ValueError):self.w.resolve_suggestion(p,candidate['id'],True)

    def test_export_contains_samples_annotations_and_replay(self):
        self.w.annotation(self.p,{'start':2,'end':4,'label':'BAD_artifact'})
        filename=self.w.export(self.p,'raw')
        with zipfile.ZipFile(Path(self.tmp.name)/self.p/'exports'/filename) as z:
            self.assertTrue({'data.npy','session.json','annotations.tsv','load_review.py'}.issubset(z.namelist()))
            exported=json.loads(z.read('session.json'))
            self.assertEqual(exported['annotations'][0]['start'],2)
            self.assertEqual(exported['data_units'],'V')
            compile(z.read('load_review.py'),'load_review.py','exec')

    def test_npz_microvolt_import(self):
        path=Path(self.tmp.name)/'data.npz'
        np.savez(path,data=np.ones((2,100))*20,sfreq=100,ch_names=np.array(['L01','R01']))
        p=self.w.import_file(path,units='uV')
        np.testing.assert_allclose(self.w.stage(p,'raw')[2],20e-6)

    def test_set_reader_options_and_no_second_voltage_scaling(self):
        path=Path(self.tmp.name)/'participant.set';path.write_bytes(b'fixture')
        calls=[]
        raw=FakeEEGLABRaw()
        def reader(filename,**kwargs):calls.append((filename,kwargs));return raw
        with patch('eeg_core.require_mne',return_value=fake_mne(reader)):
            p=self.w.import_file(path,units='uV',montage_units='mm',uint16_codec='utf-8')
        self.assertEqual(calls[0][1]['montage_units'],'mm')
        self.assertEqual(calls[0][1]['uint16_codec'],'utf-8')
        self.assertEqual(calls[0][1]['eog'],'auto')
        np.testing.assert_allclose(self.w.stage(p,'raw')[2],20e-6)
        self.assertEqual(self.w.meta(p)['source']['format'],'set')
        self.assertTrue(raw.closed)

    def test_set_missing_companion_error(self):
        path=Path(self.tmp.name)/'participant.set';path.write_bytes(b'fixture')
        def reader(*args,**kwargs):raise FileNotFoundError('participant.fdt')
        with patch('eeg_core.require_mne',return_value=fake_mne(reader)):
            with self.assertRaisesRegex(ValueError,'original .fdt'):
                self.w.import_file(path)

    def test_epoched_set_is_not_silently_flattened(self):
        path=Path(self.tmp.name)/'epoched.set';path.write_bytes(b'fixture')
        def reader(*args,**kwargs):raise ValueError('The number of trials is 10. Please use epochs.')
        with patch('eeg_core.require_mne',return_value=fake_mne(reader)):
            with self.assertRaisesRegex(ValueError,'not silently concatenated'):
                self.w.import_file(path)

    @unittest.skipUnless(importlib.util.find_spec('mne'), 'MNE not installed: real SET reader integration')
    def test_real_embedded_and_external_set_import(self):
        from scipy.io import savemat
        # EEGLAB stores continuous samples in microvolts; its MNE reader returns volts.
        expected=np.vstack([np.sin(2*np.pi*10*np.arange(512)/128),np.cos(2*np.pi*6*np.arange(512)/128)]).astype('float32')*20
        chanlocs=np.empty(2,dtype=[('labels','O'),('X','O'),('Y','O'),('Z','O')])
        chanlocs[0]=('L01',20.,80.,-40.)
        chanlocs[1]=('R01',20.,-80.,-40.)
        base=dict(setname='Synthetic EEGLAB',nbchan=2,pnts=512,trials=1,srate=128.,xmin=0.,xmax=511/128,
                  chanlocs=chanlocs,event=np.empty((0,0)),icaweights=np.empty((0,0)),icasphere=np.empty((0,0)))
        for external in [False,True]:
            name='external' if external else 'embedded'
            data=expected
            if external:
                expected.T.astype('<f4').tofile(Path(self.tmp.name)/(name+'.fdt'))
                data=name+'.fdt'
            path=Path(self.tmp.name)/(name+'.set')
            savemat(path,{'EEG':dict(base,data=data)})
            p=self.w.import_file(path,montage_units='mm')
            np.testing.assert_allclose(self.w.stage(p,'raw')[2],expected.astype(float)*1e-6,atol=1e-12)

    def test_full_length_5385_second_recording_navigation(self):
        sfreq=125.
        n_samples=673244  # Exactly 5385.952 seconds at 125 Hz.
        x=np.zeros((2,n_samples),dtype=float)
        x[0,-100:]=50e-6
        p=self.w.create('90-minute navigation',x,sfreq,['L01','R01'])
        self.assertAlmostEqual(self.w.meta(p)['duration'],5385.952)
        result=self.w.window(p,'raw',5375.952,10)
        self.assertGreater(result['end'],5385.9)
        self.assertIn(50.,result['traces'][0]['y'])
        self.assertEqual(len(self.w.overview(p,'raw')['times']),2693)

    def test_ica_correction_and_stale_model_guard(self):
        rng=np.random.default_rng(12)
        samples=12000
        sources=np.column_stack([rng.laplace(size=samples),rng.uniform(-2,2,size=samples),rng.standard_t(5,size=samples)])
        mixing=np.array([[1.,.2,.5],[.4,1.,.3],[.2,.3,1.],[.8,.4,.5]])
        data=(sources@mixing.T).T*1e-5
        p=self.w.create('ICA test',data,128,['L01','L02','R01','R02'])
        model=self.w.fit_ica(p,'raw')
        m,info,arr=self.w.model(p,model)
        self.assertTrue(info['converged'])
        self.assertEqual(info['rank'],3)
        selected=self.w.select_components(p,model,[0])
        self.assertEqual(selected['ica_models'][0]['selected_excluded'],[0])
        stage=self.w.apply_ica(p,model,[0])
        observed=self.w.stage(p,stage)[2]
        eeg=data.T*1e6
        expected=data-(((eeg-arr['mean'])@arr['components'][[0]].T)@arr['mixing'][:,[0]].T).T/1e6
        np.testing.assert_allclose(observed,expected,rtol=1e-10,atol=1e-15)
        self.assertGreater(np.max(np.abs(observed-data)),1e-6)
        np.testing.assert_array_equal(self.w.stage(p,'raw')[2],data)
        component=self.w.component(p,model,0,0,5)
        self.assertEqual(len(component['weights']),4)
        self.w.annotation(p,{'start':2,'end':3,'label':'BAD_artifact'})
        with self.assertRaisesRegex(ValueError,'Refit ICA'):self.w.apply_ica(p,model,[0])

    def test_all_component_plot_matches_individual_sources(self):
        rng=np.random.default_rng(21)
        sources=rng.laplace(size=(6000,3))
        mixing=np.array([[1.,.2,.5],[.4,1.,.3],[.2,.3,1.]])
        data=(sources@mixing.T).T*1e-5
        p=self.w.create('Combined source plot',data,128,['L01','L02','R01'])
        model=self.w.fit_ica(p,'raw')
        combined=self.w.all_components(p,model,5,4)
        self.assertEqual(combined['components'],['IC000','IC001','IC002'])
        self.assertEqual(combined['units'],'a.u.')
        self.assertEqual(combined['source'],'raw')
        self.assertEqual(combined['start'],5)
        for i in range(3):
            individual=self.w.component(p,model,i,5,4)
            np.testing.assert_allclose(combined['traces'][i]['y'],individual['trace']['y'],atol=1e-12)
            self.assertEqual(combined['traces'][i]['x'],individual['trace']['x'])
            self.assertAlmostEqual(combined['stats'][i]['rms'],individual['source_stats']['rms'])
            self.assertAlmostEqual(combined['stats'][i]['peak_to_peak'],individual['source_stats']['peak_to_peak'])
        np.testing.assert_array_equal(self.w.stage(p,'raw')[2],data)
        with self.assertRaises(ValueError):self.w.all_components(p,model,1000,10)


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.server=make_server(self.tmp.name,0)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'
        with urllib.request.urlopen(self.url+'/api/init') as response:self.init=json.load(response)

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.server.jobs.executor.shutdown(wait=True);self.tmp.cleanup()

    def test_http_assets_and_token_boundary(self):
        for path in ['/','/app.js','/style.css']:
            with urllib.request.urlopen(self.url+path) as response:self.assertEqual(response.status,200)
        request=urllib.request.Request(self.url+'/api/demo',data=b'{}',headers={'Content-Type':'application/json'})
        with self.assertRaises(urllib.error.HTTPError) as caught:urllib.request.urlopen(request)
        self.assertEqual(caught.exception.code,403)
        request=urllib.request.Request(self.url+'/api/demo',data=b'{"duration":20}',headers={'Content-Type':'application/json','X-Echo-Token':self.init['token']})
        with self.assertRaises(urllib.error.HTTPError) as caught:urllib.request.urlopen(request)
        self.assertEqual(caught.exception.code,404)  # Demo generation is removed.
        self.assertFalse(hasattr(self.server.workspace, 'demo'))

    def test_deny_path_traversal(self):
        with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(self.url+'/%2e%2e/eeg_core.py')

    def request_json(self,route,body):
        request=urllib.request.Request(self.url+route,data=json.dumps(body).encode(),headers={
            'Content-Type':'application/json','X-Echo-Token':self.init['token']})
        with urllib.request.urlopen(request) as response:return json.load(response)

    def upload(self,batch,name,data):
        request=urllib.request.Request(self.url+'/api/upload',data=data,headers={
            'X-Echo-Token':self.init['token'],'X-Upload-Batch':batch,'X-Filename':name})
        with urllib.request.urlopen(request) as response:return json.load(response)

    def test_set_fdt_batch_keeps_original_companion_names(self):
        batch=self.request_json('/api/upload-batch',{})['batch']
        self.upload(batch,'participant.set',b'set fixture')
        self.upload(batch,'participant.fdt',b'fdt fixture')
        seen=[]
        def reader(filename,**kwargs):
            path=Path(filename)
            self.assertEqual(path.name,'participant.set')
            self.assertEqual((path.parent/'participant.fdt').read_bytes(),b'fdt fixture')
            seen.append(path)
            return FakeEEGLABRaw()
        with patch('eeg_core.require_mne',return_value=fake_mne(reader)):
            job=self.request_json('/api/import-upload',{'batch':batch,'montage_units':'mm'})
            for _ in range(100):
                with urllib.request.urlopen(self.url+'/api/job?id='+job['id']) as response:job=json.load(response)
                if job['status'] in ['done','error']:break
                time.sleep(.01)
        self.assertEqual(job['status'],'done',job)
        self.assertEqual(len(seen),1)
        self.assertFalse(seen[0].parent.exists())
        self.assertEqual(self.server.workspace.meta(job['result']['project'])['source']['format'],'set')

    def test_upload_batch_isolation_and_filename_validation(self):
        first=self.request_json('/api/upload-batch',{})['batch']
        second=self.request_json('/api/upload-batch',{})['batch']
        self.upload(first,'participant.set',b'first')
        self.upload(second,'participant.set',b'second')
        root=Path(self.tmp.name)/'_uploads'
        self.assertEqual((root/first/'participant.set').read_bytes(),b'first')
        self.assertEqual((root/second/'participant.set').read_bytes(),b'second')
        with self.assertRaises(urllib.error.HTTPError):self.upload(first,'../escape.fdt',b'no')
        self.request_json('/api/cancel-upload',{'batch':first})
        self.request_json('/api/cancel-upload',{'batch':second})

    def test_fdt_alone_and_unrelated_multi_recording_are_rejected(self):
        batch=self.request_json('/api/upload-batch',{})['batch']
        self.upload(batch,'participant.fdt',b'companion')
        with self.assertRaises(urllib.error.HTTPError):self.request_json('/api/import-upload',{'batch':batch})
        self.upload(batch,'first.set',b'one')
        self.upload(batch,'second.set',b'two')
        with self.assertRaises(urllib.error.HTTPError):self.request_json('/api/import-upload',{'batch':batch})
        self.request_json('/api/cancel-upload',{'batch':batch})


if __name__=='__main__':
    unittest.main()
