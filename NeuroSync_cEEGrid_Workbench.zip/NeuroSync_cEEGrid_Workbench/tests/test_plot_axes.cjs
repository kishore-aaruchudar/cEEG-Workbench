/* Unit-test the actual canvas drawing functions without a browser or DOM engine.
 * This checks axis text and finite plot coordinates; it is not visual browser QA.
 */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=require('node:path').join(__dirname,'..','static');
const app=fs.readFileSync(root+'/app.js','utf8'),ica=fs.readFileSync(root+'/ica_view.js','utf8');
const labels=[];
const noop=()=>{};
const context=new Proxy({
  fillText(text,...numbers){labels.push(String(text));assert.ok(numbers.every(Number.isFinite),'Finite axis/label positions');},
  measureText(text){return {width:String(text).length*5};},
  createLinearGradient(){return {addColorStop:noop};},
}, {get(target,key){if(key in target)return target[key];return (...args)=>{for(const n of args.filter(v=>typeof v==='number'))assert.ok(Number.isFinite(n),'Finite canvas coordinates');};}});
const elements=new Map();
function element(id){if(!elements.has(id))elements.set(id,{hidden:false,checked:id==='center-traces'||id==='clip-rows',style:{},parentElement:{clientWidth:900},getContext:()=>context});return elements.get(id);}
const trace={x:[5,5.25,5.5,5.75],y:[-.1,0,.1,0]};
const sourceData={components:['IC000','IC001'],start:5,end:5.75,traces:[trace,trace],stats:[{median:0},{median:0}]};
const sandbox={console,Math,Number,Set,window:{devicePixelRatio:1},$ : element,
  S:{tab:'waveforms',start:5,duration:1,sensitivity:30,replayCursor:null,component:0,componentGain:1,excluded:new Set(),allComponents:sourceData,
     meta:{duration:10,bad_channels:[],annotations:[],viewed:[],suggestions:[]},overview:{times:[0,2,4,6,8],rms_uv:[1,2,3,2,1]}},
  timeLabel:seconds=>String(seconds),moveReplayPlayheads:noop,EEGDisplay:require('../static/signal_display.js')};
vm.createContext(sandbox);
function load(source,name){const start=source.indexOf('function '+name+'(');assert.ok(start>=0,name+' exists');let end=source.indexOf('\nfunction ',start+10);if(end<0)end=source.indexOf('\nasync function ',start+10);if(end<0)end=source.length;vm.runInContext(source.slice(start,end),sandbox);}
for(const name of ['setupCanvas','drawWave','drawOverview','lineChart','weightColor','drawComponentMap'])load(app,name);
for(const name of ['drawAllComponents','niceTimeStep'])load(ica,name);
sandbox.drawWave(element('wave-main'),{channels:['L01'],traces:[trace],stats:[{median_uv:0}]},'#147d78');
assert.ok(labels.includes('Elapsed recording time (s)'));
assert.ok(labels.includes('EEG channel · amplitude (µV)'));
sandbox.drawOverview();assert.ok(labels.includes('Median RMS (µV)'));
assert.ok(labels.includes('Elapsed recording time (mm:ss / hh:mm:ss)'));
sandbox.lineChart(element('spectrum'),[{x:[0,1,2],y:[-20,-10,-15],color:'#147d78'}],{yLabel:'PSD (dB re 1 µV²/Hz)'});
assert.ok(labels.includes('Frequency (Hz)'));assert.ok(labels.includes('PSD (dB re 1 µV²/Hz)'));
sandbox.lineChart(element('source'),[{x:[5,6,7],y:[-.02,.02,0],color:'#147d78'}],{xLabel:'Time (s)',yLabel:'Source (a.u.)',height:180});
assert.ok(labels.includes('Time (s)'));assert.ok(labels.includes('Source (a.u.)'));
sandbox.drawComponentMap({channels:['L01','R01'],weights:[-1,1],positions:{L01:[-.08,.02,-.04],R01:[.08,.02,-.04]}});
assert.ok(labels.includes('−y (mm) · anterior ←'));assert.ok(labels.includes('z (mm) · superior ↑'));
sandbox.S.tab='ica-all';sandbox.drawAllComponents();assert.ok(labels.includes('ICA component · amplitude (a.u.)'));
console.log('Canvas unit checks passed: waveform, overview, PSD, source time, ear coordinates, and all-ICA axes.');
