const assert=require('node:assert/strict');
const pipeline=require('../static/pipeline.js');
const m={channels:['L01','R01'],channel_types:['eeg','eeg'],bad_channels:[],stages:[
  {id:'raw',kind:'raw',parent:null,params:{}},
  {id:'filtered',kind:'filtered',parent:'raw',params:{highpass_hz:1,lowpass_hz:70}},
  {id:'other',kind:'filtered',parent:'raw',params:{highpass_hz:.1,lowpass_hz:40}},
  {id:'ref',kind:'reference',parent:'filtered',params:{mode:'average',reference_channels:['L01','R01']}},
]};
assert.deepEqual(pipeline.lineage(m,'ref').map(s=>s.id),['raw','filtered','ref']);
assert.equal(pipeline.plan(m,'ref').highpass,1);
assert.equal(pipeline.plan(m,'ref').lowpass,70);
assert.equal(pipeline.plan(m,'ref').additionalHighpass,false);
assert.equal(pipeline.plan(m,'other').additionalHighpass,true);
assert.equal(pipeline.plan(m,'raw').additionalHighpass,true);
assert.equal(pipeline.sameAverage(m,'ref','average'),true);
assert.equal(pipeline.sameAverage(m,'ref','linked'),false);
m.bad_channels=['R01'];assert.equal(pipeline.sameAverage(m,'ref','average'),false);
m.bad_channels=[];
m.stages.push({id:'legacy_ref',kind:'reference',parent:'ref',params:{mode:'average',reference_channels:['L01','R01']}});
assert.equal(pipeline.plan(m,'legacy_ref').duplicateReferences,1);
console.log('Pipeline checks passed: branch lineage, 1–70 Hz source, private-fit policy, reference reuse, changed bad channels.');
