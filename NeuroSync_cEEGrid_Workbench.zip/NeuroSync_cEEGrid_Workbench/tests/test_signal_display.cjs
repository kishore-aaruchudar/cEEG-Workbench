/* Run: node tests/test_signal_display.cjs */
const assert=require('node:assert/strict');
const display=require('../static/signal_display.js');

// Every row fits the allocated plotting area, including small mobile windows.
for(const available of [120,220,380,700])for(const count of [1,4,18,64]){
  const g=display.layout(available,count);
  assert.equal(g.height,available);
  assert.ok(g.gap>0&&g.division>0);
  assert.ok(Math.abs(g.top+g.gap*count+g.bottom-available)<1e-8);
  assert.ok(g.division<=g.gap*.32+1e-8);
  assert.equal(display.pixel(30,100,30,0,g.division),100-g.division);
}
const reading=display.layout(380,18,28,40,false),whole=display.layout(380,18,28,40,true);
assert.equal(reading.gap,40);
assert.equal(whole.height,380);
assert.ok(reading.height>whole.height);

const trace={x:[0,1,2,3],y:[19990,20000,20010,20000]};
const original=trace.y.slice();
const stats={channel:'L01',finite_samples:4,median_uv:20000,min_uv:19990,max_uv:20010,q01_uv:19990,q99_uv:20010};
const pane={traces:[trace],stats:[stats]};
const offset=display.center(stats,trace,true);
assert.equal(offset,20000);
assert.equal(display.pixel(20000,70,30,offset),70);
assert.ok(Math.abs(display.pixel(20010,70,30,offset)-70)<10);
assert.ok(display.pixel(20000,70,30,0)<-10000); // Regression: original offset was far off-screen.
assert.deepEqual(trace.y,original); // Display centering must never mutate sample values.
assert.deepEqual(display.status(pane,true,30).clipped,[]);
assert.deepEqual(display.status(pane,false,30).clipped,['L01']);
assert.equal(display.center(stats,trace,false),0);
assert.equal(display.center(null,trace,true),20000);

// A single global sensitivity fits both panes; channel gain ratios are preserved.
const second={traces:[{x:[0,1,2],y:[-1020,-1000,-980]}],stats:[{finite_samples:3,median_uv:-1000,min_uv:-1020,max_uv:-980,q01_uv:-1020,q99_uv:-980}]};
const sensitivity=display.fit([pane,second],true);
assert.ok(sensitivity>=20*22/27);
const displacement=(v,center)=>Math.abs(display.pixel(v,0,sensitivity,center));
assert.equal(displacement(20010,20000)/displacement(20001,20000),10);

const empty={traces:[{y:[null,null]}],stats:[{channel:'R01',finite_samples:0}]};
assert.equal(display.fit([empty],true),5);
assert.deepEqual(display.status(empty,true,30).invalid,['R01']);
assert.equal(display.center(null,empty.traces[0],true),0);
const flat={traces:[{y:[5,5]}],stats:[{channel:'R02',finite_samples:2,median_uv:5,min_uv:5,max_uv:5,q01_uv:5,q99_uv:5}]};
assert.deepEqual(display.status(flat,true,30).nearFlat,['R02']);
console.log('Display regression checks passed: large DC offsets, shared scale, unchanged samples, invalid/flat traces.');
