"""Small localhost HTTP API. Long processing runs in background job threads."""
from __future__ import annotations

import json
import mimetypes
import re
import secrets
import shutil
import threading
import traceback
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from eeg_core import Workspace, identifier, now


class Jobs:
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='eeg-job')
        self.jobs = {}
        self.lock = threading.Lock()

    def submit(self, label, operation, project=None):
        job_id = identifier()
        with self.lock:
            self.jobs[job_id] = {'id': job_id, 'label': label, 'status': 'queued',
                                 'project': project, 'created_at': now()}
        def run():
            with self.lock:
                self.jobs[job_id]['status'] = 'running'
            try:
                result = operation()
                with self.lock:
                    self.jobs[job_id].update(status='done', result=result, finished_at=now())
            except Exception as exc:
                traceback.print_exc()
                with self.lock:
                    self.jobs[job_id].update(status='error', error=str(exc), finished_at=now())
        self.executor.submit(run)
        return self.jobs[job_id].copy()

    def get(self, job_id):
        with self.lock:
            if job_id not in self.jobs:
                raise ValueError('Job not found; the server may have restarted. Reopen the saved session.')
            return self.jobs[job_id].copy()


def make_server(workspace, port=8765):
    workspace = Workspace(workspace)
    jobs = Jobs()
    token = secrets.token_urlsafe(32)
    static = Path(__file__).resolve().parent / 'static'

    def upload_directory(batch):
        if not re.fullmatch(r'[a-f0-9]{32}', str(batch)):
            raise ValueError('Invalid upload batch.')
        folder = workspace.root / '_uploads' / batch
        if not folder.is_dir():
            raise ValueError('Upload batch not found. Select the files again.')
        return folder

    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def log_message(self, format, *args):
            # Keep the console useful: errors and processing tracebacks only.
            if args and str(args[1] if len(args) > 1 else '') not in ('200', '202', '304'):
                super().log_message(format, *args)

        def send(self, value, status=200):
            data = json.dumps(value, allow_nan=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def permitted(self, mutation=False):
            host = self.headers.get('Host', '').split(':')[0].lower()
            if host not in ('127.0.0.1', 'localhost'):
                raise PermissionError('Use localhost or 127.0.0.1 to open this local app.')
            if self.headers.get('Sec-Fetch-Site') == 'cross-site':
                raise PermissionError('Cross-site requests are not permitted.')
            origin = self.headers.get('Origin')
            if origin and urlparse(origin).netloc != self.headers.get('Host'):
                raise PermissionError('Origin does not match this local app.')
            if mutation and not secrets.compare_digest(self.headers.get('X-Echo-Token', ''), token):
                raise PermissionError('Session token missing; reload the app page.')

        def file(self, path, attachment=False):
            if not path.is_file():
                raise ValueError('File not found.')
            self.send_response(200)
            self.send_header('Content-Type', mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
            self.send_header('Content-Length', str(path.stat().st_size))
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
            if not attachment:
                self.send_header('Cache-Control', 'no-store')
            if attachment:
                self.send_header('Content-Disposition', f'attachment; filename="{path.name}"')
            self.end_headers()
            with path.open('rb') as stream:
                shutil.copyfileobj(stream, self.wfile)

        def do_GET(self):
            try:
                self.permitted()
                parsed = urlparse(self.path)
                route = parsed.path
                q = {k: v[-1] for k, v in parse_qs(parsed.query).items()}
                if route == '/api/init':
                    return self.send({'token': token, 'sessions': workspace.projects(), 'version': '2.2.0'})
                if route == '/api/sessions':
                    return self.send(workspace.projects())
                if route == '/api/session':
                    return self.send(workspace.meta(q['project']))
                if route == '/api/job':
                    return self.send(jobs.get(q['id']))
                if route == '/api/window':
                    return self.send(workspace.window(q['project'], q['stage'], float(q.get('start', 0)),
                                                     float(q.get('duration', 10)), json.loads(q['channels']) if 'channels' in q else None))
                if route == '/api/overview':
                    return self.send(workspace.overview(q['project'], q['stage']))
                if route == '/api/component':
                    return self.send(workspace.component(q['project'], q['model'], int(q['component']),
                                                        float(q.get('start', 0)), float(q.get('duration', 10))))
                if route == '/api/components':
                    return self.send(workspace.all_components(q['project'], q['model'],
                                                            float(q.get('start', 0)), float(q.get('duration', 10))))
                if route == '/api/review.json':
                    return self.send(workspace.meta(q['project']))
                if route == '/api/download':
                    filename = q['file']
                    if Path(filename).name != filename:
                        raise ValueError('Invalid export filename.')
                    return self.file(workspace.directory(q['project'])/'exports'/filename, attachment=True)
                if route == '/api/annotations.tsv':
                    data = workspace.review_csv(q['project']).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/tab-separated-values; charset=utf-8')
                    self.send_header('Content-Disposition', 'attachment; filename="annotations.tsv"')
                    self.send_header('Content-Length', str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if route.startswith('/api/'):
                    return self.send({'error': 'Endpoint not found.'}, 404)
                relative = 'index.html' if route == '/' else unquote(route).lstrip('/')
                path = (static/relative).resolve()
                if not path.is_relative_to(static):
                    raise ValueError('Invalid asset path.')
                return self.file(path)
            except PermissionError as exc:
                self.send({'error': str(exc)}, 403)
            except (KeyError, ValueError, OSError) as exc:
                self.send({'error': str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                traceback.print_exc()
                self.send({'error': str(exc)}, 500)

        def do_POST(self):
            try:
                self.permitted(mutation=True)
                parsed = urlparse(self.path)
                route = parsed.path
                if route == '/api/upload':
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= 8*1024**3:
                        raise ValueError('Choose a file below 8 GB, or use its local path.')
                    name = unquote(self.headers.get('X-Filename', 'recording'))
                    if not name or Path(name).name != name or '/' in name or '\\' in name or any(ord(c) < 32 for c in name):
                        raise ValueError('A plain upload filename is required.')
                    batch = self.headers.get('X-Upload-Batch')
                    if Path(name).suffix.lower() not in ['.npz', '.edf', '.bdf', '.fif', '.set', '.fdt']:
                        raise ValueError('Supported files: EDF, BDF, FIF, SET (+ FDT), NPZ.')
                    if Path(name).suffix.lower() == '.fdt' and not batch:
                        raise ValueError('Select FDT together with its SET file.')
                    uploads = upload_directory(batch) if batch else workspace.root / '_uploads' / identifier()
                    uploads.mkdir(parents=True, exist_ok=True)
                    path = uploads / name
                    if path.exists():
                        raise ValueError('Duplicate filename in this upload batch.')
                    try:
                        with path.open('wb') as stream:
                            remaining = length
                            while remaining:
                                block = self.rfile.read(min(1024*1024, remaining))
                                if not block:
                                    raise ValueError('File upload interrupted.')
                                stream.write(block)
                                remaining -= len(block)
                    except Exception:
                        path.unlink(missing_ok=True)
                        raise
                    if batch:
                        return self.send({'batch': batch, 'uploaded': name})
                    units = self.headers.get('X-Data-Units', 'V')
                    def import_uploaded():
                        try:
                            return {'project': workspace.import_file(path, name=name, units=units)}
                        finally:
                            shutil.rmtree(uploads, ignore_errors=True)
                    return self.send(jobs.submit('Import recording', import_uploaded), 202)
                length = int(self.headers.get('Content-Length', '0'))
                if length > 2*1024**2:
                    raise ValueError('Request body too large.')
                body = json.loads(self.rfile.read(length) or b'{}')
                p = body.get('project')
                if route == '/api/upload-batch':
                    batch = identifier()
                    (workspace.root / '_uploads' / batch).mkdir(parents=True)
                    return self.send({'batch': batch})
                if route == '/api/cancel-upload':
                    shutil.rmtree(upload_directory(body['batch']))
                    return self.send({'status': 'cancelled'})
                if route == '/api/import-upload':
                    folder = upload_directory(body['batch'])
                    files = list(folder.iterdir())
                    primary = [f for f in files if f.suffix.lower() != '.fdt']
                    if len(primary) != 1:
                        raise ValueError('Select exactly one recording, with its FDT companion if needed.')
                    if len(files) > 2 or (len(files) == 2 and primary[0].suffix.lower() != '.set'):
                        raise ValueError('Only a SET recording may include an FDT companion. Use local-path import for split FIF.')
                    def import_batch():
                        try:
                            return {'project': workspace.import_file(primary[0], units=body.get('units', 'V'),
                                                                    montage_units=body.get('montage_units', 'auto'),
                                                                    uint16_codec=body.get('uint16_codec'))}
                        finally:
                            shutil.rmtree(folder, ignore_errors=True)
                    return self.send(jobs.submit('Import recording and companions', import_batch), 202)
                if route == '/api/import-path':
                    return self.send(jobs.submit('Import recording', lambda: {'project': workspace.import_file(body['path'], units=body.get('units', 'V'), montage_units=body.get('montage_units', 'auto'), uint16_codec=body.get('uint16_codec'))}), 202)
                if route == '/api/annotation':
                    return self.send(workspace.annotation(p, body))
                if route == '/api/bad-channels':
                    return self.send(workspace.bad_channels(p, body['channels']))
                if route == '/api/viewed':
                    return self.send(workspace.viewed(p, body['start'], body['end']))
                if route == '/api/montage':
                    return self.send(workspace.nominal_montage(p))
                if route == '/api/filter':
                    return self.send(jobs.submit('Filter recording', lambda: {'stage': workspace.filter(p, body['source'], body['low'], body['high'], body.get('notch'))}, p), 202)
                if route == '/api/reference':
                    def reference_stage():
                        stage = workspace.reference(p, body['source'], body['mode'], body.get('confirm', False))
                        return {'stage': stage, 'reused': stage == body['source']}
                    return self.send(jobs.submit('Change reference', reference_stage, p), 202)
                if route == '/api/fit-ica':
                    return self.send(jobs.submit('Fit ICA · full recording unless a fit range is set', lambda: {'model': workspace.fit_ica(p, body['source'], body.get('start', 0), body.get('end'), body.get('n_components'))}, p), 202)
                if route == '/api/apply-ica':
                    return self.send(jobs.submit('Apply reviewed ICA exclusions', lambda: {'stage': workspace.apply_ica(p, body['model'], body['excluded'])}, p), 202)
                if route == '/api/ica-selection':
                    return self.send(workspace.select_components(p, body['model'], body['excluded']))
                if route == '/api/psd':
                    return self.send(jobs.submit('Estimate accepted-window PSD', lambda: {'psd': workspace.psd(p, body['stage'], body.get('start', 0), body.get('end'), body.get('channels'))}, p), 202)
                if route == '/api/screen':
                    return self.send(jobs.submit('Screen full recording', lambda: workspace.screen(p, body['stage'], body.get('p2p_uv', 200), body.get('flat_uv', .1), body.get('robust_z', 8)), p), 202)
                if route == '/api/suggestion':
                    return self.send(workspace.resolve_suggestion(p, body['id'], body['accept'], body.get('note', '')))
                if route == '/api/export':
                    return self.send(jobs.submit('Package samples and review decisions', lambda: {'download': workspace.export(p, body['stage'], body.get('fif', False))}, p), 202)
                return self.send({'error': 'Endpoint not found.'}, 404)
            except PermissionError as exc:
                self.send({'error': str(exc)}, 403)
            except (ValueError, KeyError, OSError) as exc:
                self.send({'error': str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                traceback.print_exc()
                self.send({'error': str(exc)}, 500)

    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.workspace = workspace
    server.jobs = jobs
    return server


def serve(workspace, port=8765, open_browser=True):
    server = make_server(workspace, port)
    url = f'http://127.0.0.1:{server.server_port}'
    print(f'\nNeuroSync - cEEGrid Workbench is running at {url}\nSessions: {Path(workspace).resolve()}\nPress Ctrl+C to stop.\n', flush=True)
    if open_browser:
        threading.Timer(.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping NeuroSync - cEEGrid Workbench…', flush=True)
    finally:
        server.server_close()
        server.jobs.executor.shutdown(wait=True)
