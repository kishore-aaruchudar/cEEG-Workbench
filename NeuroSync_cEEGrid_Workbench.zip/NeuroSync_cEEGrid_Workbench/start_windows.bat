@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo Installation failed. Check your Python version and internet connection.
  pause
  exit /b 1
)
.venv\Scripts\python.exe run.py
pause
