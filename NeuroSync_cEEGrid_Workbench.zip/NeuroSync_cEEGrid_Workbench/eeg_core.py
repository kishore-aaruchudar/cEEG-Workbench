"""Disk-backed EEG review and processing. Samples are always stored in volts.

Scientific conventions:
- Time in the project is seconds relative to the first stored sample.
- Viewer envelopes are display-only; processing uses the full stored samples.
- Annotations are global in time; BAD* labels exclude spans from fit/PSD.
- Filtering is explicitly fourth-order Butterworth, forward/backward (zero phase).
- ICA uses scikit-learn FastICA with unit-variance whitening and a 1 Hz fit copy.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import platform
import re
import threading
import time
import uuid
import warnings
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.integrate import trapezoid


def now():
    return datetime.now(timezone.utc).isoformat()


def identifier():
    return uuid.uuid4().hex


def number(value, name, lower=None, upper=None):
    value = float(value)
    if not math.isfinite(value) or (lower is not None and value < lower) or (upper is not None and value > upper):
        raise ValueError(f'{name} must be finite and between {lower} and {upper}.')
    return value


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp-' + identifier())
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def require_mne():
    try:
        import mne
        return mne
    except ImportError as exc:
            raise ValueError('MNE is required for EDF/BDF/FIF/SET import and FIF export. Run: python -m pip install -r requirements.txt') from exc


def envelope(data, sfreq, start, max_points=2200):
    """Return chronologically ordered min/max points; preserve sharp display peaks."""
    data = np.asarray(data)
    count = data.shape[1]
    bucket = max(1, int(math.ceil(count / (max_points // 2))))
    result = []
    for row in data:
        if bucket == 1:
            indices = np.arange(count)
        else:
            usable = count // bucket * bucket
            blocks = row[:usable].reshape(-1, bucket)
            origins = np.arange(len(blocks)) * bucket
            pairs = np.column_stack((origins + blocks.argmin(1), origins + blocks.argmax(1)))
            indices = np.unique(np.concatenate((pairs.ravel(), np.arange(usable, count))))
        values = row[indices] * 1e6
        result.append({'x': (start + indices / sfreq).round(6).tolist(),
                       'y': [None if not np.isfinite(v) else float(v) for v in values]})
    return result, bucket


class Workspace:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()

    def directory(self, project):
        if not re.fullmatch(r'[a-f0-9]{32}', str(project)):
            raise ValueError('Invalid session identifier.')
        path = self.root / project
        if not (path / 'session.json').exists():
            raise ValueError('Session not found.')
        return path

    def meta(self, project):
        with self.lock:
            return json.loads((self.directory(project) / 'session.json').read_text(encoding='utf-8'))

    def update(self, project, change):
        with self.lock:
            meta = self.meta(project)
            change(meta)
            meta['updated_at'] = now()
            atomic_json(self.directory(project) / 'session.json', meta)
            return meta

    def projects(self):
        result = []
        for path in self.root.glob('*/session.json'):
            try:
                m = json.loads(path.read_text(encoding='utf-8'))
                result.append({k: m[k] for k in ['id', 'name', 'duration', 'created_at', 'updated_at']})
            except (ValueError, KeyError, OSError):
                continue
        return sorted(result, key=lambda m: m['updated_at'], reverse=True)

    def create(self, name, data, sfreq, names, types=None, positions=None, source=None,
               original_annotations=None, original_bads=None, metadata=None):
        sfreq = number(sfreq, 'Sampling frequency', 1, 100000)
        names = list(map(str, names))
        if data.ndim != 2 or data.shape[0] != len(names) or data.shape[1] < 4:
            raise ValueError('Expected data shape (channels, samples), with at least four samples.')
        if len(names) != len(set(names)) or not names or len(names) > 512:
            raise ValueError('Channel names must be unique; maximum 512 channels.')
        if data.dtype.kind not in 'fiu':
            raise ValueError('EEG samples must be numeric.')
        if types is not None and len(types) != len(names):
            raise ValueError('Channel types must match channel names.')
        project = identifier()
        directory = self.root / project
        directory.mkdir()
        raw_id = 'raw'
        target = np.lib.format.open_memmap(directory / 'raw.npy', mode='w+', dtype='float64', shape=data.shape)
        for i in range(data.shape[0]):
            row = np.asarray(data[i], dtype=float)
            if not np.isfinite(row).all():
                del target
                raise ValueError(f'Non-finite samples in channel {names[i]}; repair/annotate them before import.')
            target[i] = row
        target.flush()
        del target
        duration = data.shape[1] / sfreq
        m = {
            'schema_version': 1, 'id': project, 'name': str(name)[:180],
            'created_at': now(), 'updated_at': now(), 'sfreq': sfreq,
            'n_samples': int(data.shape[1]), 'duration': duration,
            'channels': names, 'channel_types': list(types or ['eeg'] * len(names)),
            'positions': positions or {}, 'position_provenance': 'Imported file' if positions else 'No positions',
            'source': source or {}, 'recording_metadata': metadata or {},
            'bad_channels': original_bads or [], 'annotations': original_annotations or [],
            'annotation_revision': 0, 'quality_revision': 0, 'viewed': [], 'audit': [],
            'suggestions': [], 'screening': None, 'ica_models': [],
            'stages': [{'id': raw_id, 'label': 'Imported', 'kind': 'raw', 'file': 'raw.npy',
                        'parent': None, 'created_at': now(), 'params': {}}],
        }
        atomic_json(directory / 'session.json', m)
        return project

    def import_file(self, path, name=None, units='V', montage_units='auto', uint16_codec=None):
        path = Path(path).expanduser().resolve()
        if not path.is_file():
            raise ValueError('Recording file not found. Enter a full local file path.')
        ext = path.suffix.lower()
        if ext == '.npz':
            with np.load(path, allow_pickle=False) as archive:
                required = {'data', 'sfreq', 'ch_names'}
                if not required.issubset(archive.files):
                    raise ValueError('NPZ requires data, sfreq, and ch_names. See README for notebook export.')
                data = archive['data']
                if units not in ['V', 'uV']:
                    raise ValueError('NPZ units must be V or uV.')
                if units == 'uV':
                    data = np.asarray(data, dtype=float) * 1e-6
                types = archive['ch_types'].tolist() if 'ch_types' in archive else None
                pos = {}
                if 'positions' in archive:
                    xyz = archive['positions']
                    if xyz.shape != (len(archive['ch_names']), 3):
                        raise ValueError('positions must have shape (channels, 3), in head coordinates/meters.')
                    pos = {str(ch): xyz[i].tolist() for i, ch in enumerate(archive['ch_names']) if np.isfinite(xyz[i]).all()}
                return self.create(name or path.name, data, float(archive['sfreq']), archive['ch_names'].tolist(), types=types,
                                   positions=pos, source={'format': 'npz', 'input_units': units})
        mne = require_mne()
        readers = {'.edf': mne.io.read_raw_edf, '.bdf': mne.io.read_raw_bdf, '.fif': mne.io.read_raw_fif,
                   '.set': mne.io.read_raw_eeglab}
        if ext not in readers:
            raise ValueError('Supported formats: .edf, .bdf, .fif, .set, .npz. FDT is a SET companion, not an independent recording.')
        kwargs = {'preload': False, 'verbose': False}
        if ext == '.set':
            if montage_units not in ['auto', 'm', 'cm', 'mm']:
                raise ValueError('EEGLAB coordinate units must be auto, m, cm, or mm.')
            if uint16_codec not in [None, '', 'utf-8', 'latin1', 'utf-16-le']:
                raise ValueError('Unsupported EEGLAB text codec.')
            kwargs.update(eog='auto', montage_units=montage_units, uint16_codec=uint16_codec or None)
        try:
            raw = readers[ext](str(path), **kwargs)
        except (FileNotFoundError, OSError) as exc:
            if ext == '.set':
                raise ValueError('Could not read the EEGLAB recording. If it uses external samples, keep its original .fdt file beside the .set file, or select both files together. Details: ' + str(exc)) from exc
            raise
        except ValueError as exc:
            if ext == '.set' and any(term in str(exc).lower() for term in ['trials', 'epochs']):
                raise ValueError('This SET contains epochs/trials. The continuous viewer requires a continuous SET; epochs are not silently concatenated.') from exc
            raise
        pos = {}
        montage = raw.get_montage()
        if montage:
            details = montage.get_positions()
            if details['coord_frame'] == 'head':
                pos = {k: v.tolist() for k, v in details['ch_pos'].items() if np.isfinite(v).all() and np.linalg.norm(v) > 0}
        annotations = []
        for annotation in raw.annotations:
            start = float(annotation['onset']) - raw.first_time
            end = min(raw.n_times / raw.info['sfreq'], start + float(annotation['duration']))
            if end >= 0:
                annotations.append({'id': identifier(), 'start': max(0., start), 'end': end,
                                    'label': str(annotation['description']), 'note': 'Imported annotation',
                                    'created_at': now(), 'origin': 'imported'})
        # Stream original samples into a temporary disk array rather than loading all into RAM.
        temporary = self.root / ('import-' + identifier() + '.npy')
        data = np.lib.format.open_memmap(temporary, mode='w+', dtype='float64', shape=(len(raw.ch_names), raw.n_times))
        try:
            block = max(1, int(raw.info['sfreq'] * 60))
            for start in range(0, raw.n_times, block):
                data[:, start:start+block] = raw.get_data(start=start, stop=min(raw.n_times, start+block))
            result = self.create(name or path.name, data, raw.info['sfreq'], raw.ch_names,
                                 types=raw.get_channel_types(), positions=pos,
                                 source={'format': ext[1:], **({'eeglab_montage_units': montage_units,
                                                              'eeglab_text_codec': uint16_codec or 'default'} if ext == '.set' else {})},
                                 original_annotations=annotations, original_bads=list(raw.info['bads']),
                                 metadata={'original_first_samp': raw.first_samp,
                                           'meas_date': str(raw.info['meas_date']),
                                           'reference': 'Imported reference; verify acquisition metadata.'})
        finally:
            del data
            raw.close()
            temporary.unlink(missing_ok=True)
        return result

    def stage(self, project, stage_id):
        m = self.meta(project)
        stages = {s['id']: s for s in m['stages']}
        if stage_id not in stages:
            raise ValueError('Processing stage not found.')
        data = np.load(self.directory(project) / stages[stage_id]['file'], mmap_mode='r', allow_pickle=False)
        return m, stages[stage_id], data

    def channel_indices(self, m, names=None, eeg_only=False, exclude_bad=False):
        selected = list(names) if names is not None else m['channels']
        if len(set(selected)) != len(selected) or any(n not in m['channels'] for n in selected):
            raise ValueError('Invalid channel selection.')
        return [m['channels'].index(n) for n in selected
                if (not eeg_only or m['channel_types'][m['channels'].index(n)] == 'eeg')
                and (not exclude_bad or n not in m['bad_channels'])]

    def window(self, project, stage_id, start=0, duration=10, channels=None):
        m, stage, data = self.stage(project, stage_id)
        duration = number(duration, 'Window duration', .05, 120)
        start = number(start, 'Window start', 0, m['duration'])
        sfreq = m['sfreq']
        a, b = int(start * sfreq), min(m['n_samples'], int((start + duration) * sfreq))
        if b-a < 2:
            raise ValueError('Select an earlier time window.')
        indices = self.channel_indices(m, channels)
        if not indices or len(indices) > 64:
            raise ValueError('Select between one and 64 channels.')
        samples = data[indices, a:b]
        traces, bucket = envelope(samples, sfreq, a/sfreq)
        stats = []
        for name, row in zip([m['channels'][i] for i in indices], samples):
            finite = row[np.isfinite(row)] * 1e6
            if not len(finite):
                stats.append({'channel': name, 'finite_samples': 0, 'median_uv': None,
                              'min_uv': None, 'max_uv': None, 'q01_uv': None, 'q99_uv': None, 'rms_ac_uv': None})
                continue
            median = float(np.median(finite))
            q01, q99 = np.percentile(finite, [1, 99])
            stats.append({'channel': name, 'finite_samples': int(len(finite)), 'median_uv': median,
                          'min_uv': float(finite.min()), 'max_uv': float(finite.max()),
                          'q01_uv': float(q01), 'q99_uv': float(q99),
                          'rms_ac_uv': float(np.sqrt(np.mean((finite-median)**2)))})
        return {'start': a/sfreq, 'end': (b-1)/sfreq, 'stage': stage_id, 'sfreq': sfreq,
                'channels': [m['channels'][i] for i in indices], 'traces': traces,
                'stats': stats, 'display_bucket_samples': bucket, 'units': 'uV'}

    def overview(self, project, stage_id):
        m, stage, data = self.stage(project, stage_id)
        # One robust median-channel RMS measurement per two-second bucket.
        indices = self.channel_indices(m, eeg_only=True, exclude_bad=True)
        if not indices:
            raise ValueError('No good EEG channels remain.')
        block = max(4, round(m['sfreq'] * 2))
        times, rms = [], []
        for a in range(0, m['n_samples'], block):
            x = data[indices, a:a+block]
            x = x - np.median(x, axis=1, keepdims=True)
            times.append(a / m['sfreq'])
            rms.append(float(np.median(np.sqrt(np.mean(x*x, axis=1))) * 1e6))
        return {'times': times, 'rms_uv': rms}

    @staticmethod
    def annotation_context(meta, context):
        if not context:
            return None
        if not isinstance(context, dict):
            raise ValueError('Annotation context must be an object.')
        if context.get('view') != 'ica-all':
            return {'view': 'waveforms'}
        model = next((m for m in meta['ica_models'] if m['id'] == context.get('model')), None)
        if model is None:
            raise ValueError('Annotation ICA model not found.')
        component = int(context.get('component', -1))
        if not 0 <= component < model['n_components']:
            raise ValueError('Invalid annotation component.')
        return {'view': 'ica-all', 'model': model['id'], 'component': component,
                'scope': 'recording-time'}

    def annotation(self, project, payload):
        def change(m):
            old_id = payload.get('id')
            if payload.get('delete'):
                found = [a for a in m['annotations'] if a['id'] == old_id]
                if not found:
                    raise ValueError('Annotation not found.')
                m['annotations'] = [a for a in m['annotations'] if a['id'] != old_id]
                action = 'delete_annotation'
            else:
                start = number(payload['start'], 'Annotation start', 0, m['duration'])
                end = number(payload['end'], 'Annotation end', 0, m['duration'])
                if end <= start:
                    raise ValueError('Annotation end must be after its start.')
                label = str(payload.get('label', 'BAD_artifact')).strip()[:100]
                if not label:
                    raise ValueError('An annotation label is required.')
                annotation = {'id': old_id or identifier(), 'start': start, 'end': end,
                              'label': label, 'note': str(payload.get('note', ''))[:2000],
                              'created_at': now(), 'origin': 'reviewed',
                              'context': self.annotation_context(m, payload.get('context'))}
                if old_id and not any(a['id'] == old_id for a in m['annotations']):
                    raise ValueError('Annotation not found.')
                m['annotations'] = [a for a in m['annotations'] if a['id'] != old_id] + [annotation]
                m['annotations'].sort(key=lambda a: a['start'])
                action = 'save_annotation'
            m['annotation_revision'] += 1
            m['quality_revision'] += 1
            m['audit'].append({'time': now(), 'action': action, 'id': old_id or annotation['id']})
        return self.update(project, change)

    def bad_channels(self, project, names):
        def change(m):
            self.channel_indices(m, names)
            m['bad_channels'] = sorted(set(names), key=m['channels'].index)
            m['quality_revision'] += 1
            m['audit'].append({'time': now(), 'action': 'bad_channels', 'channels': m['bad_channels']})
        return self.update(project, change)

    def viewed(self, project, start, end):
        def change(m):
            a = number(start, 'Viewed start', 0, m['duration'])
            b = number(end, 'Viewed end', a, m['duration'])
            merged = []
            for x, y in sorted(m['viewed'] + [[a, b]]):
                if merged and x <= merged[-1][1]:
                    merged[-1][1] = max(y, merged[-1][1])
                else:
                    merged.append([x, y])
            m['viewed'] = merged
        return self.update(project, change)

    def _new_stage(self, project, source_id, kind, label, operation, params):
        m, source, data = self.stage(project, source_id)
        stage_id = kind + '-' + identifier()[:10]
        filename = stage_id + '.npy'
        path = self.directory(project) / filename
        out = np.lib.format.open_memmap(path, mode='w+', dtype='float64', shape=data.shape)
        try:
            operation(m, data, out)
            out.flush()
            del out
            stage = {'id': stage_id, 'kind': kind, 'label': label, 'file': filename, 'parent': source_id,
                     'created_at': now(), 'params': params, 'quality_revision': m['quality_revision']}
            self.update(project, lambda meta: meta['stages'].append(stage))
            return stage_id
        except Exception:
            if 'out' in locals():
                del out
            path.unlink(missing_ok=True)
            raise

    @staticmethod
    def lineage(meta, stage_id):
        stages = {stage['id']: stage for stage in meta['stages']}
        result, seen = [], set()
        while stage_id is not None:
            if stage_id in seen or stage_id not in stages:
                raise ValueError('Invalid processing lineage.')
            seen.add(stage_id)
            stage = stages[stage_id]
            result.append(stage)
            stage_id = stage['parent']
        return list(reversed(result))

    @classmethod
    def processing_context(cls, meta, stage_id):
        lineage = cls.lineage(meta, stage_id)
        filters = [s for s in lineage if s['kind'] == 'filtered']
        references = [s for s in lineage if s['kind'] == 'reference']
        lows = [float(s['params']['highpass_hz']) for s in filters]
        highs = [float(s['params']['lowpass_hz']) for s in filters]
        return {'source': stage_id, 'source_label': lineage[-1]['label'],
                'lineage': [s['id'] for s in lineage],
                'known_highpass_hz': max(lows) if lows else None,
                'known_lowpass_hz': min(highs) if highs else None,
                'reference': references[-1]['params'] if references else None,
                'filter_steps': [s['id'] for s in filters]}

    def filter(self, project, source_id, low=1, high=40, notch=None):
        m = self.meta(project)
        low = number(low, 'High-pass', 0, m['sfreq']/2)
        high = number(high, 'Low-pass', .01, m['sfreq']/2)
        if high >= m['sfreq']/2 or low >= high:
            raise ValueError('Require 0 <= high-pass < low-pass < Nyquist.')
        sos = signal.butter(4, [low, high] if low else high, btype='bandpass' if low else 'lowpass', fs=m['sfreq'], output='sos')
        notch_freqs = []
        if notch not in (None, '', 'none', 0):
            base = number(notch, 'Notch frequency', 1, m['sfreq']/2 - .01)
            # Only notch the selected fundamental; do not invent extra harmonics.
            notch_freqs = [base]
        eeg = self.channel_indices(m, eeg_only=True)
        def operation(meta, data, out):
            for i in range(len(meta['channels'])):
                row = np.array(data[i])
                if i in eeg:
                    for frequency in notch_freqs:
                        b, a = signal.iirnotch(frequency, 30, fs=meta['sfreq'])
                        row = signal.filtfilt(b, a, row)
                    row = signal.sosfiltfilt(sos, row)
                out[i] = row
        params = {'highpass_hz': low, 'lowpass_hz': high, 'notch_hz': notch_freqs,
                  'method': 'Butterworth order 4, forward/backward zero phase; notch Q=30',
                  'note': 'Continuous filtering; inspect filter ringing around abrupt artifacts.'}
        return self._new_stage(project, source_id, 'filtered', f'Filtered · {low:g}–{high:g} Hz', operation, params)

    def reference(self, project, source_id, mode, confirm=False):
        m, source, data = self.stage(project, source_id)
        eeg = self.channel_indices(m, eeg_only=True)
        good = self.channel_indices(m, eeg_only=True, exclude_bad=True)
        if not good:
            raise ValueError('No good EEG channels remain.')
        if mode not in ['average', 'linked']:
            raise ValueError('Choose available-channel average or verified linked mastoids.')
        if mode == 'average':
            context = self.processing_context(m, source_id)
            previous = context['reference']
            requested_channels = [m['channels'][i] for i in good]
            if previous and previous.get('mode') == 'average' and previous.get('reference_channels') == requested_channels:
                # An unchanged available-channel average is idempotent. Reuse
                # the selected stage instead of writing another identical file.
                return source_id
        if mode == 'linked':
            stages = {s['id']: s for s in m['stages']}
            current = source
            while current:
                if current['kind'] in ['reference', 'cleaned']:
                    raise ValueError('Linked mastoids requires the original-reference data, before any previous re-reference/ICA correction.')
                current = stages.get(current['parent'])
            if not confirm or 'L04b' not in m['channels'] or 'L04b' in m['bad_channels']:
                raise ValueError('Verify original R4b reference and a usable L04b channel first.')
            if any(n in m['channels'] for n in ['R04b', 'R4b']):
                raise ValueError('A right reference channel is already recorded; verify the wiring before using this shortcut.')
        def operation(meta, x, out):
            block = max(1, int(meta['sfreq'] * 30))
            for a in range(0, meta['n_samples'], block):
                chunk = np.array(x[:, a:a+block])
                reference = chunk[good].mean(axis=0) if mode == 'average' else .5*chunk[meta['channels'].index('L04b')]
                chunk[eeg] -= reference
                out[:, a:a+block] = chunk
        params = {'mode': mode, 'reference_channels': [m['channels'][i] for i in good] if mode == 'average' else ['L04b', 'unrecorded original R4b'],
                  'original_r4b_confirmed': bool(confirm)}
        return self._new_stage(project, source_id, 'reference', 'Reference · ' + mode, operation, params)

    def _bad_mask(self, m, start, stop):
        mask = np.zeros(stop-start, dtype=bool)
        for annotation in m['annotations']:
            if not annotation['label'].lower().startswith('bad'):
                continue
            a = max(start, int(math.floor(annotation['start']*m['sfreq'])))
            b = min(stop, int(math.ceil(annotation['end']*m['sfreq'])))
            if b > a:
                mask[a-start:b-start] = True
        return mask

    def fit_ica(self, project, source_id, start=0, end=None, n_components=None, max_samples=200000):
        from sklearn.decomposition import FastICA
        from sklearn.exceptions import ConvergenceWarning
        m, source, x = self.stage(project, source_id)
        if source['kind'] == 'cleaned':
            raise ValueError('Fit ICA on a pre-ICA stage, not an already corrected stage.')
        indices = self.channel_indices(m, eeg_only=True, exclude_bad=True)
        if len(indices) < 2:
            raise ValueError('ICA requires at least two usable EEG channels.')
        start = number(start, 'ICA start', 0, m['duration'])
        end = m['duration'] if end in (None, '') else number(end, 'ICA end', 0, m['duration'])
        a, b = int(start*m['sfreq']), min(m['n_samples'], int(end*m['sfreq']))
        if b-a < m['sfreq']*10:
            raise ValueError('Choose at least ten seconds for ICA; use representative clean data.')
        good_samples = np.flatnonzero(~self._bad_mask(m, a, b)) + a
        if len(good_samples) < max(1000, 20*len(indices)):
            raise ValueError('Insufficient accepted samples for ICA.')
        # Distribution sampling, not unfiltered time decimation. ICA is instantaneous.
        max_samples = int(number(max_samples, 'ICA sample cap', 1000, 500000))
        if len(good_samples) > max_samples:
            good_samples = np.sort(np.random.default_rng(97).choice(good_samples, max_samples, replace=False))
        context = self.processing_context(m, source_id)
        # A previous recorded app high-pass >= 1 Hz already meets this fitting
        # policy. Do not cascade a second 1 Hz filter on an existing 1–70 stage.
        additional_highpass = context['known_highpass_hz'] is None or context['known_highpass_hz'] < 1.
        fit_highpass = signal.butter(4, 1., btype='highpass', fs=m['sfreq'], output='sos') if additional_highpass else None
        train = np.empty((len(good_samples), len(indices)))
        for column, i in enumerate(indices):
            filtered = signal.sosfiltfilt(fit_highpass, np.array(x[i])) if additional_highpass else x[i]
            train[:, column] = filtered[good_samples]
        # Scale volts to uV for stable numeric conditioning; store this factor explicitly.
        train *= 1e6
        eigenvalues = np.linalg.eigvalsh(np.cov(train, rowvar=False))
        largest = max(float(eigenvalues[-1]), np.finfo(float).tiny)
        rank = int(np.sum(eigenvalues > largest*1e-8))
        if rank < 2:
            raise ValueError('Effective rank is below two; inspect reference, flat channels, and duplicates.')
        requested = rank if n_components in (None, '', 'auto') else int(n_components)
        if not 1 <= requested <= rank:
            raise ValueError(f'Component count must be 1–{rank} (estimated effective rank).')
        model = FastICA(n_components=requested, whiten='unit-variance', algorithm='parallel',
                        fun='logcosh', random_state=97, max_iter=1500, tol=1e-4)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always', ConvergenceWarning)
            model.fit(train)
        converged = not any(issubclass(w.category, ConvergenceWarning) for w in caught)
        model_id = 'ica-' + identifier()[:10]
        np.savez(self.directory(project) / (model_id + '.npz'), components=model.components_,
                 mixing=model.mixing_, mean=model.mean_, indices=np.array(indices, dtype=int))
        info = {'id': model_id, 'source': source_id, 'created_at': now(), 'channels': [m['channels'][i] for i in indices],
                'n_components': requested, 'rank': rank, 'converged': converged, 'iterations': int(model.n_iter_),
                'fit_start': start, 'fit_end': end, 'training_samples': len(good_samples),
                'highpass_fit_hz': 1. if additional_highpass else context['known_highpass_hz'],
                'additional_highpass_hz': 1. if additional_highpass else None,
                'source_context': context,
                'fit_filter_note': 'Private 1 Hz high-pass fit copy; source samples unchanged.' if additional_highpass else 'Source already high-pass filtered at >=1 Hz; no additional fit filter.',
                'quality_revision': m['quality_revision'], 'method': 'sklearn FastICA; unit-variance whitening; seed 97',
                'sampling': 'Seeded subset of accepted samples if above cap; not time-series decimation.'}
        self.update(project, lambda meta: meta['ica_models'].append(info))
        return model_id

    def model(self, project, model_id):
        m = self.meta(project)
        info = next((i for i in m['ica_models'] if i['id'] == model_id), None)
        if info is None:
            raise ValueError('ICA model not found.')
        with np.load(self.directory(project)/(model_id+'.npz'), allow_pickle=False) as arrays:
            result = {key: arrays[key] for key in arrays.files}
        return m, info, result

    def component(self, project, model_id, component, start=0, duration=10):
        m, info, arrays = self.model(project, model_id)
        component = int(component)
        if not 0 <= component < info['n_components']:
            raise ValueError('Component index out of range.')
        m, stage, x = self.stage(project, info['source'])
        start = number(start, 'Start', 0, m['duration'])
        duration = number(duration, 'Duration', .1, 120)
        a, b = int(start*m['sfreq']), min(m['n_samples'], int((start+duration)*m['sfreq']))
        if b-a < 4:
            raise ValueError('ICA display interval too short.')
        centered = x[arrays['indices'], a:b].T*1e6-arrays['mean']
        s = centered @ arrays['components'][component]
        # envelope expects volts; divide to preserve arbitrary source units through helper.
        traces, bucket = envelope(s[None, :]/1e6, m['sfreq'], a/m['sfreq'])
        n = min(len(s), max(4, int(m['sfreq']*2)))
        f, p = signal.welch(s, fs=m['sfreq'], nperseg=n, noverlap=n//2)
        keep = f <= min(80, m['sfreq']/2)
        return {'info': info, 'index': component, 'trace': traces[0],
                'source_stats': {'rms': float(np.sqrt(np.mean(s*s))), 'peak_to_peak': float(np.ptp(s))},
                'frequencies': f[keep].tolist(), 'psd_db': (10*np.log10(np.maximum(p[keep], 1e-30))).tolist(),
                'channels': info['channels'], 'weights': arrays['mixing'][:, component].tolist(),
                'positions': {n: m['positions'][n] for n in info['channels'] if n in m['positions']}}

    def all_components(self, project, model_id, start=0, duration=10):
        """Source waveforms from one model in recorded sample time, without refitting."""
        m, info, arrays = self.model(project, model_id)
        m, source, x = self.stage(project, info['source'])
        start = number(start, 'Component window start', 0, m['duration'])
        duration = number(duration, 'Component window duration', .1, 120)
        a, b = int(start*m['sfreq']), min(m['n_samples'], int((start+duration)*m['sfreq']))
        if b-a < 4:
            raise ValueError('Choose an earlier or longer component window.')
        centered = x[arrays['indices'], a:b].T*1e6-arrays['mean']
        sources = (centered @ arrays['components'].T).T
        traces, bucket = envelope(sources/1e6, m['sfreq'], a/m['sfreq'])
        stats = []
        for row in sources:
            median = float(np.median(row))
            q01, q99 = np.percentile(row, [1, 99])
            stats.append({'median': median, 'min': float(row.min()), 'max': float(row.max()),
                          'q01': float(q01), 'q99': float(q99),
                          'rms': float(np.sqrt(np.mean(row*row))), 'peak_to_peak': float(np.ptp(row))})
        return {'info': info, 'source': info['source'], 'start': a/m['sfreq'], 'end': (b-1)/m['sfreq'],
                'sfreq': m['sfreq'], 'components': [f'IC{i:03d}' for i in range(info['n_components'])],
                'traces': traces, 'stats': stats, 'units': 'a.u.', 'display_bucket_samples': bucket}

    def apply_ica(self, project, model_id, excluded):
        m, info, arrays = self.model(project, model_id)
        excluded = sorted(set(int(i) for i in excluded))
        if not excluded or any(i < 0 or i >= info['n_components'] for i in excluded):
            raise ValueError('Select one or more valid components after reviewing their evidence.')
        if len(excluded) == info['n_components']:
            raise ValueError('Do not exclude every component.')
        if not info['converged']:
            raise ValueError('ICA did not converge. Adjust fit interval/channel quality and refit before correction.')
        if info['quality_revision'] != m['quality_revision']:
            raise ValueError('Annotations or bad channels changed after fitting. Refit ICA to use the current review decisions.')
        def operation(meta, x, out):
            block = max(1, int(meta['sfreq']*30))
            for a in range(0, meta['n_samples'], block):
                chunk = np.array(x[:, a:a+block])
                eeg = chunk[arrays['indices']].T*1e6
                source = (eeg-arrays['mean']) @ arrays['components'][excluded].T
                removed = source @ arrays['mixing'][:, excluded].T
                chunk[arrays['indices']] -= removed.T/1e6
                out[:, a:a+block] = chunk
        return self._new_stage(project, info['source'], 'cleaned', 'ICA corrected · ' + ', '.join(map(str, excluded)), operation,
                               {'ica_model': model_id, 'excluded': excluded, 'mean_handling': 'Subtract excluded centered contributions; preserve residual/PCA subspace.'})

    def select_components(self, project, model_id, excluded):
        m, info, arrays = self.model(project, model_id)
        excluded = sorted(set(int(i) for i in excluded))
        if any(i < 0 or i >= info['n_components'] for i in excluded):
            raise ValueError('Invalid component index.')
        def change(meta):
            for model in meta['ica_models']:
                if model['id'] == model_id:
                    model['selected_excluded'] = excluded
            meta['audit'].append({'time': now(), 'action': 'review_ica_selection', 'model': model_id, 'excluded': excluded})
        return self.update(project, change)

    def psd(self, project, stage_id, start=0, end=None, channels=None):
        m, stage, x = self.stage(project, stage_id)
        start = number(start, 'PSD start', 0, m['duration'])
        end = m['duration'] if end in (None, '') else number(end, 'PSD end', start, m['duration'])
        indices = self.channel_indices(m, channels, eeg_only=True, exclude_bad=True)
        if not indices:
            raise ValueError('No selected good EEG channels for PSD.')
        n = int(round(4*m['sfreq']))
        step = max(1, n//2)
        a, b = int(start*m['sfreq']), min(m['n_samples'], int(end*m['sfreq']))
        bad_samples = self._bad_mask(m, a, b)
        accepted, total, mean_psd = 0, 0, None
        for first in range(a, b-n+1, step):
            total += 1
            if bad_samples[first-a:first-a+n].any():
                continue
            f, p = signal.periodogram(x[indices, first:first+n], fs=m['sfreq'], window='hamming', detrend='constant', axis=-1)
            mean_psd = p.copy() if mean_psd is None else mean_psd + p
            accepted += 1
        if not accepted:
            raise ValueError('No complete accepted four-second windows. Expand the interval or review annotations.')
        mean_psd /= accepted
        keep = f <= min(80, m['sfreq']/2)
        mean_linear = mean_psd.mean(axis=0)*1e12
        bandpowers = {}
        for name, lo, hi in [('Delta', 1, 4), ('Theta', 4, 8), ('Alpha', 8, 13), ('Beta', 13, 30), ('30–45 Hz', 30, 45)]:
            mask = (f >= lo) & (f <= hi)
            if mask.sum() > 1:
                bandpowers[name] = (10*np.log10(np.maximum(trapezoid(mean_psd[:, mask], f[mask], axis=1)*1e12, 1e-30))).tolist()
        return {'frequencies': f[keep].tolist(), 'mean_db': (10*np.log10(np.maximum(mean_linear[keep], 1e-30))).tolist(),
                'channels': [m['channels'][i] for i in indices], 'per_channel_db': (10*np.log10(np.maximum(mean_psd[:, keep]*1e12, 1e-30))).tolist(),
                'bandpower_db': bandpowers, 'accepted_windows': accepted, 'total_windows': total,
                'settings': 'Hamming, 4 s, 50% overlap; BAD spans rejected; linear power averaged before dB.'}

    def screen(self, project, stage_id, p2p_uv=200, flat_uv=.1, robust_z=8):
        m, stage, x = self.stage(project, stage_id)
        p2p_uv = number(p2p_uv, 'Peak-to-peak threshold', 1, 100000)
        flat_uv = number(flat_uv, 'Flatness threshold', 0, 100)
        robust_z = number(robust_z, 'Robust threshold', 2, 100)
        indices = self.channel_indices(m, eeg_only=True, exclude_bad=True)
        if not indices:
            raise ValueError('No good EEG channels.')
        n = max(4, round(2*m['sfreq']))
        metrics = []
        for a in range(0, m['n_samples']-n+1, n):
            block = x[indices, a:a+n]*1e6
            metrics.append((a/m['sfreq'], np.ptp(block, axis=1), np.sqrt(np.mean((block-block.mean(axis=1, keepdims=True))**2, axis=1))))
        if not metrics:
            raise ValueError('Need at least two seconds to screen.')
        rms = np.array([v[2] for v in metrics])
        median = np.median(rms, axis=0)
        mad = 1.4826*np.median(np.abs(rms-median), axis=0)
        floor = np.maximum(mad, np.maximum(median*.05, .01))
        suggestions = []
        for start, ptp, r in metrics:
            reasons = []
            flags = (ptp > p2p_uv) | (ptp < flat_uv) | ((r-median)/floor > robust_z)
            if not flags.any():
                continue
            if (ptp > p2p_uv).any(): reasons.append('large amplitude')
            if (ptp < flat_uv).any(): reasons.append('flat signal')
            if ((r-median)/floor > robust_z).any(): reasons.append('unusual RMS')
            channels = [m['channels'][indices[i]] for i in np.flatnonzero(flags)]
            if suggestions and abs(suggestions[-1]['end']-start) < 1e-6:
                suggestions[-1]['end'] = start+2
                suggestions[-1]['channels'] = sorted(set(suggestions[-1]['channels']+channels))
                suggestions[-1]['reasons'] = sorted(set(suggestions[-1]['reasons']+reasons))
            else:
                suggestions.append({'id': identifier(), 'start': start, 'end': start+2,
                                    'channels': channels, 'reasons': reasons, 'status': 'pending'})
        settings = {'stage': stage_id, 'p2p_uv': p2p_uv, 'flat_uv': flat_uv, 'robust_z': robust_z,
                    'created_at': now(), 'windows': len(metrics), 'note': 'Heuristic screening only. Flags are not BAD annotations.'}
        def change(meta):
            meta['suggestions'] = suggestions
            meta['screening'] = settings
        self.update(project, change)
        return {'candidates': len(suggestions), 'settings': settings}

    def resolve_suggestion(self, project, suggestion_id, accept, note=''):
        m = self.meta(project)
        item = next((s for s in m['suggestions'] if s['id'] == suggestion_id), None)
        if not item:
            raise ValueError('Candidate not found.')
        if item['status'] != 'pending':
            raise ValueError('Candidate was already reviewed.')
        if accept:
            self.annotation(project, {'start': item['start'], 'end': item['end'], 'label': 'BAD_artifact',
                                      'note': note or ('Reviewed screening candidate: ' + ', '.join(item['reasons']))})
        def change(meta):
            for s in meta['suggestions']:
                if s['id'] == suggestion_id:
                    s['status'] = 'accepted' if accept else 'dismissed'
        return self.update(project, change)

    def nominal_montage(self, project):
        # User-supplied spherical coordinates; exact channel names only.
        right = {
            '08': [.08065417, .02620613, -.05299193], '07': [.07339955, .01162535, -.06691306],
            '06': [.07339955, -.01162535, -.06691306], '05': [.08065417, -.02620613, -.05299193],
            '04': [.09302736, -.03022642, -.02079117], '03': [.09870867, -.01563392, -.00348995],
            '02': [.09870867, .01563392, -.00348995], '01': [.09302736, .03022642, -.02079117],
        }
        pos = {'R'+n: xyz for n, xyz in right.items()}
        pos.update({'L'+n: [-xyz[0], xyz[1], xyz[2]] for n, xyz in right.items()})
        pos.update({'L04a': [-.08940054, -.03078307, -.03255682], 'L04b': [-.08569308, -.0295065, -.04226183]})
        def change(m):
            matching = {n: pos[n] for n in m['channels'] if n in pos}
            if not matching:
                raise ValueError('No exact cEEGrid names match. Preserve/verify your wiring labels first.')
            m['positions'].update(matching)
            m['position_provenance'] = 'User-supplied nominal 100 mm cEEGrid sphere; not participant digitization'
            m['audit'].append({'time': now(), 'action': 'apply_nominal_ceegrid_geometry', 'channels': list(matching)})
        return self.update(project, change)

    def review_csv(self, project):
        m = self.meta(project)
        text = io.StringIO(newline='')
        writer = csv.writer(text, delimiter='\t')
        writer.writerow(['onset', 'duration', 'description', 'note', 'origin'])
        for a in m['annotations']:
            writer.writerow([a['start'], a['end']-a['start'], a['label'], a['note'], a.get('origin', '')])
        return text.getvalue()

    def export(self, project, stage_id, fif=False):
        m, stage, data = self.stage(project, stage_id)
        directory = self.directory(project) / 'exports'
        directory.mkdir(exist_ok=True)
        suffix = identifier()[:8]
        if fif:
            mne = require_mne()
            info = mne.create_info(m['channels'], m['sfreq'], m['channel_types'])
            raw = mne.io.RawArray(np.asarray(data), info, copy='auto', verbose=False)
            raw.info['bads'] = list(m['bad_channels'])
            if m['positions']:
                raw.set_montage(mne.channels.make_dig_montage(ch_pos={n: np.array(v) for n, v in m['positions'].items()}, coord_frame='head'), on_missing='ignore')
            raw.set_annotations(mne.Annotations(
                onset=[a['start'] for a in m['annotations']],
                duration=[a['end']-a['start'] for a in m['annotations']],
                description=[a['label'] for a in m['annotations']],
            ))
            filename = f'{stage_id}-{suffix}_raw.fif'
            raw.save(directory/filename, overwrite=False, split_size='2GB', fmt='double', verbose=False)
            files = list(directory.glob(f'{stage_id}-{suffix}*.fif'))
            # Bundle split FIF files together so large exports remain usable.
            destination = directory / f'fif-export-{suffix}.zip'
            with zipfile.ZipFile(destination, 'w', zipfile.ZIP_STORED) as z:
                for p in files:
                    z.write(p, p.name)
                z.writestr('session.json', json.dumps(m, indent=2))
                z.writestr('annotations.tsv', self.review_csv(project))
            return destination.name
        filename = f'review-{stage_id}-{suffix}.zip'
        destination = directory / filename
        with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as z:
            z.write(self.directory(project)/stage['file'], 'data.npy')
            exported = dict(m, exported_stage=stage, export_time=now(), data_units='V', time_origin='First stored sample; t=0', python=platform.python_version())
            z.writestr('session.json', json.dumps(exported, indent=2))
            z.writestr('annotations.tsv', self.review_csv(project))
            z.writestr('load_review.py', REPLAY_SCRIPT)
            for model in m['ica_models']:
                z.write(self.directory(project)/(model['id']+'.npz'), 'ica/'+model['id']+'.npz')
        return filename


REPLAY_SCRIPT = '''"""Run beside extracted data.npy/session.json. Requires MNE and NumPy."""
import json
from pathlib import Path
import numpy as np
import mne
folder = Path(__file__).resolve().parent
meta = json.loads((folder / "session.json").read_text(encoding="utf-8"))
samples = np.load(folder / "data.npy", mmap_mode="r", allow_pickle=False)
info = mne.create_info(meta["channels"], meta["sfreq"], meta["channel_types"])
raw = mne.io.RawArray(np.asarray(samples), info, copy="auto")
raw.info["bads"] = meta["bad_channels"]
if meta["positions"]:
    montage = mne.channels.make_dig_montage(ch_pos={n: np.array(v) for n,v in meta["positions"].items()}, coord_frame="head")
    raw.set_montage(montage, on_missing="ignore")
ann = meta["annotations"]
raw.set_annotations(mne.Annotations([a["start"] for a in ann], [a["end"]-a["start"] for a in ann], [a["label"] for a in ann]))
print("Loaded:", meta["exported_stage"]["label"])
print("Annotations:", len(ann), "Bad channels:", raw.info["bads"])
# BAD annotations are retained, not erased from continuous samples.
# Example: raw.compute_psd(method="welch", reject_by_annotation=True)
'''
